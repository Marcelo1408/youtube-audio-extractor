<?php
// Sistema de autenticação avançado

class Auth {
    private $db;
    private $conn;
    
    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
    }
    
    public function register($data) {
        try {
            // Validar dados
            $errors = $this->validateRegistration($data);
            if (!empty($errors)) {
                return ['success' => false, 'errors' => $errors];
            }
            
            // Verificar se email já existe
            if ($this->emailExists($data['email'])) {
                return ['success' => false, 'errors' => ['email' => 'Este email já está registrado']];
            }
            
            // Verificar se username já existe
            if ($this->usernameExists($data['username'])) {
                return ['success' => false, 'errors' => ['username' => 'Este nome de usuário já está em uso']];
            }
            
            // Hash da senha
            $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);
            
            // Gerar token de verificação
            $verificationToken = bin2hex(random_bytes(32));
            
            // Inserir usuário
            $stmt = $this->conn->prepare("
                INSERT INTO users (
                    username, 
                    email, 
                    password, 
                    phone,
                    verification_token,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->bind_param(
                "sssss",
                $data['username'],
                $data['email'],
                $hashedPassword,
                $data['phone'] ?? null,
                $verificationToken
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Erro ao criar usuário: " . $stmt->error);
            }
            
            $userId = $stmt->insert_id;
            $stmt->close();
            
            // Criar sessão
            $this->createSession($userId, $data['username']);
            
            // Enviar email de verificação (se configurado)
            $this->sendVerificationEmail($data['email'], $verificationToken);
            
            // Log
            log_message("Novo usuário registrado: {$data['username']} ({$data['email']})");
            
            return [
                'success' => true,
                'message' => 'Conta criada com sucesso!',
                'user_id' => $userId,
                'redirect' => 'index.php'
            ];
            
        } catch (Exception $e) {
            log_message("Erro no registro: " . $e->getMessage(), 'ERROR');
            return ['success' => false, 'errors' => ['general' => 'Erro ao criar conta. Tente novamente.']];
        }
    }
    
    public function login($email, $password, $remember = false) {
        try {
            // Buscar usuário
            $stmt = $this->conn->prepare("
                SELECT id, username, email, password, role, status, email_verified 
                FROM users 
                WHERE email = ? OR username = ?
            ");
            
            $stmt->bind_param("ss", $email, $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                return ['success' => false, 'error' => 'Credenciais inválidas'];
            }
            
            $user = $result->fetch_assoc();
            $stmt->close();
            
            // Verificar status da conta
            if ($user['status'] !== 'active') {
                return ['success' => false, 'error' => 'Sua conta está suspensa ou banida'];
            }
            
            // Verificar senha
            if (!password_verify($password, $user['password'])) {
                // Registrar tentativa falha
                $this->logFailedAttempt($user['id']);
                return ['success' => false, 'error' => 'Credenciais inválidas'];
            }
            
            // Verificar email (se necessário)
            if (!$user['email_verified'] && getenv('REQUIRE_EMAIL_VERIFICATION') === 'true') {
                return ['success' => false, 'error' => 'Verifique seu email antes de fazer login'];
            }
            
            // Criar sessão
            $this->createSession($user['id'], $user['username'], $user['role']);
            
            // Atualizar último login
            $this->updateLastLogin($user['id']);
            
            // Lembrar de mim
            if ($remember) {
                $this->setRememberMeCookie($user['id']);
            }
            
            // Limpar tentativas falhas
            $this->clearFailedAttempts($user['id']);
            
            // Log
            log_message("Login realizado: {$user['username']}");
            
            return [
                'success' => true,
                'message' => 'Login realizado com sucesso!',
                'redirect' => $_SESSION['redirect_url'] ?? 'index.php'
            ];
            
        } catch (Exception $e) {
            log_message("Erro no login: " . $e->getMessage(), 'ERROR');
            return ['success' => false, 'error' => 'Erro ao fazer login'];
        }
    }
    
    public function logout() {
        // Destruir sessão
        session_destroy();
        
        // Limpar cookie "lembrar de mim"
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/');
        }
        
        return ['success' => true, 'redirect' => 'index.php'];
    }
    
    public function checkSession() {
        // Verificar sessão
        if (isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0) {
            return true;
        }
        
        // Verificar cookie "lembrar de mim"
        if (isset($_COOKIE['remember_token'])) {
            return $this->validateRememberToken($_COOKIE['remember_token']);
        }
        
        return false;
    }
    
    public function getUserInfo($userId = null) {
        try {
            $userId = $userId ?: $_SESSION['user_id'];
            
            $stmt = $this->conn->prepare("
                SELECT id, username, email, phone, avatar, role, plan, 
                       storage_limit, storage_used, process_count,
                       last_login, created_at
                FROM users 
                WHERE id = ?
            ");
            
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                
                // Calcular uso de armazenamento
                $user['storage_percentage'] = $user['storage_limit'] > 0 ? 
                    round(($user['storage_used'] / $user['storage_limit']) * 100, 2) : 0;
                
                // Formatar datas
                $user['last_login_formatted'] = $user['last_login'] ? 
                    date('d/m/Y H:i', strtotime($user['last_login'])) : 'Nunca';
                $user['created_at_formatted'] = date('d/m/Y', strtotime($user['created_at']));
                
                $stmt->close();
                return $user;
            }
            
            $stmt->close();
            return null;
            
        } catch (Exception $e) {
            log_message("Erro ao obter informações do usuário: " . $e->getMessage(), 'ERROR');
            return null;
        }
    }
    
    private function validateRegistration($data) {
        $errors = [];
        
        // Username
        if (empty($data['username'])) {
            $errors['username'] = 'Nome de usuário é obrigatório';
        } elseif (strlen($data['username']) < 3) {
            $errors['username'] = 'Nome de usuário deve ter pelo menos 3 caracteres';
        } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $data['username'])) {
            $errors['username'] = 'Nome de usuário só pode conter letras, números e underline';
        }
        
        // Email
        if (empty($data['email'])) {
            $errors['email'] = 'Email é obrigatório';
        } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Email inválido';
        }
        
        // Password
        if (empty($data['password'])) {
            $errors['password'] = 'Senha é obrigatória';
        } elseif (strlen($data['password']) < 6) {
            $errors['password'] = 'Senha deve ter pelo menos 6 caracteres';
        } elseif ($data['password'] !== $data['confirm_password']) {
            $errors['confirm_password'] = 'As senhas não coincidem';
        }
        
        // Phone (opcional)
        if (!empty($data['phone']) && !preg_match('/^[0-9+\-\s\(\)]{10,20}$/', $data['phone'])) {
            $errors['phone'] = 'Telefone inválido';
        }
        
        return $errors;
    }
    
    private function emailExists($email) {
        $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        return $exists;
    }
    
    private function usernameExists($username) {
        $stmt = $this->conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        return $exists;
    }
    
    private function createSession($userId, $username, $role = 'user') {
        $_SESSION['user_id'] = $userId;
        $_SESSION['username'] = $username;
        $_SESSION['user_role'] = $role;
        $_SESSION['logged_in'] = true;
        $_SESSION['login_time'] = time();
        
        // Regenerar ID da sessão
        session_regenerate_id(true);
    }
    
    private function updateLastLogin($userId) {
        $stmt = $this->conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->close();
    }
    
    private function setRememberMeCookie($userId) {
        $token = bin2hex(random_bytes(32));
        $expires = time() + (30 * 24 * 3600); // 30 dias
        
        // Salvar token no banco
        $stmt = $this->conn->prepare("
            INSERT INTO user_sessions (user_id, token, expires_at) 
            VALUES (?, ?, FROM_UNIXTIME(?))
        ");
        $stmt->bind_param("isi", $userId, $token, $expires);
        $stmt->execute();
        $stmt->close();
        
        // Definir cookie
        setcookie('remember_token', $token, $expires, '/', '', true, true);
    }
    
    private function validateRememberToken($token) {
        $stmt = $this->conn->prepare("
            SELECT u.id, u.username, u.role 
            FROM user_sessions s
            JOIN users u ON s.user_id = u.id
            WHERE s.token = ? AND s.expires_at > NOW() AND u.status = 'active'
        ");
        
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Criar sessão
            $this->createSession($user['id'], $user['username'], $user['role']);
            
            // Atualizar último login
            $this->updateLastLogin($user['id']);
            
            $stmt->close();
            return true;
        }
        
        $stmt->close();
        return false;
    }
    
    private function logFailedAttempt($userId) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $stmt = $this->conn->prepare("
            INSERT INTO login_attempts (user_id, ip_address, user_agent) 
            VALUES (?, ?, ?)
        ");
        $stmt->bind_param("iss", $userId, $ip, $userAgent);
        $stmt->execute();
        $stmt->close();
        
        // Verificar se deve bloquear
        $this->checkAndBlockUser($userId);
    }
    
    private function clearFailedAttempts($userId) {
        $stmt = $this->conn->prepare("DELETE FROM login_attempts WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->close();
    }
    
    private function checkAndBlockUser($userId) {
        // Contar tentativas recentes
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as attempts 
            FROM login_attempts 
            WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        // Bloquear se mais de 5 tentativas
        if ($result['attempts'] >= 5) {
            $stmt = $this->conn->prepare("UPDATE users SET status = 'suspended' WHERE id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $stmt->close();
            
            log_message("Usuário $userId suspenso por muitas tentativas falhas de login");
        }
    }
    
    private function sendVerificationEmail($email, $token) {
        // Implementação do envio de email
        // Usar PHPMailer, SwiftMailer ou serviço externo
    }
    
    public function changePassword($userId, $currentPassword, $newPassword) {
        try {
            // Verificar senha atual
            $stmt = $this->conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                return ['success' => false, 'error' => 'Usuário não encontrado'];
            }
            
            $user = $result->fetch_assoc();
            
            if (!password_verify($currentPassword, $user['password'])) {
                return ['success' => false, 'error' => 'Senha atual incorreta'];
            }
            
            $stmt->close();
            
            // Atualizar senha
            $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
            
            $stmt = $this->conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashedPassword, $userId);
            $stmt->execute();
            $stmt->close();
            
            log_message("Senha alterada para usuário $userId");
            
            return ['success' => true, 'message' => 'Senha alterada com sucesso'];
            
        } catch (Exception $e) {
            log_message("Erro ao alterar senha: " . $e->getMessage(), 'ERROR');
            return ['success' => false, 'error' => 'Erro ao alterar senha'];
        }
    }
    
    public function resetPasswordRequest($email) {
        try {
            // Verificar se email existe
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                // Por segurança, não revelar que o email não existe
                return ['success' => true, 'message' => 'Se o email existir, enviaremos instruções'];
            }
            
            $user = $result->fetch_assoc();
            $stmt->close();
            
            // Gerar token de reset
            $resetToken = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600); // Expira em 1 hora
            
            // Salvar token
            $stmt = $this->conn->prepare("
                UPDATE users 
                SET reset_token = ?, reset_expires = ? 
                WHERE id = ?
            ");
            $stmt->bind_param("ssi", $resetToken, $expires, $user['id']);
            $stmt->execute();
            $stmt->close();
            
            // Enviar email com link de reset
            $resetLink = APP_URL . "/reset_password.php?token=" . $resetToken;
            
            // TODO: Implementar envio de email
            // $this->sendResetEmail($email, $resetLink);
            
            log_message("Solicitação de reset de senha para: $email");
            
            return ['success' => true, 'message' => 'Instruções enviadas para seu email'];
            
        } catch (Exception $e) {
            log_message("Erro na solicitação de reset: " . $e->getMessage(), 'ERROR');
            return ['success' => false, 'error' => 'Erro ao processar solicitação'];
        }
    }
    
    public function resetPassword($token, $newPassword) {
        try {
            // Verificar token
            $stmt = $this->conn->prepare("
                SELECT id FROM users 
                WHERE reset_token = ? AND reset_expires > NOW()
            ");
            $stmt->bind_param("s", $token);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                return ['success' => false, 'error' => 'Token inválido ou expirado'];
            }
            
            $user = $result->fetch_assoc();
            $stmt->close();
            
            // Atualizar senha
            $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
            
            $stmt = $this->conn->prepare("
                UPDATE users 
                SET password = ?, reset_token = NULL, reset_expires = NULL 
                WHERE id = ?
            ");
            $stmt->bind_param("si", $hashedPassword, $user['id']);
            $stmt->execute();
            $stmt->close();
            
            log_message("Senha resetada via token para usuário {$user['id']}");
            
            return ['success' => true, 'message' => 'Senha alterada com sucesso'];
            
        } catch (Exception $e) {
            log_message("Erro ao resetar senha: " . $e->getMessage(), 'ERROR');
            return ['success' => false, 'error' => 'Erro ao resetar senha'];
        }
    }
    
    public function updateProfile($userId, $data) {
        try {
            $allowedFields = ['username', 'phone', 'avatar'];
            $updates = [];
            $params = [];
            $types = '';
            
            foreach ($data as $field => $value) {
                if (in_array($field, $allowedFields) && $value !== null) {
                    $updates[] = "$field = ?";
                    $params[] = $value;
                    $types .= 's';
                }
            }
            
            if (empty($updates)) {
                return ['success' => false, 'error' => 'Nenhum dado para atualizar'];
            }
            
            // Verificar se username já existe (se for atualizado)
            if (isset($data['username']) && $data['username'] !== $_SESSION['username']) {
                if ($this->usernameExists($data['username'])) {
                    return ['success' => false, 'error' => 'Este nome de usuário já está em uso'];
                }
            }
            
            $params[] = $userId;
            $types .= 'i';
            
            $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                // Atualizar sessão se username foi alterado
                if (isset($data['username'])) {
                    $_SESSION['username'] = $data['username'];
                }
                
                log_message("Perfil atualizado para usuário $userId");
                return ['success' => true, 'message' => 'Perfil atualizado com sucesso'];
            } else {
                return ['success' => false, 'error' => 'Nenhuma alteração realizada'];
            }
            
        } catch (Exception $e) {
            log_message("Erro ao atualizar perfil: " . $e->getMessage(), 'ERROR');
            return ['success' => false, 'error' => 'Erro ao atualizar perfil'];
        }
    }
}

// Instância global do Auth
$auth = new Auth();

// Verificar autenticação automática
if (!$auth->checkSession() && !defined('PUBLIC_PAGE')) {
    // Redirecionar para login se não estiver em página pública
    $current_page = basename($_SERVER['PHP_SELF']);
    $public_pages = ['index.php', 'login.php', 'register.php', 'reset_password.php'];
    
    if (!in_array($current_page, $public_pages)) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        redirect('login.php');
    }
}
?>