const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegStatic = require('ffmpeg-static');

// Configurar caminho do ffmpeg
ffmpeg.setFfmpegPath(ffmpegStatic);

class AudioProcessor {
  constructor() {
    this.uploadsDir = path.join(__dirname, '..', 'uploads');
    this.ensureUploadsDir();
  }

  ensureUploadsDir() {
    if (!fs.existsSync(this.uploadsDir)) {
      fs.mkdirSync(this.uploadsDir, { recursive: true });
    }
  }

  // Método principal para processar áudio do YouTube
  async processYouTubeAudio(youtubeUrl, quality = 128, jobId) {
    const jobDir = path.join(this.uploadsDir, jobId);
    fs.mkdirSync(jobDir, { recursive: true });

    try {
      // 1. Baixar áudio usando ytdl-core
      const audioPath = await this.downloadAudio(youtubeUrl, quality, jobDir);
      
      // 2. Detectar silêncios
      const silencePoints = await this.detectSilences(audioPath, jobDir);
      
      // 3. Separar por silêncios
      const tracks = await this.splitBySilences(audioPath, silencePoints, jobDir, quality);
      
      // 4. Gerar arquivo ZIP (opcional)
      const zipPath = await this.createZip(jobDir, jobId);
      
      return {
        success: true,
        jobId,
        tracks,
        zipPath,
        totalTracks: tracks.length
      };
      
    } catch (error) {
      console.error('Erro no processamento:', error);
      throw error;
    }
  }

  // Baixar áudio do YouTube
  async downloadAudio(url, quality, outputDir) {
    return new Promise((resolve, reject) => {
      const ytdl = require('ytdl-core');
      const outputPath = path.join(outputDir, 'audio.mp3');
      
      const stream = ytdl(url, {
        filter: 'audioonly',
        quality: 'highestaudio'
      });
      
      const writeStream = fs.createWriteStream(outputPath);
      
      stream.pipe(writeStream);
      
      stream.on('progress', (chunkLength, downloaded, total) => {
        const percent = downloaded / total;
        console.log(`Download: ${(percent * 100).toFixed(2)}%`);
      });
      
      stream.on('end', () => {
        console.log('✅ Download concluído');
        resolve(outputPath);
      });
      
      stream.on('error', reject);
    });
  }

  // Detectar silêncios usando ffmpeg
  async detectSilences(audioPath, outputDir) {
    return new Promise((resolve, reject) => {
      const silenceData = [];
      
      ffmpeg(audioPath)
        .audioFilters('silencedetect=noise=-30dB:d=1.5')
        .output(path.join(outputDir, 'silence_analysis.txt'))
        .on('start', (command) => {
          console.log('Comando FFmpeg:', command);
        })
        .on('stderr', (stderrLine) => {
          // Extrair tempos de silêncio da saída
          const silenceMatch = stderrLine.match(/silence_(start|end): (\d+\.\d+)/);
          if (silenceMatch) {
            const type = silenceMatch[1];
            const time = parseFloat(silenceMatch[2]);
            silenceData.push({ type, time });
          }
        })
        .on('end', () => {
          console.log('✅ Análise de silêncios concluída');
          resolve(this.parseSilenceData(silenceData));
        })
        .on('error', reject)
        .run();
    });
  }

  // Processar dados de silêncio
  parseSilenceData(silenceData) {
    const segments = [];
    let currentStart = 0;
    
    for (let i = 0; i < silenceData.length; i += 2) {
      if (silenceData[i]?.type === 'start' && silenceData[i+1]?.type === 'end') {
        const end = silenceData[i].time;
        const duration = end - currentStart;
        
        if (duration > 2) { // Mínimo 2 segundos por faixa
          segments.push({
            start: currentStart,
            end: end,
            duration: duration
          });
        }
        
        currentStart = silenceData[i+1].time;
      }
    }
    
    console.log(`📊 ${segments.length} segmentos detectados`);
    return segments;
  }

  // Separar áudio nos pontos de silêncio
  async splitBySilences(audioPath, segments, outputDir, quality) {
    const tracks = [];
    
    for (let i = 0; i < segments.length; i++) {
      const segment = segments[i];
      const trackNum = (i + 1).toString().padStart(2, '0');
      const outputPath = path.join(outputDir, `track_${trackNum}.mp3`);
      
      await this.extractSegment(audioPath, segment.start, segment.duration, outputPath, quality);
      
      tracks.push({
        number: trackNum,
        path: outputPath,
        filename: `track_${trackNum}.mp3`,
        start: segment.start,
        duration: segment.duration
      });
      
      console.log(`✅ Faixa ${trackNum} criada`);
    }
    
    return tracks;
  }

  // Extrair segmento de áudio
  extractSegment(inputPath, start, duration, outputPath, quality) {
    return new Promise((resolve, reject) => {
      ffmpeg(inputPath)
        .setStartTime(start)
        .setDuration(duration)
        .audioBitrate(`${quality}k`)
        .audioCodec('libmp3lame')
        .output(outputPath)
        .on('end', resolve)
        .on('error', reject)
        .run();
    });
  }

  // Criar ZIP com todas as faixas
  async createZip(jobDir, jobId) {
    const archiver = require('archiver');
    const zipPath = path.join(this.uploadsDir, `${jobId}.zip`);
    
    return new Promise((resolve, reject) => {
      const output = fs.createWriteStream(zipPath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      output.on('close', () => {
        console.log(`📦 ZIP criado: ${archive.pointer()} bytes`);
        resolve(zipPath);
      });
      
      archive.on('error', reject);
      archive.pipe(output);
      
      // Adicionar todas as faixas MP3
      const mp3Files = fs.readdirSync(jobDir)
        .filter(file => file.endsWith('.mp3') && file.startsWith('track_'));
      
      mp3Files.forEach(file => {
        archive.file(path.join(jobDir, file), { name: file });
      });
      
      archive.finalize();
    });
  }
}

module.exports = new AudioProcessor();
