/**
 * YouTube Audio Extractor Pro - Utilitários
 * Arquivo: js/utils.js
 * Funções utilitárias reutilizáveis
 */

/**
 * Formatar bytes para tamanho legível
 */
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/**
 * Formatar duração em segundos para MM:SS ou HH:MM:SS
 */
function formatDuration(seconds) {
    if (!seconds && seconds !== 0) return 'N/A';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }
}

/**
 * Formatar número com separadores de milhar
 */
function formatNumber(num) {
    if (!num && num !== 0) return 'N/A';
    return new Intl.NumberFormat('pt-BR').format(num);
}

/**
 * Formatar data para formato brasileiro
 */
function formatDate(dateString, includeTime = false) {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    
    if (includeTime) {
        return date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR', {
            hour: '2-digit',
            minute: '2-digit'
        });
    } else {
        return date.toLocaleDateString('pt-BR');
    }
}

/**
 * Formatar data relativa (ex: "há 2 dias")
 */
function formatRelativeTime(dateString) {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffSecs < 60) {
        return 'agora mesmo';
    } else if (diffMins < 60) {
        return `há ${diffMins} minuto${diffMins > 1 ? 's' : ''}`;
    } else if (diffHours < 24) {
        return `há ${diffHours} hora${diffHours > 1 ? 's' : ''}`;
    } else if (diffDays < 7) {
        return `há ${diffDays} dia${diffDays > 1 ? 's' : ''}`;
    } else {
        return formatDate(dateString);
    }
}

/**
 * Validar URL do YouTube
 */
function isValidYouTubeUrl(url) {
    if (!url) return false;
    
    const youtubePatterns = [
        /^(https?:\/\/)?(www\.)?youtube\.com\/watch\?v=[\w-]{11}/,
        /^(https?:\/\/)?(www\.)?youtu\.be\/[\w-]{11}/,
        /^(https?:\/\/)?(www\.)?youtube\.com\/playlist\?list=[\w-]+/,
        /^(https?:\/\/)?(www\.)?youtube\.com\/shorts\/[\w-]{11}/,
        /^(https?:\/\/)?(www\.)?youtube\.com\/embed\/[\w-]{11}/
    ];
    
    return youtubePatterns.some(pattern => pattern.test(url.trim()));
}

/**
 * Extrair ID do vídeo do YouTube
 */
function extractYouTubeVideoId(url) {
    if (!url) return null;
    
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/|youtube\.com\/shorts\/)([\w-]{11})/,
        /^[\w-]{11}$/
    ];
    
    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match && match[1]) {
            return match[1];
        }
    }
    
    return null;
}

/**
 * Extrair ID da playlist do YouTube
 */
function extractYouTubePlaylistId(url) {
    if (!url) return null;
    
    const pattern = /list=([\w-]+)/;
    const match = url.match(pattern);
    
    return match ? match[1] : null;
}

/**
 * Debounce function para otimizar eventos
 */
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const context = this;
        const later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
}

/**
 * Throttle function para limitar execução
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Copiar texto para clipboard
 */
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    } catch (err) {
        console.error('Falha ao copiar: ', err);
        
        // Fallback para navegadores antigos
        try {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            document.execCommand('copy');
            textArea.remove();
            return true;
        } catch (err2) {
            console.error('Fallback também falhou: ', err2);
            return false;
        }
    }
}

/**
 * Gerar ID único
 */
function generateId(prefix = '') {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 9);
    return `${prefix}${timestamp}_${random}`;
}

/**
 * Armazenar dados no localStorage com expiração
 */
function setLocalStorage(key, value, ttlMinutes = 60) {
    const data = {
        value: value,
        expires: Date.now() + (ttlMinutes * 60 * 1000)
    };
    localStorage.setItem(key, JSON.stringify(data));
}

/**
 * Recuperar dados do localStorage com verificação de expiração
 */
function getLocalStorage(key) {
    const item = localStorage.getItem(key);
    if (!item) return null;
    
    try {
        const data = JSON.parse(item);
        if (data.expires && Date.now() > data.expires) {
            localStorage.removeItem(key);
            return null;
        }
        return data.value;
    } catch (error) {
        console.error('Erro ao ler localStorage:', error);
        return null;
    }
}

/**
 * Remover dados expirados do localStorage
 */
function cleanupExpiredLocalStorage() {
    const keys = Object.keys(localStorage);
    keys.forEach(key => {
        if (key.startsWith('cache_') || key.includes('_expires')) {
            getLocalStorage(key); // Isso remove automaticamente se expirado
        }
    });
}

/**
 * Verificar conexão com internet
 */
function isOnline() {
    return navigator.onLine;
}

/**
 * Monitorar status da conexão
 */
function monitorConnectionStatus(callback) {
    window.addEventListener('online', () => callback(true));
    window.addEventListener('offline', () => callback(false));
    
    // Retornar status inicial
    return isOnline();
}

/**
 * Fazer download de arquivo
 */
function downloadFile(url, filename) {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

/**
 * Fazer download de blob
 */
function downloadBlob(blob, filename) {
    const url = window.URL.createObjectURL(blob);
    downloadFile(url, filename);
    window.URL.revokeObjectURL(url);
}

/**
 * Converter blob para base64
 */
function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}

/**
 * Converter base64 para blob
 */
function base64ToBlob(base64, contentType = '') {
    const byteCharacters = atob(base64.split(',')[1]);
    const byteArrays = [];
    
    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
        const slice = byteCharacters.slice(offset, offset + 512);
        
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        
        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }
    
    return new Blob(byteArrays, { type: contentType });
}

/**
 * Comprimir string para URL segura
 */
function compressForUrl(str) {
    return btoa(encodeURIComponent(str)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/**
 * Descomprimir string de URL
 */
function decompressFromUrl(str) {
    str = str.replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) {
        str += '=';
    }
    return decodeURIComponent(atob(str));
}

/**
 * Sanitizar HTML para prevenir XSS
 */
function sanitizeHTML(html) {
    const temp = document.createElement('div');
    temp.textContent = html;
    return temp.innerHTML;
}

/**
 * Validar email
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Validar telefone brasileiro
 */
function isValidBrazilianPhone(phone) {
    const cleaned = phone.replace(/\D/g, '');
    
    // Deve ter 10 ou 11 dígitos (com DDD)
    if (cleaned.length < 10 || cleaned.length > 11) {
        return false;
    }
    
    // DDD válido (11-99)
    const ddd = parseInt(cleaned.substring(0, 2));
    if (ddd < 11 || ddd > 99) {
        return false;
    }
    
    return true;
}

/**
 * Formatar telefone enquanto digita
 */
function formatPhoneInput(input) {
    let value = input.value.replace(/\D/g, '');
    
    if (value.length > 0) {
        value = '(' + value;
    }
    
    if (value.length > 3) {
        value = value.substring(0, 3) + ') ' + value.substring(3);
    }
    
    if (value.length > 10) {
        value = value.substring(0, 10) + '-' + value.substring(10);
    }
    
    if (value.length > 15) {
        value = value.substring(0, 15);
    }
    
    input.value = value;
}

/**
 * Verificar força da senha
 */
function checkPasswordStrength(password) {
    let strength = 0;
    let messages = [];
    
    // Comprimento mínimo
    if (password.length >= 8) {
        strength += 25;
    } else {
        messages.push('Mínimo 8 caracteres');
    }
    
    // Letra maiúscula
    if (/[A-Z]/.test(password)) {
        strength += 25;
    } else {
        messages.push('Pelo menos uma letra maiúscula');
    }
    
    // Número
    if (/[0-9]/.test(password)) {
        strength += 25;
    } else {
        messages.push('Pelo menos um número');
    }
    
    // Caractere especial
    if (/[^A-Za-z0-9]/.test(password)) {
        strength += 25;
    } else {
        messages.push('Pelo menos um caractere especial');
    }
    
    return {
        score: strength,
        level: strength <= 25 ? 'Muito Fraca' :
               strength <= 50 ? 'Fraca' :
               strength <= 75 ? 'Boa' : 'Forte',
        color: strength <= 25 ? '#ff4757' :
               strength <= 50 ? '#ffa502' :
               strength <= 75 ? '#2ed573' : '#00bfff',
        messages: messages
    };
}

/**
 * Gerar cor baseada em string (para avatares)
 */
function stringToColor(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    const colors = [
        '#00BFFF', '#1E90FF', '#4169E1', // Azuis
        '#FFD700', '#FFA500', '#FF8C00', // Amarelos/Laranjas
        '#2ED573', '#32CD32', '#228B22', // Verdes
        '#8A2BE2', '#9370DB', '#9932CC'  // Roxos
    ];
    
    return colors[Math.abs(hash) % colors.length];
}

/**
 * Gerar iniciais para avatar
 */
function getInitials(name) {
    if (!name) return '?';
    
    return name
        .split(' ')
        .map(part => part.charAt(0))
        .join('')
        .toUpperCase()
        .substring(0, 2);
}

/**
 * Animação de contagem
 */
function animateCounter(element, target, duration = 1000) {
    const start = parseInt(element.textContent) || 0;
    const increment = target > start ? 1 : -1;
    const steps = Math.abs(target - start);
    const stepTime = Math.abs(duration / steps);
    
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        element.textContent = current;
        
        if (current === target) {
            clearInterval(timer);
        }
    }, stepTime);
}

/**
 * Detecta se é dispositivo móvel
 */
function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

/**
 * Detecta se é dispositivo touch
 */
function isTouchDevice() {
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
}

/**
 * Prevenir scroll em dispositivos móveis quando modal está aberto
 */
function preventBodyScroll(prevent) {
    if (prevent) {
        document.body.style.overflow = 'hidden';
        document.body.style.height = '100%';
    } else {
        document.body.style.overflow = '';
        document.body.style.height = '';
    }
}

/**
 * Formatar moeda brasileira
 */
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

/**
 * Calcular diferença entre datas
 */
function dateDiff(startDate, endDate = new Date()) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffMs = end - start;
    
    const seconds = Math.floor(diffMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    return { days, hours: hours % 24, minutes: minutes % 60, seconds: seconds % 60 };
}

/**
 * Delay promise
 */
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Retry promise com backoff exponencial
 */
async function retryWithBackoff(fn, maxRetries = 3, baseDelay = 1000) {
    let lastError;
    
    for (let i = 0; i < maxRetries; i++) {
        try {
            return await fn();
        } catch (error) {
            lastError = error;
            
            if (i < maxRetries - 1) {
                const delay = baseDelay * Math.pow(2, i);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }
    
    throw lastError;
}

/**
 * Agrupar array por propriedade
 */
function groupBy(array, key) {
    return array.reduce((groups, item) => {
        const val = item[key];
        groups[val] = groups[val] || [];
        groups[val].push(item);
        return groups;
    }, {});
}

/**
 * Ordenar array por propriedade
 */
function sortBy(array, key, descending = false) {
    return [...array].sort((a, b) => {
        let valA = a[key];
        let valB = b[key];
        
        // Converter para número se possível
        if (!isNaN(valA) && !isNaN(valB)) {
            valA = parseFloat(valA);
            valB = parseFloat(valB);
        }
        
        if (valA < valB) return descending ? 1 : -1;
        if (valA > valB) return descending ? -1 : 1;
        return 0;
    });
}

/**
 * Filtrar array por múltiplos critérios
 */
function filterBy(array, filters) {
    return array.filter(item => {
        return Object.entries(filters).every(([key, value]) => {
            if (typeof value === 'function') {
                return value(item[key]);
            } else if (Array.isArray(value)) {
                return value.includes(item[key]);
            } else {
                return item[key] === value;
            }
        });
    });
}

/**
 * Gerar UUID v4
 */
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Exportar todas as funções para uso global
window.Utils = {
    formatBytes,
    formatDuration,
    formatNumber,
    formatDate,
    formatRelativeTime,
    isValidYouTubeUrl,
    extractYouTubeVideoId,
    extractYouTubePlaylistId,
    debounce,
    throttle,
    copyToClipboard,
    generateId,
    setLocalStorage,
    getLocalStorage,
    cleanupExpiredLocalStorage,
    isOnline,
    monitorConnectionStatus,
    downloadFile,
    downloadBlob,
    blobToBase64,
    base64ToBlob,
    compressForUrl,
    decompressFromUrl,
    sanitizeHTML,
    isValidEmail,
    isValidBrazilianPhone,
    formatPhoneInput,
    checkPasswordStrength,
    stringToColor,
    getInitials,
    animateCounter,
    isMobileDevice,
    isTouchDevice,
    preventBodyScroll,
    formatCurrency,
    dateDiff,
    delay,
    retryWithBackoff,
    groupBy,
    sortBy,
    filterBy,
    generateUUID
};

// Inicializar utilitários
document.addEventListener('DOMContentLoaded', function() {
    console.log('🛠️ Utilitários - Carregados');
    
    // Limpar localStorage expirado
    cleanupExpiredLocalStorage();
    
    // Adicionar evento para limpeza periódica
    setInterval(cleanupExpiredLocalStorage, 60000); // A cada minuto
});