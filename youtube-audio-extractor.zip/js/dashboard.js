/**
 * YouTube Audio Extractor Pro - Dashboard
 * Arquivo: js/dashboard.js
 * Responsável pelo dashboard do usuário
 */

// Estado do dashboard
const DashboardState = {
    stats: null,
    recentVideos: [],
    isLoading: false
};

// Aguardar DOM carregar
document.addEventListener('DOMContentLoaded', function() {
    console.log('📊 Dashboard - Carregado');
    
    // Verificar autenticação
    if (!Auth.requireAuth()) {
        return;
    }
    
    // Inicializar dashboard
    initDashboard();
    
    // Carregar dados
    loadDashboardData();
    
    // Configurar eventos
    setupDashboardEvents();
    
    // Inicializar gráficos
    initCharts();
});

/**
 * Inicializar dashboard
 */
function initDashboard() {
    // Atualizar informações do usuário
    updateUserInfo();
    
    // Configurar menu mobile se existir
    initDashboardMenu();
    
    // Configurar tooltips
    initDashboardTooltips();
    
    // Configurar atualização automática
    startAutoRefresh();
}

/**
 * Atualizar informações do usuário
 */
function updateUserInfo() {
    const user = Auth.getUserData();
    if (!user) return;
    
    // Atualizar elementos com dados do usuário
    document.querySelectorAll('#userName, #username').forEach(el => {
        if (el) el.textContent = user.username || 'Usuário';
    });
    
    document.querySelectorAll('#userEmail').forEach(el => {
        if (el) el.textContent = user.email || '';
    });
    
    // Atualizar avatar se existir
    const avatarElements = document.querySelectorAll('.user-avatar, .user-btn i');
    if (user.avatar_url) {
        avatarElements.forEach(el => {
            if (el.tagName === 'IMG') {
                el.src = user.avatar_url;
            } else if (el.tagName === 'I') {
                el.style.display = 'none';
                el.parentElement.innerHTML = `<img src="${user.avatar_url}" alt="${user.username}" style="width:100%;height:100%;border-radius:50%;">`;
            }
        });
    }
}

/**
 * Configurar eventos do dashboard
 */
function setupDashboardEvents() {
    // Evento de logout
    const logoutBtn = document.querySelector('.logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', Auth.logout);
    }
    
    // Evento de upgrade premium
    const upgradeBtn = document.querySelector('.btn-premium');
    if (upgradeBtn) {
        upgradeBtn.addEventListener('click', showPremiumModal);
    }
    
    // Evento de ver todos os vídeos
    const viewAllBtn = document.querySelector('.btn-link');
    if (viewAllBtn && viewAllBtn.href.includes('videos.html')) {
        viewAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'videos.html';
        });
    }
    
    // Eventos dos cards de ação
    document.querySelectorAll('.action-card').forEach(card => {
        card.addEventListener('click', function(e) {
            if (!this.href) {
                e.preventDefault();
                const title = this.querySelector('h3').textContent;
                handleActionCardClick(title);
            }
        });
    });
    
    // Evento de refresh manual
    const refreshBtn = document.querySelector('[onclick*="refreshDashboard"]');
    if (refreshBtn) {
        refreshBtn.onclick = refreshDashboard;
    }
}

/**
 * Carregar dados do dashboard
 */
async function loadDashboardData() {
    if (DashboardState.isLoading) return;
    
    DashboardState.isLoading = true;
    showLoadingState();
    
    try {
        // Carregar dados em paralelo
        const [statsData, videosData, limitsData] = await Promise.allSettled([
            fetch('/api/dashboard/stats', {
                headers: { 'Authorization': `Bearer ${Auth.getAuthToken()}` }
            }).then(res => res.json()),
            
            fetch('/api/videos/recent?limit=4', {
                headers: { 'Authorization': `Bearer ${Auth.getAuthToken()}` }
            }).then(res => res.json()),
            
            fetch('/api/user/limits', {
                headers: { 'Authorization': `Bearer ${Auth.getAuthToken()}` }
            }).then(res => res.json())
        ]);
        
        // Processar estatísticas
        if (statsData.status === 'fulfilled' && statsData.value.success) {
            DashboardState.stats = statsData.value.stats;
            updateStatsDisplay();
        }
        
        // Processar vídeos recentes
        if (videosData.status === 'fulfilled' && videosData.value.success) {
            DashboardState.recentVideos = videosData.value.videos;
            updateRecentVideosDisplay();
        }
        
        // Processar limites
        if (limitsData.status === 'fulfilled' && limitsData.value.success) {
            updateLimitsDisplay(limitsData.value);
        }
        
        // Atualizar gráficos
        updateCharts();
        
    } catch (error) {
        console.error('Erro ao carregar dados do dashboard:', error);
        showError('Erro ao carregar dados. Tente recarregar a página.');
    } finally {
        DashboardState.isLoading = false;
        hideLoadingState();
    }
}

/**
 * Atualizar display das estatísticas
 */
function updateStatsDisplay() {
    if (!DashboardState.stats) return;
    
    const { totalVideos = 0, totalTracks = 0, totalDownloads = 0 } = DashboardState.stats;
    
    // Atualizar contadores
    document.getElementById('totalVideos').textContent = totalVideos;
    document.getElementById('totalTracks').textContent = totalTracks;
    document.getElementById('totalDownloads').textContent = totalDownloads;
    
    // Atualizar texto de boas-vindas se for o primeiro vídeo
    if (totalVideos === 0) {
        const welcomeText = document.querySelector('.welcome-content p');
        if (welcomeText) {
            welcomeText.textContent = 'Você ainda não processou nenhum vídeo. Comece agora!';
        }
    }
}

/**
 * Atualizar display de vídeos recentes
 */
function updateRecentVideosDisplay() {
    const container = document.getElementById('recentVideos');
    if (!container) return;
    
    const videos = DashboardState.recentVideos;
    
    if (videos.length === 0) {
        container.innerHTML = `
            <div class="empty-state metal-card">
                <i class="fas fa-video-slash"></i>
                <h3>Nenhum vídeo processado ainda</h3>
                <p>Comece extraindo áudio de um vídeo do YouTube</p>
                <a href="extractor.html" class="btn btn-primary">Extrair Áudio</a>
            </div>
        `;
        return;
    }
    
    let html = '';
    
    videos.forEach(video => {
        const formattedDate = formatDate(video.created_at);
        const formattedDuration = video.duration ? formatDuration(video.duration) : 'N/A';
        
        html += `
            <div class="video-card metal-card" data-video-id="${video.id}">
                <div class="video-thumb">
                    <img src="${video.thumbnail || 'https://via.placeholder.com/300x180/2a2a2a/666?text=No+Thumbnail'}" 
                         alt="${video.title}" 
                         onerror="this.src='https://via.placeholder.com/300x180/2a2a2a/666?text=No+Thumbnail'">
                    <div class="video-status ${video.status}">
                        ${getStatusText(video.status)}
                    </div>
                </div>
                <div class="video-info">
                    <h4 title="${video.title}">${truncateText(video.title, 50)}</h4>
                    <div class="video-meta">
                        <span><i class="fas fa-clock"></i> ${formattedDuration}</span>
                        <span><i class="fas fa-music"></i> ${video.tracks_count || 0} faixas</span>
                    </div>
                    <div class="video-date">
                        <i class="fas fa-calendar"></i> ${formattedDate}
                    </div>
                    <div class="video-actions">
                        <button class="btn btn-small" onclick="viewVideoDetails('${video.id}')" 
                                title="Ver detalhes">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${video.status === 'completed' ? `
                        <button class="btn btn-small" onclick="downloadVideoResults('${video.id}')" 
                                title="Baixar resultados">
                            <i class="fas fa-download"></i>
                        </button>
                        ` : ''}
                        <button class="btn btn-small" onclick="deleteVideo('${video.id}')" 
                                title="Excluir vídeo">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // Adicionar efeitos hover
    initVideoCardHovers();
}

/**
 * Atualizar display de limites
 */
function updateLimitsDisplay(limits) {
    // Atualizar barras de progresso
    const limitElements = document.querySelectorAll('.limit-fill');
    
    if (limitElements[0] && limits.daily_videos) {
        const { current, max } = limits.daily_videos;
        const percent = Math.min((current / max) * 100, 100);
        limitElements[0].style.width = `${percent}%`;
        
        // Atualizar texto
        const limitText = limitElements[0].closest('.limit-item').querySelector('p');
        if (limitText) {
            limitText.textContent = `${current}/${max} processamentos`;
        }
    }
    
    if (limitElements[1] && limits.total_downloads) {
        const { current, max } = limits.total_downloads;
        const percent = Math.min((current / max) * 100, 100);
        limitElements[1].style.width = `${percent}%`;
        
        // Atualizar texto
        const limitText = limitElements[1].closest('.limit-item').querySelector('p');
        if (limitText) {
            limitText.textContent = `${current}/${max} downloads`;
        }
    }
}

/**
 * Inicializar gráficos
 */
function initCharts() {
    // Gráfico de barras (uso mensal)
    initMonthlyUsageChart();
    
    // Gráfico de pizza (formatos preferidos)
    initFormatsPieChart();
}

/**
 * Inicializar gráfico de uso mensal
 */
function initMonthlyUsageChart() {
    const chartContainer = document.querySelector('.chart-bar');
    if (!chartContainer) return;
    
    // Dados de exemplo (serão substituídos por dados reais)
    const monthlyData = [60, 80, 45, 90, 75, 65, 85, 70, 55, 95, 80, 65];
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    
    chartContainer.innerHTML = '';
    
    monthlyData.forEach((value, index) => {
        const bar = document.createElement('div');
        bar.style.height = `${value}%`;
        bar.setAttribute('data-value', value);
        bar.setAttribute('data-month', months[index]);
        bar.title = `${months[index]}: ${value}%`;
        
        // Adicionar gradiente baseado no valor
        if (value >= 80) {
            bar.style.background = 'linear-gradient(to top, #ff4757, #ff6b81)';
        } else if (value >= 50) {
            bar.style.background = 'linear-gradient(to top, #ffa502, #ffbe76)';
        } else {
            bar.style.background = 'linear-gradient(to top, #2ed573, #7bed9f)';
        }
        
        chartContainer.appendChild(bar);
    });
}

/**
 * Inicializar gráfico de pizza de formatos
 */
function initFormatsPieChart() {
    const pieChart = document.querySelector('.pie-chart');
    if (!pieChart) return;
    
    // Dados de exemplo (serão substituídos por dados reais)
    const formats = [
        { name: 'MP3', value: 75, color: '#00BFFF' },
        { name: 'WAV', value: 15, color: '#2ED573' },
        { name: 'FLAC', value: 10, color: '#FFD700' }
    ];
    
    // Atualizar legendas
    const legendContainer = document.querySelector('.chart-legend');
    if (legendContainer) {
        legendContainer.innerHTML = '';
        
        formats.forEach(format => {
            const legendItem = document.createElement('span');
            legendItem.innerHTML = `
                <i class="fas fa-circle" style="color:${format.color}"></i>
                ${format.name}: ${format.value}%
            `;
            legendContainer.appendChild(legendItem);
        });
    }
    
    // Criar gradiente conic para o gráfico
    let conicGradient = '';
    let currentAngle = 0;
    
    formats.forEach((format, index) => {
        const angle = (format.value / 100) * 360;
        const startAngle = currentAngle;
        const endAngle = currentAngle + angle;
        
        conicGradient += `${format.color} ${startAngle}deg ${endAngle}deg`;
        if (index < formats.length - 1) conicGradient += ', ';
        
        currentAngle = endAngle;
    });
    
    pieChart.style.background = `conic-gradient(${conicGradient})`;
}

/**
 * Atualizar gráficos com dados reais
 */
function updateCharts() {
    // Buscar dados reais da API
    fetch('/api/dashboard/charts', {
        headers: { 'Authorization': `Bearer ${Auth.getAuthToken()}` }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Atualizar gráficos com dados reais
            updateChartsWithData(data);
        }
    })
    .catch(error => {
        console.error('Erro ao carregar dados dos gráficos:', error);
    });
}

/**
 * Atualizar gráficos com dados da API
 */
function updateChartsWithData(data) {
    // Implementar atualização dos gráficos com dados reais
    // Esta função será chamada quando a API estiver pronta
}

/**
 * Mostrar estado de loading
 */
function showLoadingState() {
    const loadingIndicator = document.createElement('div');
    loadingIndicator.id = 'dashboardLoading';
    loadingIndicator.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(10, 10, 10, 0.8);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        z-index: 9998;
        backdrop-filter: blur(5px);
    `;
    
    loadingIndicator.innerHTML = `
        <div class="spinner" style="
            width: 60px;
            height: 60px;
            border: 4px solid rgba(255, 255, 255, 0.1);
            border-top-color: #00bfff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        "></div>
        <p style="color: white; font-size: 1.1rem;">Carregando dashboard...</p>
    `;
    
    document.body.appendChild(loadingIndicator);
    
    // Adicionar animação de spin
    if (!document.querySelector('#spinnerStyle')) {
        const style = document.createElement('style');
        style.id = 'spinnerStyle';
        style.textContent = `
            @keyframes spin {
                to { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    }
}

/**
 * Esconder estado de loading
 */
function hideLoadingState() {
    const loadingIndicator = document.getElementById('dashboardLoading');
    if (loadingIndicator) {
        loadingIndicator.remove();
    }
}

/**
 * Inicializar menu do dashboard
 */
function initDashboardMenu() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            this.querySelector('i').classList.toggle('fa-bars');
            this.querySelector('i').classList.toggle('fa-times');
        });
    }
}

/**
 * Inicializar tooltips do dashboard
 */
function initDashboardTooltips() {
    const tooltips = [
        { selector: '.stat', text: 'Clique para ver detalhes' },
        { selector: '.action-card', text: 'Clique para executar ação' },
        { selector: '.video-actions button', text: 'Ações disponíveis para o vídeo' },
        { selector: '.btn-premium', text: 'Desbloqueie recursos avançados' }
    ];
    
    tooltips.forEach(({ selector, text }) => {
        document.querySelectorAll(selector).forEach(element => {
            element.setAttribute('data-tooltip', text);
        });
    });
}

/**
 * Inicializar efeitos hover nos cards de vídeo
 */
function initVideoCardHovers() {
    document.querySelectorAll('.video-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 8px 32px rgba(0, 191, 255, 0.3)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '';
        });
    });
}

/**
 * Manipular clique nos cards de ação
 */
function handleActionCardClick(action) {
    switch (action) {
        case 'Extrair Áudio':
            window.location.href = 'extractor.html';
            break;
            
        case 'Histórico':
            window.location.href = 'videos.html';
            break;
            
        case 'Configurações':
            window.location.href = 'profile.html';
            break;
            
        case 'Upgrade Premium':
            showPremiumModal();
            break;
            
        default:
            console.log('Ação não reconhecida:', action);
    }
}

/**
 * Mostrar modal de upgrade premium
 */
function showPremiumModal() {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        backdrop-filter: blur(10px);
    `;
    
    modal.innerHTML = `
        <div class="modal-content metal-card" style="max-width: 500px; width: 90%;">
            <div class="modal-header">
                <h2><i class="fas fa-crown"></i> Upgrade Premium</h2>
                <button class="modal-close" onclick="this.closest('.modal').remove()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="premium-features">
                    <h3>Recursos Premium</h3>
                    <ul>
                        <li><i class="fas fa-check"></i> Downloads ilimitados</li>
                        <li><i class="fas fa-check"></i> Qualidade máxima (320kbps)</li>
                        <li><i class="fas fa-check"></i> Processamento prioritário</li>
                        <li><i class="fas fa-check"></i> Vídeos até 4 horas</li>
                        <li><i class="fas fa-check"></i> Sem anúncios</li>
                    </ul>
                    
                    <div class="pricing">
                        <div class="price-option active">
                            <h4>Plano Mensal</h4>
                            <div class="price">R$ 19,90<span>/mês</span></div>
                            <button class="btn btn-primary">Assinar</button>
                        </div>
                        
                        <div class="price-option">
                            <h4>Plano Anual</h4>
                            <div class="price">R$ 199,90<span>/ano</span></div>
                            <div class="savings">Economize 16%</div>
                            <button class="btn btn-secondary">Assinar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Adicionar estilos
    const style = document.createElement('style');
    style.textContent = `
        .premium-features 