/**
 * YouTube Audio Extractor Pro - Autenticação
 * Arquivo: js/auth.js
 * Responsável pelo login, registro e gestão de usuários
 */

// Aguardar DOM carregar
document.addEventListener('DOMContentLoaded', function() {
    console.log('🔐 Sistema de Autenticação - Carregado');
    
    // Inicializar forms de autenticação
    initAuthForms();
    
    // Verificar parâmetros da URL
    checkUrlParams();
    
    // Configurar Google OAuth se disponível
    initGoogleAuth();
});

/**
 * Inicializar formulários de autenticação
 */
function initAuthForms() {
    // Formulário de login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Formulário de registro
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    // Formulário de recuperação de senha
    const forgotForm = document.querySelector('form[action*="forgot"]');
    if (forgotForm) {
        forgotForm.addEventListener('submit', handleForgotPassword);
    }
    
    // Formulário de reset de senha
    const resetForm = document.querySelector('form[action*="reset"]');
    if (resetForm) {
        resetForm.addEventListener('submit', handleResetPassword);
    }
}

/**
 * Manipular login
 */
async function handleLogin(event) {
    event.preventDefault();
    
    const form = event.target;
    const email = form.querySelector('#email').value.trim();
    const password = form.querySelector('#password').value;
    const remember = form.querySelector('input[name="remember"]')?.checked || false;
    
    // Validações básicas
    if (!email || !password) {
        showAuthError('Por favor, preencha todos os campos');
        return;
    }
    
    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showAuthError('Por favor, insira um email válido');
        return;
    }
    
    // Mostrar loading
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
    submitBtn.disabled = true;
    
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email,
                password,
                remember
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Salvar token e dados do usuário
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            
            // Salvar token de refresh se fornecido
            if (data.refreshToken) {
                localStorage.setItem('refreshToken', data.refreshToken);
            }
            
            // Mostrar mensagem de sucesso
            showAuthSuccess('Login realizado com sucesso!');
            
            // Redirecionar após 1 segundo
            setTimeout(() => {
                // Verificar se há URL de demo salva
                const demoUrl = localStorage.getItem('demoUrl');
                if (demoUrl) {
                    window.location.href = `extractor.html?url=${encodeURIComponent(demoUrl)}`;
                    localStorage.removeItem('demoUrl');
                } else {
                    window.location.href = 'dashboard.html';
                }
            }, 1000);
            
        } else {
            showAuthError(data.message || 'Email ou senha incorretos');
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
        
    } catch (error) {
        console.error('Erro no login:', error);
        showAuthError('Erro ao conectar com o servidor. Tente novamente.');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

/**
 * Manipular registro
 */
async function handleRegister(event) {
    event.preventDefault();
    
    const form = event.target;
    const username = form.querySelector('#username').value.trim();
    const email = form.querySelector('#email').value.trim();
    const password = form.querySelector('#password').value;
    const confirmPassword = form.querySelector('#confirmPassword').value;
    const phone = form.querySelector('#phone')?.value.trim() || null;
    const terms = form.querySelector('#terms')?.checked;
    
    // Validações
    if (!username || !email || !password || !confirmPassword) {
        showAuthError('Por favor, preencha todos os campos obrigatórios');
        return;
    }
    
    if (!terms) {
        showAuthError('Você deve aceitar os termos de uso');
        return;
    }
    
    if (password !== confirmPassword) {
        showAuthError('As senhas não coincidem');
        return;
    }
    
    if (password.length < 8) {
        showAuthError('A senha deve ter pelo menos 8 caracteres');
        return;
    }
    
    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showAuthError('Por favor, insira um email válido');
        return;
    }
    
    // Validar telefone se fornecido
    if (phone && !validatePhone(phone)) {
        showAuthError('Por favor, insira um telefone válido');
        return;
    }
    
    // Mostrar loading
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Criando conta...';
    submitBtn.disabled = true;
    
    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username,
                email,
                password,
                phone
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Mostrar modal de confirmação
            showConfirmationModal(email);
            
            // Limpar formulário
            form.reset();
            
        } else {
            showAuthError(data.message || 'Erro ao criar conta. Tente novamente.');
        }
        
    } catch (error) {
        console.error('Erro no registro:', error);
        showAuthError('Erro ao conectar com o servidor. Tente novamente.');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

/**
 * Manipular recuperação de senha
 */
async function handleForgotPassword(event) {
    event.preventDefault();
    
    const form = event.target;
    const email = form.querySelector('#email').value.trim();
    
    if (!email) {
        showAuthError('Por favor, insira seu email');
        return;
    }
    
    // Mostrar loading
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
    submitBtn.disabled = true;
    
    try {
        const response = await fetch('/api/auth/forgot-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAuthSuccess('Email de recuperação enviado! Verifique sua caixa de entrada.');
            form.reset();
        } else {
            showAuthError(data.message || 'Erro ao enviar email de recuperação');
        }
        
    } catch (error) {
        console.error('Erro na recuperação:', error);
        showAuthError('Erro ao conectar com o servidor');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

/**
 * Manipular reset de senha
 */
async function handleResetPassword(event) {
    event.preventDefault();
    
    const form = event.target;
    const password = form.querySelector('#password').value;
    const confirmPassword = form.querySelector('#confirmPassword').value;
    const token = new URLSearchParams(window.location.search).get('token');
    
    if (!token) {
        showAuthError('Token inválido ou expirado');
        return;
    }
    
    if (!password || !confirmPassword) {
        showAuthError('Por favor, preencha todos os campos');
        return;
    }
    
    if (password !== confirmPassword) {
        showAuthError('As senhas não coincidem');
        return;
    }
    
    if (password.length < 8) {
        showAuthError('A senha deve ter pelo menos 8 caracteres');
        return;
    }
    
    // Mostrar loading
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Alterando senha...';
    submitBtn.disabled = true;
    
    try {
        const response = await fetch('/api/auth/reset-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token,
                password
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAuthSuccess('Senha alterada com sucesso! Redirecionando para login...');
            
            // Redirecionar para login após 2 segundos
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
            
        } else {
            showAuthError(data.message || 'Erro ao alterar senha');
        }
        
    } catch (error) {
        console.error('Erro no reset:', error);
        showAuthError('Erro ao conectar com o servidor');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

/**
 * Mostrar modal de confirmação de email
 */
function showConfirmationModal(email) {
    const modal = document.getElementById('confirmationModal');
    const emailSpan = document.getElementById('userEmail');
    
    if (modal && emailSpan) {
        emailSpan.textContent = email;
        modal.style.display = 'flex';
        
        // Configurar botão de reenvio
        const resendBtn = modal.querySelector('[onclick*="resendConfirmation"]');
        if (resendBtn) {
            resendBtn.onclick = () => resendConfirmation(email);
        }
    }
}

/**
 * Reenviar email de confirmação
 */
async function resendConfirmation(email) {
    try {
        const response = await fetch('/api/auth/resend-confirmation', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAuthSuccess('Email de confirmação reenviado!');
        } else {
            showAuthError(data.message || 'Erro ao reenviar email');
        }
        
    } catch (error) {
        console.error('Erro no reenvio:', error);
        showAuthError('Erro ao conectar com o servidor');
    }
}

/**
 * Verificar parâmetros da URL
 */
function checkUrlParams() {
    const urlParams = new URLSearchParams(window.location.search);
    
    // Verificar se veio de demo
    if (urlParams.has('demo')) {
        showDemoMessage();
    }
    
    // Verificar se é verificação de email
    const verifyToken = urlParams.get('verify');
    if (verifyToken) {
        verifyEmail(verifyToken);
    }
    
    // Verificar se é ativação de conta
    const activateToken = urlParams.get('activate');
    if (activateToken) {
        activateAccount(activateToken);
    }
}

/**
 * Mostrar mensagem de demo
 */
function showDemoMessage() {
    const demoMessage = document.getElementById('demoMessage');
    if (demoMessage) {
        demoMessage.style.display = 'block';
        
        // Esconder após 10 segundos
        setTimeout(() => {
            demoMessage.style.display = 'none';
        }, 10000);
    }
}

/**
 * Verificar email
 */
async function verifyEmail(token) {
    try {
        const response = await fetch(`/api/auth/verify/${token}`);
        const data = await response.json();
        
        if (data.success) {
            showAuthSuccess('Email verificado com sucesso! Você já pode fazer login.');
            
            // Remover token da URL
            const url = new URL(window.location);
            url.searchParams.delete('verify');
            window.history.replaceState({}, '', url);
            
        } else {
            showAuthError(data.message || 'Token de verificação inválido ou expirado');
        }
        
    } catch (error) {
        console.error('Erro na verificação:', error);
        showAuthError('Erro ao verificar email');
    }
}

/**
 * Ativar conta
 */
async function activateAccount(token) {
    try {
        const response = await fetch(`/api/auth/activate/${token}`);
        const data = await response.json();
        
        if (data.success) {
            showAuthSuccess('Conta ativada com sucesso! Você já pode fazer login.');
            
            // Redirecionar para login após 3 segundos
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 3000);
            
        } else {
            showAuthError(data.message || 'Token de ativação inválido ou expirado');
        }
        
    } catch (error) {
        console.error('Erro na ativação:', error);
        showAuthError('Erro ao ativar conta');
    }
}

/**
 * Inicializar autenticação com Google
 */
function initGoogleAuth() {
    const googleBtn = document.querySelector('.btn-google');
    if (googleBtn) {
        googleBtn.addEventListener('click', handleGoogleAuth);
    }
}

/**
 * Manipular autenticação com Google
 */
function handleGoogleAuth() {
    // URL do backend para OAuth do Google
    const googleAuthUrl = '/api/auth/google';
    
    // Abrir popup para autenticação
    const width = 500;
    const height = 600;
    const left = (screen.width - width) / 2;
    const top = (screen.height - height) / 2;
    
    const popup = window.open(
        googleAuthUrl,
        'Google Auth',
        `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes`
    );
    
    // Verificar status da autenticação
    const checkPopup = setInterval(() => {
        if (popup.closed) {
            clearInterval(checkPopup);
            checkGoogleAuthStatus();
        }
    }, 1000);
}

/**
 * Verificar status da autenticação Google
 */
async function checkGoogleAuthStatus() {
    try {
        const response = await fetch('/api/auth/google/status');
        const data = await response.json();
        
        if (data.success) {
            // Salvar token e dados do usuário
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            
            showAuthSuccess('Login com Google realizado com sucesso!');
            
            // Redirecionar
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1000);
            
        } else {
            showAuthError('Erro na autenticação com Google');
        }
        
    } catch (error) {
        console.error('Erro ao verificar status Google:', error);
        showAuthError('Erro na autenticação com Google');
    }
}

/**
 * Validar telefone
 */
function validatePhone(phone) {
    // Remove caracteres não numéricos
    const cleaned = phone.replace(/\D/g, '');
    
    // Verifica se tem entre 10 e 11 dígitos (com DDD)
    if (cleaned.length < 10 || cleaned.length > 11) {
        return false;
    }
    
    // Validação básica de DDD (11 a 99)
    const ddd = parseInt(cleaned.substring(0, 2));
    if (ddd < 11 || ddd > 99) {
        return false;
    }
    
    return true;
}

/**
 * Formatar telefone enquanto digita
 */
function formatPhoneInput(input) {
    let value = input.value.replace(/\D/g, '');
    
    if (value.length > 0) {
        value = '(' + value;
    }
    
    if (value.length > 3) {
        value = value.substring(0, 3) + ') ' + value.substring(3);
    }
    
    if (value.length > 10) {
        value = value.substring(0, 10) + '-' + value.substring(10);
    }
    
    if (value.length > 15) {
        value = value.substring(0, 15);
    }
    
    input.value = value;
}

/**
 * Mostrar erro de autenticação
 */
function showAuthError(message) {
    // Criar ou atualizar elemento de erro
    let errorDiv = document.querySelector('.auth-error');
    
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.className = 'auth-error';
        errorDiv.style.cssText = `
            background: rgba(255, 71, 87, 0.1);
            border: 1px solid rgba(255, 71, 87, 0.3);
            color: #ff4757;
            padding: 1rem;
            border-radius: 8px;
            margin: 1rem 0;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.3s ease;
        `;
        
        const form = document.querySelector('.auth-form');
        if (form) {
            form.parentNode.insertBefore(errorDiv, form);
        }
    }
    
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        <span>${message}</span>
    `;
    
    errorDiv.style.display = 'flex';
    
    // Esconder após 5 segundos
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 5000);
}

/**
 * Mostrar sucesso de autenticação
 */
function showAuthSuccess(message) {
    // Criar ou atualizar elemento de sucesso
    let successDiv = document.querySelector('.auth-success');
    
    if (!successDiv) {
        successDiv = document.createElement('div');
        successDiv.className = 'auth-success';
        successDiv.style.cssText = `
            background: rgba(46, 213, 115, 0.1);
            border: 1px solid rgba(46, 213, 115, 0.3);
            color: #2ed573;
            padding: 1rem;
            border-radius: 8px;
            margin: 1rem 0;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.3s ease;
        `;
        
        const form = document.querySelector('.auth-form');
        if (form) {
            form.parentNode.insertBefore(successDiv, form);
        }
    }
    
    successDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    
    successDiv.style.display = 'flex';
    
    // Esconder após 5 segundos
    setTimeout(() => {
        successDiv.style.display = 'none';
    }, 5000);
}

/**
 * Logout do usuário
 */
function logout() {
    // Remover tokens do localStorage
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('refreshToken');
    
    // Fazer logout no servidor (opcional)
    fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
    }).catch(console.error);
    
    // Redirecionar para home
    window.location.href = '/';
}

/**
 * Verificar se usuário está autenticado
 */
function isAuthenticated() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (!token || !user) {
        return false;
    }
    
    // Verificar se token está expirado (opcional)
    try {
        const userData = JSON.parse(user);
        if (userData.exp && us