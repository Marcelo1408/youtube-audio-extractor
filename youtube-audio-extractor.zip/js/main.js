/**
 * YouTube Audio Extractor Pro - JavaScript Principal
 * Arquivo: js/main.js
 * Responsável pela lógica geral do site
 */

// Aguardar DOM carregar
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎵 YouTube Audio Extractor Pro - Carregado');
    
    // Inicializar componentes
    initMobileMenu();
    initPasswordToggles();
    initFormValidations();
    initDemoFeatures();
    checkAuthStatus();
    
    // Verificar URL atual para highlight do menu
    highlightActiveNav();
    
    // Inicializar tooltips
    initTooltips();
    
    // Configurar interceptors para requests
    setupRequestInterceptors();
});

/**
 * Inicializar menu mobile
 */
function initMobileMenu() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            this.querySelector('i').classList.toggle('fa-bars');
            this.querySelector('i').classList.toggle('fa-times');
        });
        
        // Fechar menu ao clicar em link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                menuToggle.querySelector('i').classList.remove('fa-times');
                menuToggle.querySelector('i').classList.add('fa-bars');
            });
        });
    }
}

/**
 * Inicializar toggle de visualização de senha
 */
function initPasswordToggles() {
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
                this.setAttribute('title', 'Ocultar senha');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
                this.setAttribute('title', 'Mostrar senha');
            }
            
            input.focus();
        });
    });
}

/**
 * Inicializar validações de formulário
 */
function initFormValidations() {
    // Validação de email
    document.querySelectorAll('input[type="email"]').forEach(input => {
        input.addEventListener('blur', function() {
            validateEmail(this);
        });
    });
    
    // Validação de senha
    document.querySelectorAll('input[type="password"]').forEach(input => {
        input.addEventListener('input', function() {
            validatePasswordStrength(this);
        });
    });
    
    // Validação de URL do YouTube
    const youtubeInput = document.getElementById('youtubeUrl') || document.getElementById('demoUrl');
    if (youtubeInput) {
        youtubeInput.addEventListener('blur', function() {
            validateYouTubeUrl(this);
        });
    }
}

/**
 * Validar formato de email
 */
function validateEmail(input) {
    const email = input.value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (email && !emailRegex.test(email)) {
        showInputError(input, 'Por favor, insira um email válido');
        return false;
    }
    
    clearInputError(input);
    return true;
}

/**
 * Validar força da senha
 */
function validatePasswordStrength(input) {
    const password = input.value;
    const strengthBar = input.parentElement.nextElementSibling?.querySelector('.strength-bar');
    const strengthText = input.parentElement.nextElementSibling?.querySelector('.strength-text');
    
    if (!strengthBar || !strengthText) return;
    
    let strength = 0;
    let messages = [];
    
    // Critérios de força
    if (password.length >= 8) {
        strength += 25;
    } else {
        messages.push('Mínimo 8 caracteres');
    }
    
    if (/[A-Z]/.test(password)) {
        strength += 25;
    } else {
        messages.push('Pelo menos uma letra maiúscula');
    }
    
    if (/[0-9]/.test(password)) {
        strength += 25;
    } else {
        messages.push('Pelo menos um número');
    }
    
    if (/[^A-Za-z0-9]/.test(password)) {
        strength += 25;
    } else {
        messages.push('Pelo menos um caractere especial');
    }
    
    // Atualizar barra de força
    strengthBar.style.width = strength + '%';
    
    // Definir cor e texto baseado na força
    let color, text;
    if (strength <= 25) {
        color = '#ff4757';
        text = 'Muito Fraca';
    } else if (strength <= 50) {
        color = '#ffa502';
        text = 'Fraca';
    } else if (strength <= 75) {
        color = '#2ed573';
        text = 'Boa';
    } else {
        color = '#00bfff';
        text = 'Forte';
    }
    
    strengthBar.style.background = color;
    strengthText.textContent = text;
    strengthText.style.color = color;
    
    // Adicionar tooltip com mensagens
    if (messages.length > 0 && strength < 100) {
        strengthText.setAttribute('data-tooltip', messages.join('\n'));
    } else {
        strengthText.removeAttribute('data-tooltip');
    }
}

/**
 * Validar URL do YouTube
 */
function validateYouTubeUrl(input) {
    const url = input.value.trim();
    
    if (!url) {
        clearInputError(input);
        return true;
    }
    
    const youtubePatterns = [
        /^(https?:\/\/)?(www\.)?youtube\.com\/watch\?v=[\w-]{11}/,
        /^(https?:\/\/)?(www\.)?youtu\.be\/[\w-]{11}/,
        /^(https?:\/\/)?(www\.)?youtube\.com\/playlist\?list=[\w-]+/,
        /^(https?:\/\/)?(www\.)?youtube\.com\/shorts\/[\w-]{11}/
    ];
    
    const isValid = youtubePatterns.some(pattern => pattern.test(url));
    
    if (!isValid) {
        showInputError(input, 'URL do YouTube inválida. Use um link de vídeo, playlist ou shorts.');
        return false;
    }
    
    clearInputError(input);
    return true;
}

/**
 * Mostrar erro em input
 */
function showInputError(input, message) {
    clearInputError(input);
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'input-error';
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
    errorDiv.style.cssText = `
        color: #ff4757;
        font-size: 0.85rem;
        margin-top: 0.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        animation: fadeIn 0.3s ease;
    `;
    
    input.parentElement.appendChild(errorDiv);
    input.style.borderColor = '#ff4757';
    
    // Remover erro após 5 segundos
    setTimeout(() => clearInputError(input), 5000);
}

/**
 * Limpar erro do input
 */
function clearInputError(input) {
    const errorDiv = input.parentElement.querySelector('.input-error');
    if (errorDiv) {
        errorDiv.remove();
    }
    input.style.borderColor = '';
}

/**
 * Inicializar features de demo
 */
function initDemoFeatures() {
    const demoExtractBtn = document.querySelector('[onclick*="demoExtract"]');
    if (demoExtractBtn) {
        demoExtractBtn.onclick = demoExtract;
    }
    
    // Carregar URL de demo do localStorage
    const demoUrl = localStorage.getItem('demoUrl');
    const demoInput = document.getElementById('demoUrl');
    if (demoUrl && demoInput) {
        demoInput.value = demoUrl;
    }
}

/**
 * Extrair áudio (demo)
 */
async function demoExtract() {
    const urlInput = document.getElementById('demoUrl');
    const url = urlInput.value.trim();
    
    if (!validateYouTubeUrl(urlInput)) {
        return;
    }
    
    // Salvar URL para login
    localStorage.setItem('demoUrl', url);
    
    // Mostrar loading
    const originalText = urlInput.nextElementSibling.innerHTML;
    urlInput.nextElementSibling.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processando...';
    urlInput.nextElementSibling.disabled = true;
    
    // Simular processamento
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Redirecionar para login
    window.location.href = 'login.html?demo=true';
}

/**
 * Verificar status de autenticação
 */
function checkAuthStatus() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    
    if (token && user) {
        // Usuário está logado
        updateUIForLoggedInUser(JSON.parse(user));
    } else {
        // Usuário não está logado
        updateUIForGuest();
    }
}

/**
 * Atualizar UI para usuário logado
 */
function updateUIForLoggedInUser(user) {
    // Atualizar nome do usuário em elementos
    document.querySelectorAll('#username, #userName').forEach(el => {
        if (el) el.textContent = user.username || 'Usuário';
    });
    
    // Atualizar email do usuário
    document.querySelectorAll('#userEmail').forEach(el => {
        if (el) el.textContent = user.email || '';
    });
    
    // Mostrar elementos específicos de usuário logado
    document.querySelectorAll('.user-only').forEach(el => {
        el.style.display = 'block';
    });
    
    // Esconder elementos de convidado
    document.querySelectorAll('.guest-only').forEach(el => {
        el.style.display = 'none';
    });
}

/**
 * Atualizar UI para convidado
 */
function updateUIForGuest() {
    // Mostrar elementos de convidado
    document.querySelectorAll('.guest-only').forEach(el => {
        el.style.display = 'block';
    });
    
    // Esconder elementos de usuário logado
    document.querySelectorAll('.user-only').forEach(el => {
        el.style.display = 'none';
    });
}

/**
 * Destacar navegação ativa
 */
function highlightActiveNav() {
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    
    document.querySelectorAll('.nav-link').forEach(link => {
        const linkPath = link.getAttribute('href');
        
        if (linkPath === currentPath || 
            (currentPath === '' && linkPath === 'index.html') ||
            (linkPath === '/' && currentPath === 'index.html')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

/**
 * Inicializar tooltips
 */
function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    
    tooltips.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

/**
 * Mostrar tooltip
 */
function showTooltip(event) {
    const element = event.target;
    const tooltipText = element.getAttribute('data-tooltip');
    
    if (!tooltipText) return;
    
    // Criar tooltip
    const tooltip = document.createElement('div');
    tooltip.className = 'custom-tooltip';
    tooltip.textContent = tooltipText;
    tooltip.style.cssText = `
        position: absolute;
        background: #1a1a1a;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        font-size: 0.85rem;
        z-index: 10000;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        max-width: 300px;
        white-space: pre-line;
        pointer-events: none;
    `;
    
    // Posicionar tooltip
    const rect = element.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) + 'px';
    tooltip.style.top = rect.top - 10 + 'px';
    tooltip.style.transform = 'translate(-50%, -100%)';
    
    // Adicionar seta
    const arrow = document.createElement('div');
    arrow.style.cssText = `
        position: absolute;
        bottom: -5px;
        left: 50%;
        transform: translateX(-50%);
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
        border-top: 5px solid #1a1a1a;
    `;
    
    tooltip.appendChild(arrow);
    document.body.appendChild(tooltip);
    
    // Guardar referência
    element._tooltip = tooltip;
}

/**
 * Esconder tooltip
 */
function hideTooltip(event) {
    const element = event.target;
    
    if (element._tooltip) {
        element._tooltip.remove();
        delete element._tooltip;
    }
}

/**
 * Configurar interceptors para requests
 */
function setupRequestInterceptors() {
    // Interceptor para fetch
    const originalFetch = window.fetch;
    
    window.fetch = async function(...args) {
        const [url, options = {}] = args;
        
        // Adicionar token de autenticação se existir
        const token = localStorage.getItem('token');
        if (token && !options.headers?.['Authorization']) {
            options.headers = {
                ...options.headers,
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            };
        }
        
        // Mostrar loading para requests demorados
        let loadingTimeout;
        if (!url.includes('/health') && !url.includes('/socket.io')) {
            loadingTimeout = setTimeout(() => {
                showLoadingOverlay();
            }, 500);
        }
        
        try {
            const response = await originalFetch(url, options);
            
            // Verificar se token expirou
            if (response.status === 401) {
                handleUnauthorized();
                return response;
            }
            
            return response;
        } catch (error) {
            console.error('Fetch error:', error);
            showError('Erro de conexão. Verifique sua internet.');
            throw error;
        } finally {
            clearTimeout(loadingTimeout);
            hideLoadingOverlay();
        }
    };
}

/**
 * Mostrar overlay de loading
 */
function showLoadingOverlay() {
    let overlay = document.getElementById('loadingOverlay');
    
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(10, 10, 10, 0.8);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            backdrop-filter: blur(5px);
        `;
        
        const spinner = document.createElement('div');
        spinner.style.cssText = `
            width: 60px;
            height: 60px;
            border: 4px solid rgba(255, 255, 255, 0.1);
            border-top-color: #00bfff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        `;
        
        const text = document.createElement('p');
        text.textContent = 'Carregando...';
        text.style.cssText = `
            color: white;
            font-size: 1.1rem;
            margin: 0;
        `;
        
        overlay.appendChild(spinner);
        overlay.appendChild(text);
        document.body.appendChild(overlay);
        
        // Adicionar animação de spin
        const style = document.createElement('style');
        style.textContent = `
            @keyframes spin {
                to { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    }
    
    overlay.style.display = 'flex';
}

/**
 * Esconder overlay de loading
 */
function hideLoadingOverlay() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

/**
 * Manipular não autorizado (token expirado)
 */
function handleUnauthorized() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    
    showError('Sessão expirada. Por favor, faça login novamente.');
    
    // Redirecionar para login após 2 segundos
    setTimeout(() => {
        if (!window.location.pathname.includes('login.html') && 
            !window.location.pathname.includes('register.html')) {
            window.location.href = 'login.html';
        }
    }, 2000);
}

/**
 * Mostrar mensagem de erro
 */
function showError(message, duration = 5000) {
    // Remover erro anterior
    const existingError = document.querySelector('.error-notification');
    if (existingError) {
        existingError.remove();
    }
    
    // Criar elemento de erro
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-notification';
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-triangle"></i>
        <span>${message}</span>
        <button class="error-close"><i class="fas fa-times"></i></button>
    `;
    
    errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(255, 71, 87, 0.9);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 9998;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        animation: slideInRight 0.3s ease;
        max-width: 400px;
    `;
    
    // Botão fechar
    const closeBtn = errorDiv.querySelector('.error-close');
    closeBtn.style.cssText = `
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        padding: 0;
        margin-left: 10px;
    `;
    
    closeBtn.onclick = () => errorDiv.remove();
    
    document.body.appendChild(errorDiv);
    
    // Remover automaticamente após duração
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.remove();
        }
    }, duration);
    
    // Adicionar animação
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
}

/**
 * Mostrar mensagem de sucesso
 */
function showSuccess(message, duration = 3000) {
    // Remover sucesso anterior
    const existingSuccess = document.querySelector('.success-notification');
    if (existingSuccess) {
        existingSuccess.remove();
    }
    
    // Criar elemento de sucesso
    const successDiv = document.createElement('div');
    successDiv.className = 'success-notification';
    successDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    
    successDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(46, 213, 115, 0.9);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 9998;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        animation: slideInRight 0.3s ease;
        max-width: 400px;
    `;
    
    document.body.appendChild(successDiv);
    
    // Remover automaticamente após duração
    setTimeout(() => {
        if (successDiv.parentNode) {
            successDiv.remove();
        }
    }, duration);
}

/**
 * Formatar bytes para tamanho legível
 */
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/**
 * Formatar duração em segundos para MM:SS
 */
function formatDuration(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${sec