/**
 * YouTube Audio Extractor Pro - Extrator de Áudio
 * Arquivo: js/extractor.js
 * Responsável pelo processamento de vídeos do YouTube
 */

// Estado global do extrator
const ExtractorState = {
    currentJobId: null,
    isProcessing: false,
    progressInterval: null,
    socket: null,
    videoInfo: null
};

// Aguardar DOM carregar
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎵 Extrator de Áudio - Carregado');
    
    // Verificar autenticação
    if (!Auth.requireAuth()) {
        return;
    }
    
    // Inicializar componentes
    initExtractor();
    loadUserStats();
    
    // Verificar URL pré-carregada
    checkPreloadedUrl();
    
    // Configurar eventos
    setupEventListeners();
});

/**
 * Inicializar extrator
 */
function initExtractor() {
    // Configurar seletores de qualidade
    document.querySelectorAll('.quality-option').forEach(option => {
        option.addEventListener('click', function() {
            selectQuality(this);
        });
    });
    
    // Configurar validação de URL em tempo real
    const urlInput = document.getElementById('youtubeUrl');
    if (urlInput) {
        urlInput.addEventListener('input', debounce(validateUrlInput, 500));
    }
    
    // Configurar tooltips
    initExtractorTooltips();
    
    // Carregar histórico recente
    loadRecentHistory();
}

/**
 * Verificar URL pré-carregada
 */
function checkPreloadedUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    const url = urlParams.get('url');
    
    if (url) {
        const urlInput = document.getElementById('youtubeUrl');
        if (urlInput) {
            urlInput.value = decodeURIComponent(url);
            
            // Analisar automaticamente após um delay
            setTimeout(() => {
                if (validateYouTubeUrl(urlInput)) {
                    analyzeVideo();
                }
            }, 1000);
        }
    }
}

/**
 * Configurar listeners de eventos
 */
function setupEventListeners() {
    // Evento de análise de vídeo
    const analyzeBtn = document.querySelector('[onclick*="analyzeVideo"]');
    if (analyzeBtn) {
        analyzeBtn.onclick = analyzeVideo;
    }
    
    // Evento de início de processamento
    const processBtn = document.querySelector('[onclick*="startProcessing"]');
    if (processBtn) {
        processBtn.onclick = startProcessing;
    }
    
    // Evento de reset
    const resetBtn = document.querySelector('[onclick*="resetForm"]');
    if (resetBtn) {
        resetBtn.onclick = resetForm;
    }
    
    // Evento de download all
    const downloadAllBtn = document.querySelector('[onclick*="downloadAll"]');
    if (downloadAllBtn) {
        downloadAllBtn.onclick = downloadAllTracks;
    }
    
    // Evento de process another
    const processAnotherBtn = document.querySelector('[onclick*="processAnother"]');
    if (processAnotherBtn) {
        processAnotherBtn.onclick = resetForm;
    }
    
    // Eventos de qualidade
    document.querySelectorAll('input[name="quality"]').forEach(radio => {
        radio.addEventListener('change', updateQualitySelection);
    });
    
    // Eventos de opções
    document.querySelectorAll('.processing-options input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', updateProcessingOptions);
    });
}

/**
 * Validar input de URL em tempo real
 */
function validateUrlInput() {
    const urlInput = document.getElementById('youtubeUrl');
    const analyzeBtn = document.querySelector('[onclick*="analyzeVideo"]');
    
    if (!urlInput || !analyzeBtn) return;
    
    const url = urlInput.value.trim();
    
    if (!url) {
        analyzeBtn.disabled = true;
        hideVideoPreview();
        return;
    }
    
    const isValid = validateYouTubeUrl(urlInput);
    analyzeBtn.disabled = !isValid;
    
    if (isValid && url.length > 20) {
        // Habilitar análise automática para URLs completas
        analyzeBtn.classList.add('btn-glow');
    } else {
        analyzeBtn.classList.remove('btn-glow');
    }
}

/**
 * Selecionar qualidade
 */
function selectQuality(element) {
    // Remover seleção anterior
    document.querySelectorAll('.quality-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    
    // Adicionar seleção atual
    element.classList.add('selected');
    
    // Marcar radio button
    const radio = element.querySelector('input[type="radio"]');
    if (radio) {
        radio.checked = true;
        radio.dispatchEvent(new Event('change'));
    }
}

/**
 * Atualizar seleção de qualidade
 */
function updateQualitySelection(event) {
    const quality = event.target.value;
    console.log('Qualidade selecionada:', quality + 'kbps');
    
    // Atualizar UI se necessário
    document.querySelectorAll('.quality-option').forEach(option => {
        const optionQuality = option.querySelector('input').value;
        if (optionQuality === quality) {
            option.classList.add('selected');
        } else {
            option.classList.remove('selected');
        }
    });
}

/**
 * Atualizar opções de processamento
 */
function updateProcessingOptions(event) {
    const optionId = event.target.id;
    const isChecked = event.target.checked;
    
    console.log('Opção atualizada:', optionId, isChecked);
    
    // Atualizar UI se necessário
    const label = event.target.closest('label');
    if (label) {
        if (isChecked) {
            label.classList.add('option-checked');
        } else {
            label.classList.remove('option-checked');
        }
    }
}

/**
 * Analisar vídeo do YouTube
 */
async function analyzeVideo() {
    const urlInput = document.getElementById('youtubeUrl');
    const url = urlInput.value.trim();
    
    if (!url) {
        showError('Por favor, insira uma URL do YouTube');
        return;
    }
    
    if (!validateYouTubeUrl(urlInput)) {
        return;
    }
    
    // Mostrar loading
    const analyzeBtn = document.querySelector('[onclick*="analyzeVideo"]');
    const originalText = analyzeBtn.innerHTML;
    analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analisando...';
    analyzeBtn.disabled = true;
    
    try {
        // Verificar se já temos informações em cache
        const cacheKey = `video_info_${btoa(url)}`;
        const cachedInfo = localStorage.getItem(cacheKey);
        
        if (cachedInfo) {
            const data = JSON.parse(cachedInfo);
            if (Date.now() - data.timestamp < 3600000) { // 1 hora de cache
                displayVideoInfo(data);
                analyzeBtn.innerHTML = originalText;
                analyzeBtn.disabled = false;
                return;
            }
        }
        
        // Buscar informações da API
        const response = await fetch('/api/videos/info', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${Auth.getAuthToken()}`
            },
            body: JSON.stringify({ url })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Salvar em cache
            data.timestamp = Date.now();
            localStorage.setItem(cacheKey, JSON.stringify(data));
            
            displayVideoInfo(data);
            
        } else {
            showError(data.message || 'Erro ao obter informações do vídeo');
        }
        
    } catch (error) {
        console.error('Erro na análise:', error);
        showError('Erro ao conectar com o servidor');
        
        // Tentar fallback com API pública do YouTube
        tryFallbackAnalysis(url);
        
    } finally {
        analyzeBtn.innerHTML = originalText;
        analyzeBtn.disabled = false;
    }
}

/**
 * Exibir informações do vídeo
 */
function displayVideoInfo(data) {
    const preview = document.getElementById('videoPreview');
    if (!preview) return;
    
    // Atualizar elementos
    document.getElementById('videoThumb').src = data.thumbnail;
    document.getElementById('videoTitle').textContent = data.title;
    document.getElementById('videoDuration').textContent = data.duration;
    document.getElementById('videoChannel').textContent = data.channel;
    document.getElementById('videoViews').textContent = formatNumber(data.views);
    document.getElementById('videoDate').textContent = formatDate(data.date);
    document.getElementById('videoDescription').textContent = 
        data.description.substring(0, 200) + (data.description.length > 200 ? '...' : '');
    
    // Mostrar preview
    preview.style.display = 'block';
    
    // Salvar informações para uso posterior
    ExtractorState.videoInfo = data;
    
    // Habilitar botão de processamento
    const processBtn = document.querySelector('[onclick*="startProcessing"]');
    if (processBtn) {
        processBtn.disabled = false;
        processBtn.classList.add('btn-glow');
    }
    
    // Adicionar animação
    preview.style.animation = 'none';
    setTimeout(() => {
        preview.style.animation = 'slideInUp 0.5s ease';
    }, 10);
}

/**
 * Tentar análise alternativa (fallback)
 */
async function tryFallbackAnalysis(url) {
    try {
        // Extrair ID do vídeo
        const videoId = extractVideoId(url);
        if (!videoId) return;
        
        // Usar API do oEmbed do YouTube
        const response = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`);
        const data = await response.json();
        
        const fallbackInfo = {
            success: true,
            title: data.title,
            thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
            channel: data.author_name,
            duration: 'N/A',
            views: 0,
            date: new Date().toISOString().split('T')[0],
            description: ''
        };
        
        displayVideoInfo(fallbackInfo);
        
    } catch (error) {
        console.error('Fallback também falhou:', error);
    }
}

/**
 * Extrair ID do vídeo da URL
 */
function extractVideoId(url) {
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/,
        /youtube\.com\/embed\/([\w-]{11})/,
        /youtube\.com\/v\/([\w-]{11})/
    ];
    
    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match && match[1]) {
            return match[1];
        }
    }
    
    return null;
}

/**
 * Iniciar processamento
 */
async function startProcessing() {
    // Verificar autenticação
    if (!Auth.isAuthenticated()) {
        showError('Por favor, faça login para processar vídeos');
        window.location.href = 'login.html?redirect=' + encodeURIComponent(window.location.href);
        return;
    }
    
    const urlInput = document.getElementById('youtubeUrl');
    const url = urlInput.value.trim();
    
    if (!url || !validateYouTubeUrl(urlInput)) {
        showError('Por favor, insira uma URL válida do YouTube');
        return;
    }
    
    // Coletar configurações
    const quality = document.querySelector('input[name="quality"]:checked').value;
    const separateTracks = document.getElementById('separateTracks').checked;
    const createZip = document.getElementById('createZip').checked;
    const keepVideo = document.getElementById('keepVideo').checked;
    const emailNotification = document.getElementById('emailNotification').checked;
    
    // Validar limites do usuário
    if (!await checkUserLimits()) {
        return;
    }
    
    // Mostrar seção de processamento
    showProcessingSection();
    
    // Iniciar processamento via WebSocket
    startWebSocketProcessing(url, quality, separateTracks, createZip, keepVideo, emailNotification);
}

/**
 * Verificar limites do usuário
 */
async function checkUserLimits() {
    try {
        const response = await fetch('/api/user/limits', {
            headers: {
                'Authorization': `Bearer ${Auth.getAuthToken()}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            if (!data.canProcess) {
                showError(data.message || 'Limite de processamentos atingido');
                return false;
            }
            return true;
        }
        
        return true; // Continuar mesmo se a API falhar
        
    } catch (error) {
        console.error('Erro ao verificar limites:', error);
        return true; // Continuar mesmo se a API falhar
    }
}

/**
 * Mostrar seção de processamento
 */
function showProcessingSection() {
    // Esconder resultados anteriores
    const resultsContainer = document.getElementById('resultsContainer');
    if (resultsContainer) {
        resultsContainer.style.display = 'none';
    }
    
    // Mostrar status
    const statusContainer = document.getElementById('processingStatus');
    if (statusContainer) {
        statusContainer.style.display = 'block';
        statusContainer.style.animation = 'fadeIn 0.5s ease';
    }
    
    // Resetar progresso
    resetProgress();
    
    // Desabilitar botões
    document.querySelectorAll('.action-buttons button').forEach(btn => {
        btn.disabled = true;
    });
    
    ExtractorState.isProcessing = true;
}

/**
 * Iniciar processamento via WebSocket
 */
function startWebSocketProcessing(url, quality, separateTracks, createZip, keepVideo, emailNotification) {
    // Criar ID único para o job
    const jobId = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    ExtractorState.currentJobId = jobId;
    
    // Conectar WebSocket
    const socketUrl = window.location.protocol === 'https:' 
        ? `wss://${window.location.host}/ws`
        : `ws://${window.location.host}/ws`;
    
    ExtractorState.socket = new WebSocket(socketUrl);
    
    ExtractorState.socket.onopen = function() {
        console.log('WebSocket conectado');
        
        // Enviar dados do job
        const jobData = {
            type: 'process_video',
            jobId,
            url,
            quality: parseInt(quality),
            separateTracks,
            createZip,
            keepVideo,
            emailNotification,
            userId: Auth.getUserData()?.id
        };
        
        this.send(JSON.stringify(jobData));
        
        // Atualizar UI
        updateStepStatus(1, 'Baixando vídeo...', 'active');
        updateProgress(0, 'Iniciando download...');
    };
    
    ExtractorState.socket.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        } catch (error) {
            console.error('Erro ao processar mensagem WebSocket:', error);
        }
    };
    
    ExtractorState.socket.onerror = function(error) {
        console.error('WebSocket error:', error);
        showError('Erro na conexão com o servidor');
        
        // Tentar fallback para polling
        startPollingProcessing(jobId, url, quality, separateTracks, createZip, keepVideo, emailNotification);
    };
    
    ExtractorState.socket.onclose = function() {
        console.log('WebSocket desconectado');
    };
}

/**
 * Manipular mensagens WebSocket
 */
function handleWebSocketMessage(data) {
    switch (data.type) {
        case 'progress':
            handleProgressUpdate(data);
            break;
            
        case 'log':
            addToLog(data.message);
            break;
            
        case 'step_update':
            updateStepStatus(data.step, data.message, data.status);
            break;
            
        case 'complete':
            handleProcessingComplete(data);
            break;
            
        case 'error':
            handleProcessingError(data);
            break;
            
        default:
            console.log('Mensagem desconhecida:', data);
    }
}

/**
 * Manipular atualização de progresso
 */
function handleProgressUpdate(data) {
    updateProgress(data.progress, data.message);
    
    // Atualizar badge de status
    const statusBadge = document.getElementById('statusBadge');
    if (statusBadge) {
        statusBadge.textContent = data.stage || 'Processando';
    }
}

/**
 * Manipular conclusão do processamento
 */
function handleProcessingComplete(data) {
    console.log('Processamento completo:', data);
    
    // Atualizar UI
    updateProgress(100, 'Processamento concluído!');
    updateStepStatus(4, 'Concluído', 'completed');
    
    // Adicionar log final
    addToLog('✅ Processamento concluído com sucesso!');
    
    // Mostrar resultados
    setTimeout(() => {
        showResults(data);
    }, 1000);
    
    // Fechar WebSocket
    if (ExtractorState.socket) {
        ExtractorState.socket.close();
        ExtractorState.socket = null;
    }
    
    ExtractorState.isProcessing = false;
    
    // Atualizar estatísticas do usuário
    loadUserStats();
}

/**
 * Manipular erro no processamento
 */
function handleProcessingError(data) {
    console.error('Erro no processamento:', data);
    
    showError(data.message || 'Erro durante o processamento');
    
    // Atualizar UI
    updateStepStatus('current', 'Falhou', 'failed');
    addToLog(`❌ Erro: ${data.message}`);
    
    // Fechar WebSocket
    if (ExtractorState.socket) {
        ExtractorState.socket.close();
        ExtractorState.socket = null;
    }
    
    ExtractorState.isProcessing = false;
    
    // Habilitar botões novamente
    document.querySelectorAll('.action-buttons button').forEach(btn => {
        btn.disabled = false;
    });
}

/**
 * Iniciar processamento via polling (fallback)
 */
function startPollingProcessing(jobId, url, quality, separateTracks, createZip, keepVideo, emailNotification) {
    console.log('Iniciando processamento via polling');
    
    // Criar job via API
    fetch('/api/videos/process', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${Auth.getAuthToken()}`
        },
        body: JSON.stringify({
            url,
            quality: parseInt(quality),
            separateTracks,
            createZip,
            keepVideo,
            emailNotification
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            ExtractorState.currentJobId = data.jobId;
            
            // Iniciar polling do status
            startPollingStatus(data.jobId);
            
        } else {
            throw new Error(data.message || 'Erro ao iniciar processamento');
        }
    })
    .catch(error => {
        console.error('Erro no processamento via polling:', error);
        showError('Falha ao iniciar processamento');
    });
}

/**
 * Iniciar polling do status
 */
function startPollingStatus(jobId) {
    if (ExtractorState.progressInterval) {
        clearInterval(ExtractorState.progressInterval);
    }
    
    let lastProgress = 0;
    
    ExtractorState.progressInterval = setInterval(async () => {
        try {
            const response = await fetch(`/api/videos/status/${jobId}`, {
                headers: {
                    'Authorization': `Bearer ${Auth.getAuthToken()}`
                }
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Atualizar progresso
                if (data.progress > lastProgress) {
                    updateProgress(data.progress, data.message);
                    lastProgress = data.progress;
                }
                
                // Adicionar logs
                if (data.logs) {
                    data.logs.forEach(log => addToLog(log));
                }
                
                // Atualizar steps
                if (data.currentStep) {
                    updateStepStatus(data.currentStep, data.stepMes