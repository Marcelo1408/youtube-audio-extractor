#!/bin/bash
# backend/setup.sh

echo "🚀 Configuração do YouTube Audio Extractor"
echo "=========================================="

# Verificar Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não está instalado."
    echo "Instale com: curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt install -y nodejs"
    exit 1
fi

echo "✅ Node.js $(node -v) instalado"

# Verificar npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm não está instalado."
    exit 1
fi

echo "✅ npm $(npm -v) instalado"

# Instalar dependências
echo "📦 Instalando dependências..."
npm install

# Verificar/criar .env
if [ ! -f .env ]; then
    echo "📝 Criando arquivo .env..."
    cp .env.example .env
    echo "⚠️  Configure as variáveis no arquivo .env antes de continuar"
    exit 1
fi

# Carregar .env
set -a
source .env
set +a

# Criar diretórios
echo "📁 Criando diretórios..."
mkdir -p uploads/videos uploads/audio uploads/temp logs

# Configurar permissões
echo "🔐 Configurando permissões..."
chmod 755 uploads logs
chmod 644 .env

# Instalar banco de dados
echo "🗄️  Instalando banco de dados..."
if [ -f database/install.sh ]; then
    chmod +x database/install.sh
    ./database/install.sh
else
    echo "⚠️  Script de instalação do banco não encontrado"
fi

# Testar conexão
echo "🔧 Testando configuração..."
node -e "
require('dotenv').config();
const db = require('./config/database');

(async () => {
    try {
        const connected = await db.testConnection();
        if (connected) {
            console.log('✅ Configuração concluída com sucesso!');
            console.log('🚀 Inicie o servidor com: npm start');
            console.log('🌐 Acesse: http://localhost:' + (process.env.PORT || 3000));
        } else {
            console.log('❌ Erro na configuração');
            process.exit(1);
        }
    } catch (error) {
        console.error('❌ Erro:', error.message);
        process.exit(1);
    }
})();
"
