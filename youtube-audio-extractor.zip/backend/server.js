/**
 * Configuração do Sistema de Email
 * Arquivo: backend/config/mailer.js
 */

const nodemailer = require('nodemailer');
const fs = require('fs').promises;
const path = require('path');
require('dotenv').config();

// Configuração do transporter
const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    },
    tls: {
        rejectUnauthorized: false
    }
});

// Verificar conexão com SMTP
async function verifyConnection() {
    try {
        await transporter.verify();
        console.log('✅ Conexão SMTP configurada com sucesso');
        return true;
    } catch (error) {
        console.error('❌ Erro na conexão SMTP:', error);
        return false;
    }
}

// Templates de email
const emailTemplates = {
    verification: {
        subject: 'Verifique sua conta - YouTube Audio Extractor',
        getHtml: (data) => `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #00BFFF, #1E90FF); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .button { display: inline-block; background: #00BFFF; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; }
                    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🎵 YouTube Audio Extractor Pro</h1>
                        <p>Verificação de Conta</p>
                    </div>
                    <div class="content">
                        <h2>Olá ${data.username}!</h2>
                        <p>Obrigado por se cadastrar no YouTube Audio Extractor Pro.</p>
                        <p>Para ativar sua conta, clique no botão abaixo:</p>
                        <p style="text-align: center; margin: 30px 0;">
                            <a href="${data.verificationUrl}" class="button">Verificar Minha Conta</a>
                        </p>
                        <p>Ou copie e cole este link no seu navegador:</p>
                        <p style="background: #eee; padding: 10px; border-radius: 5px; word-break: break-all;">
                            ${data.verificationUrl}
                        </p>
                        <p>Este link expira em 24 horas.</p>
                        <p>Se você não se cadastrou, ignore este email.</p>
                    </div>
                    <div class="footer">
                        <p>&copy; ${new Date().getFullYear()} YouTube Audio Extractor Pro. Todos os direitos reservados.</p>
                    </div>
                </div>
            </body>
            </html>
        `
    },
    
    welcome: {
        subject: 'Bem-vindo ao YouTube Audio Extractor Pro!',
        getHtml: (data) => `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #FFD700, #FFA500); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .feature { display: flex; align-items: center; margin: 15px 0; }
                    .feature i { color: #00BFFF; margin-right: 10px; font-size: 20px; }
                    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🎵 YouTube Audio Extractor Pro</h1>
                        <p>Sua conta foi ativada com sucesso!</p>
                    </div>
                    <div class="content">
                        <h2>Seja bem-vindo(a), ${data.username}!</h2>
                        <p>Sua conta foi verificada e está pronta para uso.</p>
                        
                        <h3>✨ O que você pode fazer agora:</h3>
                        
                        <div class="feature">
                            <i>🎬</i>
                            <div>
                                <strong>Extrair áudio do YouTube</strong>
                                <p>Converta vídeos em áudio de alta qualidade</p>
                            </div>
                        </div>
                        
                        <div class="feature">
                            <i>✂️</i>
                            <div>
                                <strong>Separar músicas automaticamente</strong>
                                <p>Detecta silêncios e cria faixas individuais</p>
                            </div>
                        </div>
                        
                        <div class="feature">
                            <i>📥</i>
                            <div>
                                <strong>Downloads ilimitados</strong>
                                <p>Baixe todas as faixas em formato MP3</p>
                            </div>
                        </div>
                        
                        <div style="text-align: center; margin: 30px 0;">
                            <a href="${data.dashboardUrl}" style="background: #00BFFF; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                                Começar a Extrair Áudio
                            </a>
                        </div>
                        
                        <p>Precisa de ajuda? Consulte nossa <a href="${data.helpUrl}">Central de Ajuda</a>.</p>
                    </div>
                    <div class="footer">
                        <p>&copy; ${new Date().getFullYear()} YouTube Audio Extractor Pro. Todos os direitos reservados.</p>
                    </div>
                </div>
            </body>
            </html>
        `
    },
    
    passwordReset: {
        subject: 'Redefinição de Senha - YouTube Audio Extractor',
        getHtml: (data) => `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #2ED573, #32CD32); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .button { display: inline-block; background: #2ED573; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; }
                    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🔐 YouTube Audio Extractor Pro</h1>
                        <p>Redefinição de Senha</p>
                    </div>
                    <div class="content">
                        <h2>Olá ${data.username}!</h2>
                        <p>Recebemos uma solicitação para redefinir a senha da sua conta.</p>
                        <p>Para criar uma nova senha, clique no botão abaixo:</p>
                        <p style="text-align: center; margin: 30px 0;">
                            <a href="${data.resetUrl}" class="button">Redefinir Minha Senha</a>
                        </p>
                        <p>Ou copie e cole este link no seu navegador:</p>
                        <p style="background: #eee; padding: 10px; border-radius: 5px; word-break: break-all;">
                            ${data.resetUrl}
                        </p>
                        <p><strong>Este link expira em 1 hora.</strong></p>
                        <p>Se você não solicitou a redefinição de senha, ignore este email e sua senha permanecerá a mesma.</p>
                        <p>Para sua segurança, nunca compartilhe este link com ninguém.</p>
                    </div>
                    <div class="footer">
                        <p>&copy; ${new Date().getFullYear()} YouTube Audio Extractor Pro. Todos os direitos reservados.</p>
                    </div>
                </div>
            </body>
            </html>
        `
    },
    
    processingComplete: {
        subject: 'Processamento concluído - YouTube Audio Extractor',
        getHtml: (data) => `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #8A2BE2, #9370DB); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .track { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #8A2BE2; }
                    .button { display: inline-block; background: #8A2BE2; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; }
                    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>✅ YouTube Audio Extractor Pro</h1>
                        <p>Processamento Concluído</p>
                    </div>
                    <div class="content">
                        <h2>Olá ${data.username}!</h2>
                        <p>Seu processamento de vídeo foi concluído com sucesso!</p>
                        
                        <div style="background: #e6f7ff; padding: 15px; border-radius: 5px; margin: 20px 0;">
                            <h3 style="margin-top: 0;">📹 Detalhes do Vídeo:</h3>
                            <p><strong>Título:</strong> ${data.videoTitle}</p>
                            <p><strong>Faixas geradas:</strong> ${data.tracksCount}</p>
                            <p><strong>Tamanho total:</strong> ${data.totalSize}</p>
                            <p><strong>Processado em:</strong> ${data.processedAt}</p>
                        </div>
                        
                        ${data.tracks && data.tracks.length > 0 ? `
                        <h3>🎵 Faixas Extraídas:</h3>
                        ${data.tracks.map(track => `
                            <div class="track">
                                <strong>${track.name}</strong>
                                <div style="color: #666; font-size: 14px;">
                                    ${track.size} • ${track.duration}
                                </div>
                            </div>
                        `).join('')}
                        ` : ''}
                        
                        <p style="text-align: center; margin: 30px 0;">
                            <a href="${data.downloadUrl}" class="button">Baixar Todas as Faixas</a>
                        </p>
                        
                        <p>Você também pode acessar seus vídeos pelo <a href="${data.dashboardUrl}">Dashboard</a>.</p>
                    </div>
                    <div class="footer">
                        <p>&copy; ${new Date().getFullYear()} YouTube Audio Extractor Pro. Todos os direitos reservados.</p>
                    </div>
                </div>
            </body>
            </html>
        `
    }
};

// Função para enviar email
async function sendEmail(to, templateName, data) {
    try {
        const template = emailTemplates[templateName];
        if (!template) {
            throw new Error(`Template de email não encontrado: ${templateName}`);
        }
        
        const mailOptions = {
            from: `"YouTube Audio Extractor Pro" <${process.env.SMTP_FROM || process.env.SMTP_USER}>`,
            to,
            subject: template.subject,
            html: template.getHtml(data)
        };
        
        const info = await transporter.sendMail(mailOptions);
        console.log(`✅ Email enviado para ${to}: ${info.messageId}`);
        return { success: true, messageId: info.messageId };
        
    } catch (error) {
        console.error(`❌ Erro ao enviar email para ${to}:`, error);
        return { success: false, error: error.message };
    }
}

// Função para enviar email de verificação
async function sendVerificationEmail(email, username, token) {
    const verificationUrl = `${process.env.FRONTEND_URL || 'http://localhost:8080'}/verify?token=${token}`;
    
    return await sendEmail(email, 'verification', {
        username,
        verificationUrl
    });
}

// Função para enviar email de boas-vindas
async function sendWelcomeEmail(email, username) {
    const dashboardUrl = `${process.env.FRONTEND_URL || 'http://localhost:8080'}/dashboard`;
    const helpUrl = `${process.env.FRONTEND_URL || 'http://localhost:8080'}/help`;
    
    return await sendEmail(email, 'welcome', {
        username,
        dashboardUrl,
        helpUrl
    });
}

// Função para enviar email de reset de senha
async function sendPasswordResetEmail(email, username, token) {
    const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:8080'}/reset-password?token=${token}`;
    
    return await sendEmail(email, 'passwordReset', {
        username,
        resetUrl
    });
}

// Função para enviar notificação de processamento concluído
async function sendProcessingCompleteEmail(email, username, videoData) {
    const downloadUrl = `${process.env.FRONTEND_URL || 'http://localhost:8080'}/download/${videoData.id}`;
    const dashboardUrl = `${process.env.FRONTEND_URL || 'http://localhost:8080'}/dashboard`;
    
    return await sendEmail(email, 'processingComplete', {
        username,
        videoTitle: videoData.title || 'Vídeo do YouTube',
        tracksCount: videoData.tracksCount || 0,
        totalSize: videoData.totalSize || '0 MB',
        processedAt: new Date().toLocaleString('pt-BR'),
        tracks: videoData.tracks || [],
        downloadUrl,
        dashboardUrl
    });
}

// Exportar funções
module.exports = {
    transporter,
    verifyConnection,
    sendEmail,
    sendVerificationEmail,
    sendWelcomeEmail,
    sendPasswordResetEmail,
    sendProcessingCompleteEmail,
    emailTemplates
};