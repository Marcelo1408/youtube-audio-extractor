// backend/config/database.js

const mariadb = require('mariadb');
require('dotenv').config();

// Configuração do pool de conexões
const pool = mariadb.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'youtube_audio_extractor',
    connectionLimit: process.env.DB_POOL_MAX || 10,
    idleTimeout: 30000,
    acquireTimeout: 30000,
    connectTimeout: 10000,
    trace: process.env.NODE_ENV === 'development'
});

// Testar conexão
async function testConnection() {
    let conn;
    try {
        conn = await pool.getConnection();
        console.log('✅ Conectado ao MariaDB');
        
        // Verificar tabelas
        const tables = await conn.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = ?
        `, [process.env.DB_NAME || 'youtube_audio_extractor']);
        
        console.log(`📊 ${tables.length} tabelas encontradas`);
        
        return true;
    } catch (error) {
        console.error('❌ Erro ao conectar ao MariaDB:', error.message);
        return false;
    } finally {
        if (conn) conn.release();
    }
}

// Função para executar queries com tratamento de erro
async function executeQuery(sql, params = []) {
    let conn;
    try {
        conn = await pool.getConnection();
        const result = await conn.query(sql, params);
        return { success: true, data: result };
    } catch (error) {
        console.error('Erro na query:', error);
        return { 
            success: false, 
            error: error.message,
            code: error.code
        };
    } finally {
        if (conn) conn.release();
    }
}

// Função para transações
async function executeTransaction(queries) {
    let conn;
    try {
        conn = await pool.getConnection();
        await conn.beginTransaction();
        
        const results = [];
        for (const query of queries) {
            const result = await conn.query(query.sql, query.params || []);
            results.push(result);
        }
        
        await conn.commit();
        return { success: true, results };
    } catch (error) {
        if (conn) await conn.rollback();
        console.error('Erro na transação:', error);
        return { success: false, error: error.message };
    } finally {
        if (conn) conn.release();
    }
}

// Migrações do banco de dados
async function runMigrations() {
    const migrations = [
        // Adicionar colunas se necessário no futuro
        `ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_url VARCHAR(500)`,
        `ALTER TABLE videos ADD COLUMN IF NOT EXISTS processed_size BIGINT`,
        `CREATE INDEX IF NOT EXISTS idx_audio_tracks_type ON audio_tracks(track_type)`
    ];
    
    let conn;
    try {
        conn = await pool.getConnection();
        console.log('🔄 Executando migrações...');
        
        for (const migration of migrations) {
            try {
                await conn.query(migration);
                console.log(`✅ Migração executada: ${migration.substring(0, 50)}...`);
            } catch (error) {
                if (!error.message.includes('already exists')) {
                    console.warn(`⚠️  Erro na migração: ${error.message}`);
                }
            }
        }
        
        console.log('✅ Migrações concluídas');
    } catch (error) {
        console.error('❌ Erro nas migrações:', error);
    } finally {
        if (conn) conn.release();
    }
}

// Backups automáticos
async function createBackup() {
    if (process.env.NODE_ENV !== 'production') return;
    
    const backupDir = './database/backups';
    const fs = require('fs').promises;
    const { exec } = require('child_process');
    const util = require('util');
    const execPromise = util.promisify(exec);
    
    try {
        await fs.mkdir(backupDir, { recursive: true });
        
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupFile = `${backupDir}/backup-${timestamp}.sql`;
        
        const command = `mysqldump -h ${process.env.DB_HOST} -u ${process.env.DB_USER} -p${process.env.DB_PASSWORD} ${process.env.DB_NAME} > ${backupFile}`;
        
        await execPromise(command);
        console.log(`✅ Backup criado: ${backupFile}`);
        
        // Manter apenas últimos 7 backups
        const files = await fs.readdir(backupDir);
        const sqlFiles = files.filter(f => f.endsWith('.sql')).sort();
        
        if (sqlFiles.length > 7) {
            const toDelete = sqlFiles.slice(0, sqlFiles.length - 7);
            for (const file of toDelete) {
                await fs.unlink(`${backupDir}/${file}`);
                console.log(`🗑️  Backup antigo removido: ${file}`);
            }
        }
    } catch (error) {
        console.error('❌ Erro no backup:', error);
    }
}

// Monitoramento de saúde do banco
async function checkDatabaseHealth() {
    let conn;
    try {
        conn = await pool.getConnection();
        
        // Verificar conexões ativas
        const [connections] = await conn.query(`
            SELECT COUNT(*) as active_connections 
            FROM information_schema.processlist 
            WHERE db = ?
        `, [process.env.DB_NAME]);
        
        // Verificar tamanho do banco
        const [size] = await conn.query(`
            SELECT 
                ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
            FROM information_schema.tables 
            WHERE table_schema = ?
        `, [process.env.DB_NAME]);
        
        // Verificar locks
        const [locks] = await conn.query(`
            SELECT COUNT(*) as lock_count 
            FROM information_schema.innodb_locks
        `);
        
        return {
            healthy: true,
            activeConnections: connections[0].active_connections,
            databaseSize: `${size[0].size_mb} MB`,
            lockCount: locks[0].lock_count,
            timestamp: new Date().toISOString()
        };
    } catch (error) {
        console.error('❌ Erro no health check:', error);
        return { healthy: false, error: error.message };
    } finally {
        if (conn) conn.release();
    }
}

// Exportar funções
module.exports = {
    pool,
    testConnection,
    executeQuery,
    executeTransaction,
    runMigrations,
    createBackup,
    checkDatabaseHealth,
    
    // Helper para queries comuns
    async findUserByEmail(email) {
        const result = await executeQuery(
            'SELECT * FROM users WHERE email = ?', 
            [email]
        );
        return result.success ? result.data[0] : null;
    },
    
    async findUserById(id) {
        const result = await executeQuery(
            'SELECT id, email, username, role, email_verified, created_at FROM users WHERE id = ?',
            [id]
        );
        return result.success ? result.data[0] : null;
    },
    
    async getSystemSettings() {
        const result = await executeQuery(
            'SELECT setting_key, setting_value FROM system_settings'
        );
        
        if (!result.success) return {};
        
        const settings = {};
        result.data.forEach(setting => {
            settings[setting.setting_key] = setting.setting_value;
        });
        
        return settings;
    },
    
    async updateSystemSetting(key, value) {
        return await executeQuery(
            `INSERT INTO system_settings (setting_key, setting_value) 
             VALUES (?, ?) 
             ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()`,
            [key, value, value]
        );
    }
};

// Inicializar banco
if (require.main === module) {
    (async () => {
        console.log('🔧 Inicializando configuração do banco de dados...');
        
        const connected = await testConnection();
        if (connected) {
            await runMigrations();
            
            // Agendar backups diários em produção
            if (process.env.NODE_ENV === 'production') {
                console.log('⏰ Agendando backups automáticos...');
                setInterval(createBackup, 24 * 60 * 60 * 1000); // Diariamente
            }
            
            // Health check periódico
            setInterval(async () => {
                const health = await checkDatabaseHealth();
                if (!health.healthy) {
                    console.error('🚨 Problema de saúde do banco detectado:', health);
                }
            }, 5 * 60 * 1000); // A cada 5 minutos
        }
    })();
}