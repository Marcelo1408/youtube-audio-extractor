/**
 * Rotas de Autenticação
 * Arquivo: backend/routes/auth.js
 */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { body, validationResult } = require('express-validator');
const { pool } = require('../config/database');
const {
    sendVerificationEmail,
    sendWelcomeEmail,
    sendPasswordResetEmail
} = require('../config/mailer');
const { generateToken, verifyToken } = require('../utils/security');
const passport = require('../config/google-auth').passport;

// Middleware para log de atividade
async function logActivity(userId, action, details = {}) {
    try {
        const conn = await pool.getConnection();
        await conn.query(
            `INSERT INTO activity_logs (user_id, action, details, ip_address, user_agent, created_at)
             VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
            [
                userId,
                action,
                JSON.stringify(details),
                details.ip || 'unknown',
                details.userAgent || 'unknown'
            ]
        );
        conn.release();
    } catch (error) {
        console.error('Erro ao registrar atividade:', error);
    }
}

// Validações de registro
const registerValidation = [
    body('username')
        .trim()
        .isLength({ min: 3, max: 50 })
        .withMessage('Username deve ter entre 3 e 50 caracteres')
        .matches(/^[a-zA-Z0-9_.-]+$/)
        .withMessage('Username só pode conter letras, números, pontos, underscores e hífens'),
    
    body('email')
        .trim()
        .isEmail()
        .withMessage('Email inválido')
        .normalizeEmail(),
    
    body('password')
        .isLength({ min: 8 })
        .withMessage('Senha deve ter pelo menos 8 caracteres')
        .matches(/[A-Z]/)
        .withMessage('Senha deve conter pelo menos uma letra maiúscula')
        .matches(/[0-9]/)
        .withMessage('Senha deve conter pelo menos um número')
        .matches(/[^A-Za-z0-9]/)
        .withMessage('Senha deve conter pelo menos um caractere especial'),
    
    body('confirmPassword')
        .custom((value, { req }) => value === req.body.password)
        .withMessage('As senhas não coincidem'),
    
    body('phone')
        .optional({ checkFalsy: true })
        .matches(/^\(?\d{2}\)?[\s-]?\d{4,5}-?\d{4}$/)
        .withMessage('Telefone inválido')
];

// Rota de registro
router.post('/register', registerValidation, async (req, res) => {
    try {
        // Validar dados
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Erro de validação',
                errors: errors.array()
            });
        }
        
        const { username, email, password, phone } = req.body;
        const conn = await pool.getConnection();
        
        try {
            // Verificar se email já existe
            const [existingEmail] = await conn.query(
                'SELECT id FROM users WHERE email = ?',
                [email]
            );
            
            if (existingEmail) {
                return res.status(400).json({
                    success: false,
                    message: 'Email já cadastrado'
                });
            }
            
            // Verificar se username já existe
            const [existingUsername] = await conn.query(
                'SELECT id FROM users WHERE username = ?',
                [username]
            );
            
            if (existingUsername) {
                return res.status(400).json({
                    success: false,
                    message: 'Username já está em uso'
                });
            }
            
            // Hash da senha
            const hashedPassword = await bcrypt.hash(password, 10);
            
            // Gerar token de verificação
            const verificationToken = crypto.randomBytes(32).toString('hex');
            const verificationExpires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 horas
            
            // Inserir usuário
            const [result] = await conn.query(
                `INSERT INTO users (
                    username,
                    email,
                    password,
                    phone,
                    verification_token,
                    verification_expires,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
                [
                    username,
                    email,
                    hashedPassword,
                    phone || null,
                    verificationToken,
                    verificationExpires
                ]
            );
            
            // Log da atividade
            await logActivity(result.insertId, 'register', {
                email,
                username,
                ip: req.ip,
                userAgent: req.get('User-Agent')
            });
            
            // Enviar email de verificação
            await sendVerificationEmail(email, username, verificationToken);
            
            // Gerar token JWT (opcional para login automático)
            const token = generateToken({
                id: result.insertId,
                email,
                username
            });
            
            res.status(201).json({
                success: true,
                message: 'Conta criada! Verifique seu email para ativar sua conta.',
                token,
                user: {
                    id: result.insertId,
                    username,
                    email,
                    is_verified: false
                }
            });
            
        } finally {
            conn.release();
        }
        
    } catch (error) {
        console.error('Erro no registro:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor'
        });
    }
});

// Validações de login
const loginValidation = [
    body('email')
        .trim()
        .isEmail()
        .withMessage('Email inválido')
        .normalizeEmail(),
    
    body('password')
        .notEmpty()
        .withMessage('Senha é obrigatória')
];

// Rota de login
router.post('/login', loginValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Erro de validação',
                errors: errors.array()
            });
        }
        
        const { email, password, remember } = req.body;
        const conn = await pool.getConnection();
        
        try {
            // Buscar usuário
            const [user] = await conn.query(
                'SELECT * FROM users WHERE email = ?',
                [email]
            );
            
            if (!user) {
                return res.status(401).json({
                    success: false,
                    message: 'Email ou senha incorretos'
                });
            }
            
            // Verificar senha
            const validPassword = await bcrypt.compare(password, user.password);
            if (!validPassword) {
                return res.status(401).json({
                    success: false,
                    message: 'Email ou senha incorretos'
                });
            }
            
            // Verificar se conta está ativa
            if (!user.is_verified) {
                return res.status(403).json({
                    success: false,
                    message: 'Conta não verificada. Verifique seu email.'
                });
            }
            
            // Atualizar último login
            await conn.query(
                'UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                [user.id]
            );
            
            // Log da atividade
            await logActivity(user.id, 'login', {
                email,
                remember: !!remember,
                ip: req.ip,
                userAgent: req.get('User-Agent')
            });
            
            // Gerar token JWT
            const token = generateToken({
                id: user.id,
                email: user.email,
                username: user.username,
                role: user.role
            });
            
            // Configurar cookie se "lembrar-me" estiver marcado
            if (remember) {
                res.cookie('auth_token', token, {
                    httpOnly: true,
                    secure: process.env.NODE_ENV === 'production',
                    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 dias
                    sameSite: 'strict'
                });
            }
            
            res.json({
                success: true,
                message: 'Login realizado com sucesso',
                token,
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    avatar_url: user.avatar_url,
                    is_verified: user.is_verified
                }
            });
            
        } finally {
            conn.release();
        }
        
    } catch (error) {
        console.error('Erro no login:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor'
        });
    }
});

// Rota de verificação de email
router.get('/verify/:token', async (req, res) => {
    try {
        const { token } = req.params;
        const conn = await pool.getConnection();
        
        try {
            // Buscar usuário pelo token
            const [user] = await conn.query(
                `SELECT * FROM users 
                 WHERE verification_token = ? 
                 AND verification_expires > NOW()`,
                [token]
            );
            
            if (!user) {
                return res.status(400).json({
                    success: false,
                    message: 'Token de verificação inválido ou expirado'
                });
            }
            
            // Ativar conta
            await conn.query(
                `UPDATE users SET 
                    is_verified = TRUE,
                    verification_token = NULL,
                    verification_expires = NULL,
                    updated_at = CURRENT_TIMESTAMP
                 WHERE id = ?`,
                [user.id]
            );
            
            // Log da atividade
            await logActivity(user.id, 'email_verified', {
                token,
                ip: req.ip
            });
            
            // Enviar email de boas-vindas
            await sendWelcomeEmail(user.email, user.username);
            
            res.json({
                success: true,
                message: 'Conta verificada com sucesso! Você já pode fazer login.'
            });
            
        } finally {
            conn.release();
        }
        
    } catch (error) {
        console.error('Erro na verificação:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor'
        });
    }
});

// Rota para reenviar email de verificação
router.post('/resend-verification', [
    body('email').isEmail().normalizeEmail()
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Email inválido'
            });
        }
        
        const { email } = req.body;
        const conn = await pool.getConnection();
        
        try {
            // Buscar usuário
            const [user] = await conn.query(
                'SELECT * FROM users WHERE email = ?',
                [email]
            );
            
            if (!user) {
                return res.status(404).json({
                    success: false,
                    message: 'Usuário não encontrado'
                });
            }
            
            if (user.is_verified) {
                return res.status(400).json({
                    success: false,
                    message: 'Conta já verificada'
                });
            }
            
            // Gerar novo token
            const verificationToken = crypto.randomBytes(32).toString('hex');
            const verificationExpires = new Date(Date.now() + 24 * 60 * 60 * 1000);
            
            // Atualizar token
            await conn.query(
                `UPDATE users SET 
                    verification_token = ?,
                    verification_expires = ?,
                    updated_at = CURRENT_TIMESTAMP
                 WHERE id = ?`,
                [verificationToken, verificationExpires, user.id]
            );
            
            // Enviar email
            await sendVerificationEmail(email, user.username, verificationToken);
            
            // Log da atividade
            await logActivity(user.id, 'resend_verification', {
                email,
                ip: req.ip
            });
            
            res.json({
                success: true,
                message: 'Email de verificação reenviado!'
            });
            
        } finally {
            conn.release();
        }
        
    } catch (error) {
        console.error('Erro ao reenviar verificação:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor'
        });
    }
});

// Rota para solicitar reset de senha
router.post('/forgot-password', [
    body('email').isEmail().normalizeEmail()
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Email inválido'
            });
        }
        
        const { email } = req.body;
        const conn = await pool.getConnection();
        
        try {
            // Buscar usuário
            const [user] = await conn.query(
                'SELECT * FROM users WHERE email = ?',
                [email]
            );
            
            if (!user) {
                // Por segurança, não revelar que o email não existe
                return res.json({
                    success: true,
                    message: 'Se o email existir, você receberá instruções para resetar sua senha'
                });
            }
            
            // Gerar token de reset
            const resetToken = crypto.randomBytes(32).toString('hex');
            const resetExpires = new Date(Date.now() + 1 * 60 * 60 * 1000); // 1 hora
            
            // Atualizar usuário
            await conn.query(
                `UPDATE users SET 
                    reset_token = ?,
                    reset_expires = ?,
                    updated_at = CURRENT_TIMESTAMP
                 WHERE id = ?`,
                [resetToken, resetExpires, user.id]
            );
            
            // Enviar email
            await sendPasswordResetEmail(email, user.username, resetToken);
            
            // Log da atividade
            await logActivity(user.id, 'forgot_password', {
                email,
                ip: req.ip
            });
            
            res.json({
                success: true,
                message: 'Se o email existir, você receberá instruções para resetar sua senha'
            });
            
        } finally {
            conn.release();
        }
        
    } catch (error) {
        console.error('Erro no forgot-password:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor'
        });
    }
});

// Validações para reset de senha
const resetPasswordValidation = [
    body('token').notEmpty().withMessage('Token é obrigatório'),
    body('password')
        .isLength({ min: 8 })
        .withMessage('Senha deve ter pelo menos 8 caracteres')
        .matches(/[A-Z]/)
        .withMessage('Senha deve conter pelo menos uma letra maiúscula')
        .matches(/[0-9]/)
        .withMessage('Senha deve conter pelo menos um número')
        .matches(/[^A-Za-z0-9]/)
        .withMessage('Senha deve conter pelo menos um caractere especial'),
    body('confirmPassword')
        .custom((value, { req }) => value === req.body.password)
        .withMessage('As senhas não coincidem')
];

// Rota para resetar senha
router.post('/reset-password', resetPasswordValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Erro de validação',
                errors: errors.array()
            });
        }
        
        const { token, password } = req.body;
        const conn = await pool.getConnection();
        
        try {
            // Buscar usuário pelo token
            const [user] = await conn.query(
                `SELECT * FROM users 
                 WHERE reset_token = ? 
                 AND reset_expires > NOW()`,
                [token]
            );
            
            if (!user) {
                return res.status(400).json({
                    success: false,
                    message: 'Token de reset inválido ou expirado'
                });
            }
            
            // Hash da nova senha
            const hashedPassword = await bcrypt.hash(password, 10);
            
            // Atualizar senha e limpar token
            await conn.query(
                `UPDATE users SET 
                    password = ?,
                    reset_token = NULL,
                    reset_expires = NULL,
                    updated_at = CURRENT_TIMESTAMP
                 WHERE id = ?`,
                [hashedPassword, user.id]
            );
            
            // Log da atividade
            await logActivity(user.id, 'password_reset', {
                ip: req.ip,
                userAgent: req.get('User-Agent')
            });
            
            res.json({
                success: true,
                message: 'Senha alterada com sucesso!'
            });
            
        } finally {
            conn.release();
        }
        
    } catch (error) {
        console.error('Erro no reset-password:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor'
        });
    }
});

// Rotas do Google OAuth
router.get('/google', passport.authenticate('google', {
    scope: ['profile', 'email'],
    prompt: 'select_account'
}));

router.get('/google/callback',
    passport.authenticate('google', { failureRedirect: '/login?error=google' }),
    async (req, res) => {
        try {
            // Gerar token JWT
            const token = generateToken({
                id: req.user.id,
                email: req.user.email,
                username: req.user.username,
                role: req.user.role
            });
            
            // Redirecionar para frontend com token
            const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:8080';
            res.redirect(`${frontendUrl}/auth/google/callback?token=${token}`);
            
        } catch (error) {
            console.error('Erro no callback do Google:', error);
            res.redirect('/login?error=server');
        }
    }
);

// Rota para logout
router.post('/logout', async (req, res) => {
    try {
        const token = req.headers.authorization