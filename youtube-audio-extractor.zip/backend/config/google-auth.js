/**
 * Rotas de Autenticação
 * Arquivo: backend/routes/auth.js
 * Versão: 2.0 - Simplificada e Otimizada
 */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { body, validationResult } = require('express-validator');
const { pool } = require('../config/database');
const authService = require('../services/authService');
const emailService = require('../services/emailService');
const activityLogger = require('../middleware/activityLogger');
const { generateToken, verifyToken } = require('../utils/security');

// Middleware de validação centralizado
const validateRequest = (validations) => {
    return async (req, res, next) => {
        await Promise.all(validations.map(validation => validation.run(req)));
        const errors = validationResult(req);
        
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Erro de validação',
                errors: errors.array()
            });
        }
        next();
    };
};

// Validações compartilhadas
const validations = {
    email: body('email')
        .trim()
        .isEmail()
        .withMessage('Email inválido')
        .normalizeEmail(),
    
    password: body('password')
        .isLength({ min: 6 })
        .withMessage('Senha deve ter pelo menos 6 caracteres'),
    
    username: body('username')
        .trim()
        .isLength({ min: 3, max: 30 })
        .withMessage('Username deve ter entre 3 e 30 caracteres')
        .matches(/^[a-zA-Z0-9_.-]+$/)
        .withMessage('Username pode conter apenas letras, números, pontos, underscores e hífens'),
    
    confirmPassword: body('confirmPassword')
        .custom((value, { req }) => value === req.body.password)
        .withMessage('As senhas não coincidem'),
    
    token: body('token')
        .notEmpty()
        .withMessage('Token é obrigatório')
};

// ==================== REGISTRO ====================
router.post('/register', validateRequest([
    validations.username,
    validations.email,
    validations.password,
    validations.confirmPassword
]), async (req, res) => {
    try {
        const { username, email, password } = req.body;
        
        // Verificar se usuário já existe
        const userExists = await authService.checkUserExists(email, username);
        if (userExists) {
            return res.status(400).json({
                success: false,
                message: userExists
            });
        }
        
        // Criar usuário
        const user = await authService.createUser({
            username,
            email,
            password,
            ip: req.ip,
            userAgent: req.headers['user-agent']
        });
        
        // Registrar atividade
        await activityLogger.log(user.id, 'REGISTER', {
            email,
            username,
            ip: req.ip
        });
        
        // Enviar email de verificação
        await emailService.sendVerificationEmail(email, username, user.verificationToken);
        
        res.status(201).json({
            success: true,
            message: 'Conta criada com sucesso! Verifique seu email.',
            data: {
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    isVerified: false
                }
            }
        });
        
    } catch (error) {
        console.error('Erro no registro:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao criar conta. Tente novamente.'
        });
    }
});

// ==================== LOGIN ====================
router.post('/login', validateRequest([
    validations.email,
    body('password').notEmpty().withMessage('Senha é obrigatória')
]), async (req, res) => {
    try {
        const { email, password, rememberMe } = req.body;
        
        // Autenticar usuário
        const authResult = await authService.authenticateUser(email, password);
        
        if (!authResult.success) {
            return res.status(401).json({
                success: false,
                message: authResult.message
            });
        }
        
        const user = authResult.user;
        
        // Verificar se a conta está ativa
        if (!user.isVerified) {
            return res.status(403).json({
                success: false,
                message: 'Conta não verificada. Verifique seu email.',
                data: {
                    requiresVerification: true,
                    email: user.email
                }
            });
        }
        
        // Atualizar último login
        await authService.updateLastLogin(user.id);
        
        // Registrar atividade
        await activityLogger.log(user.id, 'LOGIN', {
            email,
            rememberMe: !!rememberMe,
            ip: req.ip
        });
        
        // Gerar token JWT
        const token = generateToken({
            id: user.id,
            email: user.email,
            username: user.username,
            role: user.role
        });
        
        // Configurar resposta
        const response = {
            success: true,
            message: 'Login realizado com sucesso!',
            data: {
                token,
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    isVerified: user.isVerified
                }
            }
        };
        
        // Configurar cookie se "lembrar-me" estiver ativo
        if (rememberMe) {
            res.cookie('auth_token', token, {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                maxAge: 30 * 24 * 60 * 60 * 1000, // 30 dias
                sameSite: 'strict',
                path: '/'
            });
        }
        
        res.json(response);
        
    } catch (error) {
        console.error('Erro no login:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao fazer login. Tente novamente.'
        });
    }
});

// ==================== VERIFICAÇÃO DE EMAIL ====================
router.get('/verify-email/:token', async (req, res) => {
    try {
        const { token } = req.params;
        
        // Verificar token
        const verificationResult = await authService.verifyEmailToken(token);
        
        if (!verificationResult.success) {
            return res.status(400).json({
                success: false,
                message: verificationResult.message
            });
        }
        
        const user = verificationResult.user;
        
        // Registrar atividade
        await activityLogger.log(user.id, 'EMAIL_VERIFIED', {
            ip: req.ip
        });
        
        // Enviar email de boas-vindas
        await emailService.sendWelcomeEmail(user.email, user.username);
        
        res.json({
            success: true,
            message: 'Email verificado com sucesso!',
            data: {
                user: {
                    id: user.id,
                    email: user.email,
                    username: user.username
                }
            }
        });
        
    } catch (error) {
        console.error('Erro na verificação de email:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao verificar email.'
        });
    }
});

// ==================== REENVIAR VERIFICAÇÃO ====================
router.post('/resend-verification', validateRequest([validations.email]), async (req, res) => {
    try {
        const { email } = req.body;
        
        const result = await authService.resendVerificationEmail(email);
        
        if (!result.success) {
            return res.status(result.status || 400).json({
                success: false,
                message: result.message
            });
        }
        
        // Registrar atividade
        await activityLogger.log(result.userId, 'RESEND_VERIFICATION', {
            email,
            ip: req.ip
        });
        
        res.json({
            success: true,
            message: 'Email de verificação reenviado com sucesso!'
        });
        
    } catch (error) {
        console.error('Erro ao reenviar verificação:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao reenviar email de verificação.'
        });
    }
});

// ==================== ESQUECI A SENHA ====================
router.post('/forgot-password', validateRequest([validations.email]), async (req, res) => {
    try {
        const { email } = req.body;
        
        const result = await authService.initiatePasswordReset(email);
        
        if (result.success) {
            // Registrar atividade apenas se usuário existir
            if (result.userId) {
                await activityLogger.log(result.userId, 'PASSWORD_RESET_REQUEST', {
                    email,
                    ip: req.ip
                });
            }
        }
        
        // Sempre retornar sucesso por segurança
        res.json({
            success: true,
            message: 'Se o email existir em nosso sistema, você receberá instruções para redefinir sua senha.'
        });
        
    } catch (error) {
        console.error('Erro em forgot-password:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao processar solicitação.'
        });
    }
});

// ==================== REDEFINIR SENHA ====================
router.post('/reset-password', validateRequest([
    validations.token,
    validations.password,
    validations.confirmPassword
]), async (req, res) => {
    try {
        const { token, password } = req.body;
        
        const result = await authService.resetPassword(token, password);
        
        if (!result.success) {
            return res.status(400).json({
                success: false,
                message: result.message
            });
        }
        
        // Registrar atividade
        await activityLogger.log(result.userId, 'PASSWORD_RESET', {
            ip: req.ip
        });
        
        res.json({
            success: true,
            message: 'Senha redefinida com sucesso!'
        });
        
    } catch (error) {
        console.error('Erro ao redefinir senha:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao redefinir senha.'
        });
    }
});

// ==================== LOGOUT ====================
router.post('/logout', async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        
        if (token) {
            // Aqui você pode adicionar lógica para invalidar tokens
            // Ex: Adicionar token a uma blacklist
            await authService.invalidateToken(token);
        }
        
        // Limpar cookie
        res.clearCookie('auth_token', {
            path: '/'
        });
        
        res.json({
            success: true,
            message: 'Logout realizado com sucesso!'
        });
        
    } catch (error) {
        console.error('Erro no logout:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao fazer logout.'
        });
    }
});

// ==================== VERIFICAR AUTENTICAÇÃO ====================
router.get('/me', async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1] || req.cookies.auth_token;
        
        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'Não autenticado'
            });
        }
        
        // Verificar token
        const decoded = verifyToken(token);
        if (!decoded) {
            return res.status(401).json({
                success: false,
                message: 'Token inválido ou expirado'
            });
        }
        
        // Buscar informações do usuário
        const user = await authService.getUserById(decoded.id);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado'
            });
        }
        
        res.json({
            success: true,
            data: {
                user: {
                    id: user.id,
                    username: user.username,
                    email: user.email,
                    role: user.role,
                    isVerified: user.isVerified,
                    createdAt: user.created_at
                }
            }
        });
        
    } catch (error) {
        console.error('Erro ao verificar autenticação:', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao verificar autenticação'
        });
    }
});

// ==================== ROTA DE SAÚDE DA AUTENTICAÇÃO ====================
router.get('/health', (req, res) => {
    res.json({
        success: true,
        message: 'Sistema de autenticação operacional',
        timestamp: new Date().toISOString(),
        version: '2.0'
    });
});

module.exports = router;