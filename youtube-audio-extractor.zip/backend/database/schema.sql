-- backend/database/schema.sql
CREATE DATABASE IF NOT EXISTS youtube_audio_extractor;
USE youtube_audio_extractor;

-- Tabela de usuários
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    google_id VARCHAR(255) UNIQUE,
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255),
    phone VARCHAR(20),
    role ENUM('free', 'premium', 'admin') DEFAULT 'free',
    email_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(255),
    verification_expires DATETIME,
    reset_token VARCHAR(255),
    reset_expires DATETIME,
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_google_id (google_id)
);

-- Tabela de vídeos processados
CREATE TABLE videos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    video_id VARCHAR(100) NOT NULL,
    title VARCHAR(500) NOT NULL,
    duration INT NOT NULL,
    url TEXT NOT NULL,
    status ENUM('processing', 'downloading', 'extracting_audio', 'separating_tracks', 'completed', 'failed') DEFAULT 'processing',
    quality INT DEFAULT 128,
    separate_tracks BOOLEAN DEFAULT TRUE,
    audio_path TEXT,
    video_path TEXT,
    zip_path TEXT,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- Tabela de faixas de áudio separadas
CREATE TABLE audio_tracks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    video_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    track_type VARCHAR(50),
    duration INT,
    file_size BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
    INDEX idx_video_id (video_id)
);

-- Tabela de logs de atividades
CREATE TABLE activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    activity_type VARCHAR(100) NOT NULL,
    details JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_activity_type (activity_type),
    INDEX idx_created_at (created_at)
);

-- Tabela de configurações do sistema
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_setting_key (setting_key)
);

-- Tabela de sessões (para session store)
CREATE TABLE sessions (
    session_id VARCHAR(128) PRIMARY KEY,
    expires TIMESTAMP NOT NULL,
    data TEXT,
    INDEX idx_expires (expires)
);

-- Inserir configurações padrão
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('daily_limit_free', '5', 'Limite diário de processamentos para usuários free'),
('daily_limit_premium', '50', 'Limite diário de processamentos para usuários premium'),
('max_duration_free', '1800', 'Duração máxima em segundos para vídeos free (30 minutos)'),
('max_duration_premium', '7200', 'Duração máxima em segundos para vídeos premium (2 horas)'),
('site_name', 'YouTube Audio Extractor', 'Nome do site'),
('site_url', 'http://localhost:3000', 'URL do site'),
('contact_email', 'suporte@example.com', 'Email de contato'),
('smtp_host', 'smtp.gmail.com', 'Host SMTP para emails'),
('smtp_port', '587', 'Porta SMTP'),
('smtp_secure', 'false', 'Conexão segura SMTP'),
('allowed_formats', 'mp3,wav,flac', 'Formatos de áudio permitidos'),
('max_file_size', '104857600', 'Tamanho máximo de arquivo em bytes (100MB)'),
('maintenance_mode', 'false', 'Modo de manutenção do sistema'),
('registration_enabled', 'true', 'Permitir novos cadastros'),
('google_auth_enabled', 'true', 'Permitir login com Google');

-- Criar usuário admin padrão (senha: Admin123!)
INSERT INTO users (email, username, password_hash, role, email_verified) 
VALUES ('admin@example.com', 'Administrador', '$2a$10$YourHashedPasswordHere', 'admin', TRUE);

-- Criar índices adicionais para performance
CREATE INDEX idx_videos_completed ON videos(status, completed_at);
CREATE INDEX idx_users_verification ON users(verification_token, verification_expires);
CREATE INDEX idx_users_reset ON users(reset_token, reset_expires);