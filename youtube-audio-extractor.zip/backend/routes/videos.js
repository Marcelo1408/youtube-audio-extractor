/**
 * Rotas de Vídeos
 * Arquivo: backend/routes/videos.js
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const { pool } = require('../config/database');
const { authMiddleware } = require('./auth');
const ytdl = require('ytdl-core');
const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs').promises;
const path = require('path');
const crypto = require('crypto');
const { logActivity } = require('./auth');
const archiver = require('archiver');
const { spawn } = require('child_process');

// Middleware para verificar limites do usuário
async function checkUserLimits(req, res, next) {
    try {
        const userId = req.userId;
        const conn = await pool.getConnection();
        
        try {
            // Buscar configurações do sistema
            const [settings] = await conn.query(
                'SELECT * FROM system_settings WHERE setting_key IN (?, ?)',
                ['daily_limit_free', 'daily_limit_premium']
            );
            
            const settingsMap = {};
            settings.forEach(setting => {
                settingsMap[setting.setting_key] = parseInt(setting.setting_value);
            });
            
            // Buscar dados do usuário
            const [user] = await conn.query(
                'SELECT role FROM users WHERE id = ?',
                [userId]
            );
            
            if (!user) {
                return res.status(404).json({
                    success: false,
                    message: 'Usuário não encontrado'
                });
            }
            
            const dailyLimit = user.role === 'premium' 
                ? settingsMap['daily_limit_premium'] || 50
                : settingsMap['daily_limit_free'] || 5;
            
            // Contar processamentos hoje
            const today = new Date().toISOString().split('T')[0];
            const [countResult] = await conn.query(
                `SELECT COUNT(*) as count FROM videos 
                 WHERE user_id = ? 
                 AND DATE(created_at) = ?`,
                [userId, today]
            );
            
            if (countResult.count >= dailyLimit) {
                return res.status(429).json({
                    success: false,
                    message: `Limite diário atingido (${dailyLimit} vídeos por dia). Upgrade para premium para aumentar o limite.`
                });
            }
            
            next();
            
        } finally {
            conn.release();
        }
        
    } catch (error) {
        console.error('Erro ao verificar limites:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor'
        });
    }
}

// Validação para informações do vídeo
const videoInfoValidation = [
    body('url')
        .notEmpty()
        .withMessage('URL é obrigatória')
        .custom(value => {
            return ytdl.validateURL(value) || value.includes('youtu.be');
        })
        .withMessage('URL do YouTube inválida')
];

// Rota para obter informações do vídeo
router.post('/info', authMiddleware, videoInfoValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'URL do YouTube inválida',
                errors: errors.array()
            });
        }
        
        const { url } = req.body;
        
        try {
            // Obter informações do vídeo
            const info = await ytdl.getInfo(url);
            
            const videoInfo = {
                success: true,
                title: info.videoDetails.title,
                description: info.videoDetails.description,
                duration: parseInt(info.videoDetails.lengthSeconds),
                thumbnail: info.videoDetails.thumbnails[info.videoDetails.thumbnails.length - 1]?.url,
                channel: info.videoDetails.author.name,
                views: parseInt(info.videoDetails.viewCount) || 0,
                date: info.videoDetails.publishDate || info.videoDetails.uploadDate,
                videoId: info.videoDetails.videoId
            };
            
            // Log da atividade
            await logActivity(req.userId, 'video_info', {
                url,
                videoId: videoInfo.videoId,
                title: videoInfo.title
            });
            
            res.json(videoInfo);
            
        } catch (error) {
            console.error('Erro ao obter informações do vídeo:', error);
            res.status(400).json({
                success: false,
                message: 'Não foi possível obter informações do vídeo. Verifique a URL.'
            });
        }
        
    } catch (error) {
        console.error('Erro na rota de informações:', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor'
        });
    }
});

// Validação para processamento de vídeo
const processVideoValidation = [
    body('url')
        .notEmpty()
        .withMessage('URL é obrigatória')
        .custom(value => ytdl.validateURL(value) || value.includes('youtu.be'))
        .withMessage('URL do YouTube inválida'),
    
    body('quality')
        .optional()
        .isInt({ min: 128, max: 320 })
        .withMessage('Qualidade deve ser entre 128 e 320'),
    
    body('separateTracks')
        .optional()
        .isBoolean()
        .withMessage('separateTracks deve ser booleano'),
    
    body('createZip')
        .optional()
        .isBoolean()
        .withMessage('createZip deve ser booleano'),
    
    body('keepVideo')
        .optional()
        .isBoolean()
        .withMessage('keepVideo deve ser booleano'),
    
    body('emailNotification')
        .optional()
        .isBoolean()
        .withMessage('emailNotification deve ser booleano')
];

// Função para separar faixas de áudio (simulada - você precisará implementar com Spleeter ou similar)
async function separateAudioTracks(inputPath, outputDir) {
    return new Promise((resolve, reject) => {
        // Simulação - substitua por implementação real (Spleeter, Demucs, etc.)
        setTimeout(async () => {
            try {
                // Crie faixas simuladas
                const tracks = [
                    { name: 'vocais.mp3', path: path.join(outputDir, 'vocais.mp3') },
                    { name: 'bateria.mp3', path: path.join(outputDir, 'bateria.mp3') },
                    { name: 'baixo.mp3', path: path.join(outputDir, 'baixo.mp3') },
                    { name: 'outros.mp3', path: path.join(outputDir, 'outros.mp3') }
                ];
                
                // Criar arquivos simulados
                for (const track of tracks) {
                    await fs.writeFile(track.path, 'simulated audio track');
                }
                
                resolve(tracks);
            } catch (error) {
                reject(error);
            }
        }, 2000);
    });
}

// Rota para iniciar processamento de vídeo
router.post('/process', authMiddleware, checkUserLimits, processVideoValidation, async (req, res) => {
    let conn;
    let videoRecordId;
    
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Erro de validação',
                errors: errors.array()
            });
        }
        
        const {
            url,
            quality = 128,
            separateTracks = true,
            createZip = true,
            keepVideo = false,
            emailNotification = false
        } = req.body;
        
        const userId = req.userId;
        
        // Obter informações do vídeo
        const videoInfo = await ytdl.getInfo(url);
        
        conn = await pool.getConnection();
        
        // Verificar duração máxima permitida
        const [user] = await conn.query(
            'SELECT role FROM users WHERE id = ?',
            [userId]
        );
        
        const [durationSetting] = await conn.query(
            'SELECT setting_value FROM system_settings WHERE setting_key = ?',
            [user.role === 'premium' ? 'max_duration_premium' : 'max_duration_free']
        );
        
        const maxDuration = parseInt(durationSetting[0]?.setting_value || 3600); // 1 hora padrão
        
        if (parseInt(videoInfo.videoDetails.lengthSeconds) > maxDuration) {
            return res.status(400).json({
                success: false,
                message: `Vídeo muito longo. Limite: ${maxDuration} segundos`
            });
        }
        
        // Criar registro no banco de dados
        const [result] = await conn.query(
            `INSERT INTO videos (user_id, video_id, title, duration, url, status, quality, separate_tracks) 
             VALUES (?, ?, ?, ?, ?, 'processing', ?, ?)`,
            [
                userId,
                videoInfo.videoDetails.videoId,
                videoInfo.videoDetails.title,
                parseInt(videoInfo.videoDetails.lengthSeconds),
                url,
                quality,
                separateTracks
            ]
        );
        
        videoRecordId = result.insertId;
        
        // Responder imediatamente com o ID do processamento
        res.json({
            success: true,
            message: 'Processamento iniciado',
            processId: videoRecordId,
            videoTitle: videoInfo.videoDetails.title,
            estimatedTime: Math.ceil(parseInt(videoInfo.videoDetails.lengthSeconds) / 60) + 1 // minutos estimados
        });
        
        // Processamento em background
        processVideoBackground({
            videoRecordId,
            userId,
            videoInfo,
            url,
            quality,
            separateTracks,
            createZip,
            keepVideo,
            emailNotification,
            conn
        });
        
    } catch (error) {
        console.error('Erro ao iniciar processamento:', error);
        
        if (conn) {
            if (videoRecordId) {
                await conn.query(
                    'UPDATE videos SET status = ? WHERE id = ?',
                    ['failed', videoRecordId]
                );
            }
        }
        
        if (!res.headersSent) {
            res.status(500).json({
                success: false,
                message: 'Erro ao iniciar processamento'
            });
        }
    }
});

// Função de processamento em background
async function processVideoBackground(params) {
    const {
        videoRecordId,
        userId,
        videoInfo,
        url,
        quality,
        separateTracks,
        createZip,
        keepVideo,
        emailNotification,
        conn
    } = params;
    
    let tempDir, audioPath, videoPath;
    
    try {
        // Criar diretórios temporários
        const timestamp = Date.now();
        tempDir = path.join(__dirname, '..', 'uploads', 'temp', `${userId}_${timestamp}`);
        const audioDir = path.join(tempDir, 'audio');
        const videoDir = path.join(tempDir, 'video');
        
        await fs.mkdir(tempDir, { recursive: true });
        await fs.mkdir(audioDir, { recursive: true });
        await fs.mkdir(videoDir, { recursive: true });
        
        // Atualizar status
        await conn.query(
            'UPDATE videos SET status = ? WHERE id = ?',
            ['downloading', videoRecordId]
        );
        
        // Download do vídeo
        const videoFilename = `video_${videoInfo.videoDetails.videoId}.mp4`;
        videoPath = path.join(videoDir, videoFilename);
        
        const videoStream = ytdl(url, { quality: 'highestaudio' });
        const writeStream = require('fs').createWriteStream(videoPath);
        
        await new Promise((resolve, reject) => {
            videoStream.pipe(writeStream);
            videoStream.on('end', resolve);
            videoStream.on('error', reject);
            writeStream.on('error', reject);
        });
        
        // Atualizar status
        await conn.query(
            'UPDATE videos SET status = ? WHERE id = ?',
            ['extracting_audio', videoRecordId]
        );
        
        // Extrair áudio
        const audioFilename = `audio_${videoInfo.videoDetails.videoId}.mp3`;
        audioPath = path.join(audioDir, audioFilename);
        
        await new Promise((resolve, reject) => {
            ffmpeg(videoPath)
                .audioBitrate(quality)
                .audioCodec('libmp3lame')
                .format('mp3')
                .on('end', resolve)
                .on('error', reject)
                .save(audioPath);
        });
        
        // Separar faixas se solicitado
        let tracks = [];
        if (separateTracks) {
            await conn.query(
                'UPDATE videos SET status = ? WHERE id = ?',
                ['separating_tracks', videoRecordId]
            );
            
            tracks = await separateAudioTracks(audioPath, audioDir);
            
            // Registrar faixas no banco
            for (const track of tracks) {
                await conn.query(
                    `INSERT INTO audio_tracks (video_id, name, file_path, track_type) 
                     VALUES (?, ?, ?, ?)`,
                    [videoRecordId, track.name, track.path, path.basename(track.name, '.mp3')]
                );
            }
        }
        
        // Criar ZIP se solicitado
        let zipPath;
        if (createZip) {
            zipPath = path.join(tempDir, `${videoInfo.videoDetails.videoId}.zip`);
            
            const output = require('fs').createWriteStream(zipPath);
            const archive = archiver('zip', { zlib: { level: 9 } });
            
            await new Promise((resolve, reject) => {
                output.on('close', resolve);
                archive.on('error', reject);
                
                archive.pipe(output);
                archive.file(audioPath, { name: audioFilename });
                
                if (keepVideo) {
                    archive.file(videoPath, { name: videoFilename });
                }
                
                if (tracks.length > 0) {
                    tracks.forEach(track => {
                        archive.file(track.path, { name: `tracks/${track.name}` });
                    });
                }
                
                archive.finalize();
            });
        }
        
        // Mover arquivos para diretório permanente
        const permanentDir = path.join(__dirname, '..', 'uploads', 'processed', `${userId}`);
        await fs.mkdir(permanentDir, { recursive: true });
        
        const finalAudioPath = path.join(permanentDir, audioFilename);
        await fs.rename(audioPath, finalAudioPath);
        
        let finalVideoPath, finalZipPath;
        
        if (keepVideo) {
            finalVideoPath = path.join(permanentDir, videoFilename);
            await fs.rename(videoPath, finalVideoPath);
        }
        
        if (createZip) {
            finalZipPath = path.join(permanentDir, `${videoInfo.videoDetails.videoId}.zip`);
            await fs.rename(zipPath, finalZipPath);
        }
        
        // Atualizar banco de dados com caminhos finais
        await conn.query(
            `UPDATE videos 
             SET status = 'completed', 
                 audio_path = ?, 
                 video_path = ?, 
                 zip_path = ?,
                 completed_at = NOW()
             WHERE id = ?`,
            [finalAudioPath, finalVideoPath || null, finalZipPath || null, videoRecordId]
        );
        
        // Log de atividade
        await logActivity(userId, 'video_processed', {
            videoId: videoInfo.videoDetails.videoId,
            title: videoInfo.videoDetails.title,
            duration: videoInfo.videoDetails.lengthSeconds,
            separateTracks,
            keepVideo
        });
        
        // Enviar email de notificação se solicitado
        if (emailNotification) {
            const [userEmail] = await conn.query(
                'SELECT email FROM users WHERE id = ?',
                [userId]
            );
            
            // Aqui você implementaria o envio de email
            console.log(`Email enviado para ${userEmail[0].email} - Processamento concluído`);
        }
        
        // Limpar diretório temporário
        await fs.rm(tempDir, { recursive: true, force: true });
        
    } catch (error) {
        console.error('Erro no processamento em background:', error);
        
        if (conn) {
            await conn.query(
                'UPDATE videos SET status = ?, error_message = ? WHERE id = ?',
                ['failed', error.message, videoRecordId]
            );
        }
        
        // Tentar limpar diretório temporário em caso de erro
        if (tempDir) {
            try {
                await fs.rm(tempDir, { recursive: true, force: true });
            } catch (cleanupError) {
                console.error('Erro ao limpar diretório temporário:', cleanupError);
            }
        }
    } finally {
        if (conn) {
            conn.release();
        }
    }
}

// Rota para verificar status do processamento
router.get('/status/:processId', authMiddleware, async (req, res) => {
    try {
        const { processId } = req.params;
        const userId = req.userId;
        
        const conn = await pool.getConnection();
        
        try {
            const [video] = await conn.query(
                `SELECT v.*, 
                        (SELECT COUNT(*) FROM audio_tracks WHERE video_id = v.id) as track_count
                 FROM videos v 
                 WHERE v.id = ? AND v.user_id = ?`,
                [processId, userId]
            );
            
            if (video.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Processamento não encontrado'
                });
            }
            
            const videoData = video[0];
            
            // Preparar URLs de download se disponíveis
            let downloadLinks = {};
            
            if (videoData.audio_path && await fs.access(videoData.audio_path).then(() => true).catch(() => false)) {
                downloadLinks.audio = `/download/audio/${processId}`;
            }
            
            if (videoData.video_path && await fs.access(videoData.video_path).then(() => true).catch(() => false)) {
                downloadLinks.video = `/download/video/${processId}`;
            }
            
            if (videoData.zip_path && await fs.access(videoData.zip_path).then(() => true).catch(() => false)) {
                downloadLinks.zip = `/download/zip/${processId}`;
            }
            
            // Buscar faixas se existirem
            let tracks = [];
            if (videoData.separate_tracks) {
                const [audioTracks] = await conn.query(
                    'SELECT * FROM audio_tracks WHERE video_id = ?',
                    [processId]
                );
                tracks = audioTracks.map(track => ({
                    ...track,
                    downloadUrl: `/download/track/${track.id}`
                }));
            }
            
            res.json({
                success: true,
                status: videoData.status,
                video: {
                    id: videoData.id,
                    title: videoData.title,
                    duration: videoData.duration,
                    createdAt: videoData.created_at,
                    completedAt: videoData.completed_at
                },
                downloads: down