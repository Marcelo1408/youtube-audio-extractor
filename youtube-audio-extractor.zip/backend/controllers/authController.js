
cat > controllers/authController.js << 'EOF'
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { pool } = require('../config/database');
const emailService = require('../utils/emailService');

// Registro de usuário (ATUALIZADO para sua estrutura)
exports.register = async (req, res) => {
    let conn;
    try {
        const { username, email, password, phone } = req.body;
        
        // Validação básica
        if (!username || !email || !password) {
            return res.status(400).json({ 
                success: false, 
                message: 'Nome, email e senha são obrigatórios' 
            });
        }
        
        conn = await pool.getConnection();
        
        // Verificar se email já existe (sua estrutura)
        const [existing] = await conn.query(
            'SELECT id FROM users WHERE email = ?', 
            [email]
        );
        
        if (existing && existing.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Email já cadastrado' 
            });
        }
        
        // Hash da senha (password_hash no seu banco)
        const password_hash = await bcrypt.hash(password, 10);
        
        // Token de verificação com expiração
        const verification_token = crypto.randomBytes(32).toString('hex');
        const verification_expires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 horas
        
        // Inserir usuário (SUA ESTRUTURA)
        const [result] = await conn.query(
            `INSERT INTO users (
                email, username, password_hash, phone, 
                verification_token, verification_expires, role
            ) VALUES (?, ?, ?, ?, ?, ?, 'free')`,
            [email, username, password_hash, phone || null, 
             verification_token, verification_expires]
        );
        
        // Enviar email de verificação
        await emailService.sendVerificationEmail(email, username, verification_token);
        
        console.log(`✅ Usuário registrado: ${email} (ID: ${result.insertId})`);
        
        res.json({ 
            success: true, 
            message: 'Conta criada com sucesso! Verifique seu email.',
            userId: result.insertId
        });
        
    } catch (error) {
        console.error('❌ Erro no registro:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Erro interno no servidor' 
        });
    } finally {
        if (conn) conn.release();
    }
};

// Login de usuário (ATUALIZADO)
exports.login = async (req, res) => {
    let conn;
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({ 
                success: false, 
                message: 'Email e senha são obrigatórios' 
            });
        }
        
        conn = await pool.getConnection();
        
        // Buscar usuário (sua estrutura com password_hash)
        const [users] = await conn.query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );
        
        if (users.length === 0) {
            return res.status(401).json({ 
                success: false, 
                message: 'Email ou senha incorretos' 
            });
        }
        
        const user = users[0];
        
        // Verificar senha (password_hash)
        const validPassword = await bcrypt.compare(password, user.password_hash);
        if (!validPassword) {
            return res.status(401).json({ 
                success: false, 
                message: 'Email ou senha incorretos' 
            });
        }
        
        // Verificar se email foi confirmado
        if (!user.email_verified) {
            return res.status(403).json({ 
                success: false, 
                message: 'Por favor, verifique seu email antes de fazer login' 
            });
        }
        
        // Criar token JWT
        const token = jwt.sign(
            { 
                userId: user.id, 
                email: user.email,
                role: user.role 
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
        );
        
        // Atualizar último login
        await conn.query(
            'UPDATE users SET last_login = NOW() WHERE id = ?',
            [user.id]
        );
        
        // Retornar dados do usuário (sua estrutura)
        const userData = {
            id: user.id,
            username: user.username,
            email: user.email,
            phone: user.phone,
            role: user.role,
            email_verified: user.email_verified,
            created_at: user.created_at
        };
        
        console.log(`✅ Login bem-sucedido: ${email}`);
        
        res.json({
            success: true,
            message: 'Login realizado com sucesso',
            token,
            user: userData
        });
        
    } catch (error) {
        console.error('❌ Erro no login:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Erro interno no servidor' 
        });
    } finally {
        if (conn) conn.release();
    }
};

// Verificar email (ATUALIZADO)
exports.verify = async (req, res) => {
    let conn;
    try {
        const { token } = req.params;
        
        if (!token) {
            return res.status(400).json({ 
                success: false, 
                message: 'Token de verificação é obrigatório' 
            });
        }
        
        conn = await pool.getConnection();
        
        // Buscar usuário pelo token (com verificação de expiração)
        const [users] = await conn.query(
            `SELECT * FROM users 
             WHERE verification_token = ? 
             AND verification_expires > NOW()`,
            [token]
        );
        
        if (users.length === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'Token de verificação inválido ou expirado' 
            });
        }
        
        const user = users[0];
        
        // Verificar se já foi confirmado
        if (user.email_verified) {
            return res.json({ 
                success: true, 
                message: 'Email já foi verificado anteriormente' 
            });
        }
        
        // Atualizar usuário como verificado (sua estrutura)
        await conn.query(
            `UPDATE users 
             SET email_verified = TRUE, 
                 verification_token = NULL,
                 verification_expires = NULL,
                 updated_at = NOW()
             WHERE id = ?`,
            [user.id]
        );
        
        // Enviar email de boas-vindas
        await emailService.sendWelcomeEmail(user.email, user.username);
        
        console.log(`✅ Email verificado: ${user.email}`);
        
        res.json({
            success: true,
            message: 'Email verificado com sucesso! Você já pode fazer login.',
            user: {
                id: user.id,
                email: user.email,
                username: user.username
            }
        });
        
    } catch (error) {
        console.error('❌ Erro na verificação:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Erro ao verificar email' 
        });
    } finally {
        if (conn) conn.release();
    }
};

// Login com Google (ATUALIZADO para sua estrutura)
exports.googleAuth = async (req, res) => {
    let conn;
    try {
        const { token, email, name, googleId } = req.body;
        
        if (!email || !googleId) {
            return res.status(400).json({ 
                success: false, 
                message: 'Dados do Google são necessários' 
            });
        }
        
        conn = await pool.getConnection();
        
        // Verificar se usuário já existe pelo google_id
        const [existingUsers] = await conn.query(
            'SELECT * FROM users WHERE google_id = ? OR email = ?',
            [googleId, email]
        );
        
        let user;
        
        if (existingUsers.length > 0) {
            // Usuário existe, atualizar google_id se necessário
            user = existingUsers[0];
            
            if (!user.google_id) {
                await conn.query(
                    'UPDATE users SET google_id = ?, updated_at = NOW() WHERE id = ?',
                    [googleId, user.id]
                );
            }
            
            // Atualizar último login
            await conn.query(
                'UPDATE users SET last_login = NOW() WHERE id = ?',
                [user.id]
            );
        } else {
            // Criar novo usuário com Google
            const [result] = await conn.query(
                `INSERT INTO users (
                    email, username, google_id, role, email_verified
                ) VALUES (?, ?, ?, 'free', TRUE)`,
                [email, name || email.split('@')[0], googleId]
            );
            
            // Buscar usuário criado
            const [newUsers] = await conn.query(
                'SELECT * FROM users WHERE id = ?',
                [result.insertId]
            );
            
            user = newUsers[0];
            
            // Enviar email de boas-vindas
            await emailService.sendWelcomeEmail(email, name || email.split('@')[0]);
        }
        
        // Criar token JWT
        const jwtToken = jwt.sign(
            { 
                userId: user.id, 
                email: user.email,
                role: user.role 
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
        );
        
        // Retornar dados
        const userData = {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            email_verified: user.email_verified
        };
        
        console.log(`✅ Login Google: ${email}`);
        
        res.json({
            success: true,
            message: 'Login com Google realizado',
            token: jwtToken,
            user: userData
        });
        
    } catch (error) {
        console.error('❌ Erro no Google Auth:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Erro interno no servidor' 
        });
    } finally {
        if (conn) conn.release();
    }
};

// Esqueci a senha (ATUALIZADO)
exports.forgotPassword = async (req, res) => {
    let conn;
    try {
        const { email } = req.body;
        
        if (!email) {
            return res.status(400).json({ 
                success: false, 
                message: 'Email é obrigatório' 
            });
        }
        
        conn = await pool.getConnection();
        
        // Verificar se usuário existe
        const [users] = await conn.query(
            'SELECT id, username, email FROM users WHERE email = ?',
            [email]
        );
        
        if (users.length === 0) {
            // Por segurança, não revelar que o email não existe
            return res.json({ 
                success: true, 
                message: 'Se o email existir, você receberá instruções para resetar sua senha' 
            });
        }
        
        const user = users[0];
        
        // Gerar token de reset com expiração
        const reset_token = crypto.randomBytes(32).toString('hex');
        const reset_expires = new Date(Date.now() + 3600000); // 1 hora
        
        // Salvar token no banco (sua estrutura)
        await conn.query(
            `UPDATE users 
             SET reset_token = ?, 
                 reset_expires = ?,
                 updated_at = NOW()
             WHERE id = ?`,
            [reset_token, reset_expires, user.id]
        );
        
        // Enviar email de reset
        await emailService.sendPasswordResetEmail(user.email, user.username, reset_token);
        
        console.log(`📧 Email de reset enviado para: ${email}`);
        
        res.json({
            success: true,
            message: 'Instruções para resetar sua senha foram enviadas para seu email'
        });
        
    } catch (error) {
        console.error('❌ Erro no forgot password:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Erro interno no servidor' 
        });
    } finally {
        if (conn) conn.release();
    }
};

// Resetar senha (ATUALIZADO)
exports.resetPassword = async (req, res) => {
    let conn;
    try {
        const { token, newPassword } = req.body;
        
        if (!token || !newPassword) {
            return res.status(400).json({ 
                success: false, 
                message: 'Token e nova senha são obrigatórios' 
            });
        }
        
        if (newPassword.length < 6) {
            return res.status(400).json({ 
                success: false, 
                message: 'A senha deve ter pelo menos 6 caracteres' 
            });
        }
        
        conn = await pool.getConnection();
        
        // Buscar usuário pelo token (com verificação de expiração)
        const [users] = await conn.query(
            `SELECT id FROM users 
             WHERE reset_token = ? 
             AND reset_expires > NOW()`,
            [token]
        );
        
        if (users.length === 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Token inválido ou expirado' 
            });
        }
        
        const user = users[0];
        
        // Hash da nova senha (password_hash)
        const password_hash = await bcrypt.hash(newPassword, 10);
        
        // Atualizar senha e limpar token
        await conn.query(
            `UPDATE users 
             SET password_hash = ?, 
                 reset_token = NULL,
                 reset_expires = NULL,
                 updated_at = NOW()
             WHERE id = ?`,
            [password_hash, user.id]
        );
        
        console.log(`✅ Senha resetada para usuário ID: ${user.id}`);
        
        res.json({
            success: true,
            message: 'Senha alterada com sucesso! Você já pode fazer login com a nova senha.'
        });
        
    } catch (error) {
        console.error('❌ Erro no reset password:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Erro interno no servidor' 
        });
    } finally {
        if (conn) conn.release();
    }
};
EOF