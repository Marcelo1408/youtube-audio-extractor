const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/database');
const emailService = require('../utils/emailService');

exports.register = async (req, res) => {
    try {
        const { username, email, password, phone } = req.body;
        
        // Verificar se email já existe
        const conn = await pool.getConnection();
        const [existing] = await conn.query('SELECT id FROM users WHERE email = ?', [email]);
        
        if (existing) {
            conn.release();
            return res.status(400).json({ success: false, message: 'Email já cadastrado' });
        }
        
        // Hash da senha
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Token de verificação
        const verificationToken = require('crypto').randomBytes(32).toString('hex');
        
        // Inserir usuário
        const [result] = await conn.query(
            `INSERT INTO users (username, email, password, phone, verification_token) 
             VALUES (?, ?, ?, ?, ?)`,
            [username, email, hashedPassword, phone, verificationToken]
        );
        
        // Enviar email de confirmação
        await emailService.sendVerificationEmail(email, verificationToken);
        
        conn.release();
        
        res.json({ 
            success: true, 
            message: 'Conta criada! Verifique seu email.' 
        });
        
    } catch (error) {
        console.error('Erro no registro:', error);
        res.status(500).json({ success: false, message: 'Erro no servidor' });
    }
};

// ... mais funções de login, verificação, etc.