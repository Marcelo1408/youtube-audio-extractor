<?php
// Configurações do Sistema para VPS
session_start();
ob_start();

// Carregar variáveis de ambiente
if (file_exists('.env')) {
    $env = parse_ini_file('.env');
    foreach ($env as $key => $value) {
        putenv("$key=$value");
        $_ENV[$key] = $value;
    }
} else {
    die('Arquivo .env não encontrado!');
}

// Configurações do sistema
define('APP_NAME', getenv('APP_NAME') ?: 'YouTube Audio Extractor');
define('APP_ENV', getenv('APP_ENV') ?: 'production');
define('APP_DEBUG', filter_var(getenv('APP_DEBUG'), FILTER_VALIDATE_BOOLEAN));
define('APP_URL', rtrim(getenv('APP_URL'), '/'));
define('APP_TIMEZONE', getenv('APP_TIMEZONE') ?: 'America/Sao_Paulo');

// Configurações do banco de dados
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_DATABASE') ?: 'audioextractor');
define('DB_USER', getenv('DB_USERNAME') ?: 'audioextrac_usr');
define('DB_PASS', getenv('DB_PASSWORD') ?: '3GqG!%Yg7i;YsI4Y!');

// Configurações de processamento
define('YOUTUBE_API_KEY', getenv('YOUTUBE_API_KEY') ?: '');
define('YOUTUBE_DL_PATH', getenv('YOUTUBE_DL_PATH') ?: '/usr/local/bin/yt-dlp');
define('FFMPEG_PATH', getenv('FFMPEG_PATH') ?: '/usr/bin/ffmpeg');
define('SPLEETER_PATH', getenv('SPLEETER_PATH') ?: '/usr/local/bin/spleeter');
define('MAX_VIDEO_SIZE', getenv('MAX_VIDEO_SIZE') ?: 1073741824);
define('MAX_VIDEO_DURATION', getenv('MAX_VIDEO_DURATION') ?: 7200);
define('MAX_CONCURRENT_PROCESSES', getenv('MAX_CONCURRENT_PROCESSES') ?: 3);

// Configurações de armazenamento
define('STORAGE_PATH', getenv('STORAGE_PATH') ?: __DIR__ . '/assets/uploads');
define('VIDEO_PATH', STORAGE_PATH . '/videos/');
define('AUDIO_PATH', STORAGE_PATH . '/audio/');
define('TRACKS_PATH', STORAGE_PATH . '/tracks/');
define('TEMP_PATH', STORAGE_PATH . '/temp/');
define('MAX_STORAGE_PER_USER', getenv('MAX_STORAGE_PER_USER') ?: 10737418240);

// Configurar timezone
date_default_timezone_set(APP_TIMEZONE);

// Configurar exibição de erros
if (APP_DEBUG) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}

// Configurar limites
ini_set('upload_max_filesize', '1G');
ini_set('post_max_size', '1G');
ini_set('max_execution_time', '300');
ini_set('max_input_time', '300');
ini_set('memory_limit', '512M');

// Criar diretórios necessários
$required_dirs = [
    VIDEO_PATH, AUDIO_PATH, TRACKS_PATH, TEMP_PATH,
    dirname(STORAGE_PATH) . '/logs/',
    dirname(STORAGE_PATH) . '/cache/'
];

foreach ($required_dirs as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Proteger diretórios com .htaccess
$htaccess_content = "Order deny,allow\nDeny from all\n";
foreach ([VIDEO_PATH, AUDIO_PATH, TRACKS_PATH, TEMP_PATH] as $dir) {
    file_put_contents($dir . '.htaccess', $htaccess_content);
}

// Funções auxiliares
function isLoggedIn() {
    return isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0;
}

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function redirect($url, $permanent = false) {
    if ($permanent) {
        header('HTTP/1.1 301 Moved Permanently');
    }
    header("Location: $url");
    exit();
}

function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (!hash_equals($_SESSION['csrf_token'], $token)) {
            die('Token CSRF inválido!');
        }
    }
}

function log_message($message, $type = 'INFO') {
    $log = "[" . date('Y-m-d H:i:s') . "] [$type] $message" . PHP_EOL;
    $log_file = dirname(STORAGE_PATH) . '/logs/process_' . date('Y-m-d') . '.log';
    file_put_contents($log_file, $log, FILE_APPEND);
    
    if (APP_DEBUG && $type === 'ERROR') {
        error_log($message);
    }
}

// Inicializar sessão
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = csrf_token();
}

// Verificar requisições AJAX
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');
?>