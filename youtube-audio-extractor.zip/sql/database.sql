-- Banco de dados: youtube_extractor
-- Versão: 2.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS `youtube_extractor` 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `youtube_extractor`;

-- --------------------------------------------------------
-- Tabela: users
-- --------------------------------------------------------
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `role` enum('user','admin','moderator') DEFAULT 'user',
  `plan` enum('free','premium','enterprise') DEFAULT 'free',
  `storage_limit` bigint(20) DEFAULT 10737418240, -- 10GB padrão
  `storage_used` bigint(20) DEFAULT 0,
  `process_limit` int(11) DEFAULT 50, -- 50 processamentos/mês
  `process_count` int(11) DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT 0,
  `verification_token` varchar(100) DEFAULT NULL,
  `reset_token` varchar(100) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `status` enum('active','suspended','banned') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `role` (`role`),
  KEY `plan` (`plan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Tabela: processes
-- --------------------------------------------------------
CREATE TABLE `processes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `process_uid` varchar(32) NOT NULL,
  `youtube_url` text NOT NULL,
  `youtube_id` varchar(20) DEFAULT NULL,
  `video_title` varchar(255) DEFAULT NULL,
  `video_duration` int(11) DEFAULT NULL,
  `video_size` bigint(20) DEFAULT NULL,
  `thumbnail_url` text,
  `status` enum(
    'pending',
    'downloading',
    'converting',
    'separating',
    'completed',
    'failed',
    'cancelled'
  ) DEFAULT 'pending',
  `quality` enum('64','128','192','320') DEFAULT '128',
  `separate_tracks` tinyint(1) DEFAULT 0,
  `tracks_count` int(11) DEFAULT 0,
  `original_format` varchar(10) DEFAULT NULL,
  `output_format` varchar(10) DEFAULT 'mp3',
  `file_path` varchar(500) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `progress` int(11) DEFAULT 0,
  `error_message` text,
  `processing_time` int(11) DEFAULT NULL,
  `worker_id` varchar(50) DEFAULT NULL,
  `notify_user` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `process_uid` (`process_uid`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `youtube_id` (`youtube_id`),
  KEY `created_at` (`created_at`),
  FULLTEXT KEY `video_title` (`video_title`),
  CONSTRAINT `processes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Tabela: tracks
-- --------------------------------------------------------
CREATE TABLE `tracks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `track_number` int(11) NOT NULL,
  `track_name` varchar(100) NOT NULL,
  `track_type` enum('vocals','drums','bass','piano','other','full') DEFAULT 'full',
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `duration` int(11) DEFAULT 0,
  `bitrate` int(11) DEFAULT 128,
  `format` varchar(10) DEFAULT 'mp3',
  `downloads` int(11) DEFAULT 0,
  `plays` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `process_id` (`process_id`),
  KEY `track_type` (`track_type`),
  CONSTRAINT `tracks_ibfk_1` FOREIGN KEY (`process_id`) REFERENCES `processes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Tabela: downloads
-- --------------------------------------------------------
CREATE TABLE `downloads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `track_id` int(11) NOT NULL,
  `process_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `file_size` bigint(20) DEFAULT 0,
  `download_time` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `track_id` (`track_id`),
  KEY `process_id` (`process_id`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `downloads_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `downloads_ibfk_2` FOREIGN KEY (`track_id`) REFERENCES `tracks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `downloads_ibfk_3` FOREIGN KEY (`process_id`) REFERENCES `processes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Tabela: queue
-- --------------------------------------------------------
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `job_type` enum('download','convert','separate') NOT NULL,
  `priority` int(11) DEFAULT 5,
  `status` enum('pending','processing','completed','failed') DEFAULT 'pending',
  `attempts` int(11) DEFAULT 0,
  `max_attempts` int(11) DEFAULT 3,
  `payload` text,
  `result` text,
  `error_message` text,
  `worker_id` varchar(50) DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `process_id` (`process_id`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  CONSTRAINT `queue_ibfk_1` FOREIGN KEY (`process_id`) REFERENCES `processes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Tabela: settings
-- --------------------------------------------------------
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `setting_type` enum('string','integer','boolean','json','array') DEFAULT 'string',
  `description` text,
  `is_public` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Tabela: logs
-- --------------------------------------------------------
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` enum('info','warning','error','debug') DEFAULT 'info',
  `message` text NOT NULL,
  `context` json DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Tabela: api_keys
-- --------------------------------------------------------
CREATE TABLE `api_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `api_key` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `permissions` json DEFAULT NULL,
  `rate_limit` int(11) DEFAULT 100,
  `last_used` datetime DEFAULT NULL,
  `status` enum('active','suspended','expired') DEFAULT 'active',
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_key` (`api_key`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `api_keys_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Inserir dados iniciais
-- --------------------------------------------------------

-- Inserir usuário admin padrão
INSERT INTO `users` (`username`, `email`, `password`, `role`, `plan`, `email_verified`) VALUES
('admin', 'admin@seu-dominio.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'enterprise', 1);

-- Inserir configurações padrão
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `description`, `is_public`) VALUES
('site_name', 'YouTube Audio Extractor', 'string', 'Nome do site', 1),
('site_description', 'Extraia áudio de vídeos do YouTube e separe as faixas automaticamente', 'string', 'Descrição do site', 1),
('site_keywords', 'youtube,audio,extractor,mp3,download,spleeter', 'string', 'Palavras-chave para SEO', 1),
('max_video_size', '1073741824', 'integer', 'Tamanho máximo do vídeo em bytes', 1),
('max_video_duration', '7200', 'integer', 'Duração máxima do vídeo em segundos', 1),
('concurrent_processes', '3', 'integer', 'Número máximo de processos simultâneos', 0),
('enable_registration', '1', 'boolean', 'Permitir novos registros', 1),
('maintenance_mode', '0', 'boolean', 'Modo manutenção', 1),
('default_quality', '128', 'string', 'Qualidade padrão do áudio', 1),
('enable_email_notifications', '1', 'boolean', 'Ativar notificações por email', 0),
('smtp_host', 'smtp.gmail.com', 'string', 'Servidor SMTP', 0),
('storage_cleanup_days', '7', 'integer', 'Dias para limpar arquivos temporários', 0);

-- --------------------------------------------------------
-- Views
-- --------------------------------------------------------

CREATE VIEW `user_stats` AS
SELECT 
    u.id,
    u.username,
    u.email,
    u.plan,
    COUNT(p.id) as total_processes,
    SUM(CASE WHEN p.status = 'completed' THEN 1 ELSE 0 END) as completed_processes,
    SUM(p.file_size) as total_storage_used,
    COUNT(DISTINCT d.track_id) as total_downloads,
    MAX(p.created_at) as last_process_date
FROM users u
LEFT JOIN processes p ON u.id = p.user_id
LEFT JOIN downloads d ON u.id = d.user_id
GROUP BY u.id;

CREATE VIEW `daily_stats` AS
SELECT 
    DATE(created_at) as date,
    COUNT(*) as total_processes,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_processes,
    SUM(file_size) as total_storage_used,
    COUNT(DISTINCT user_id) as active_users
FROM processes
GROUP BY DATE(created_at);

-- --------------------------------------------------------
-- Procedures
-- --------------------------------------------------------

DELIMITER //

CREATE PROCEDURE `cleanup_old_files`(IN days_old INT)
BEGIN
    -- Limpar processos antigos
    DELETE FROM processes 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL days_old DAY) 
    AND status IN ('completed', 'failed', 'cancelled');
    
    -- Limpar logs antigos
    DELETE FROM logs 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL days_old DAY) 
    AND level != 'error';
END//

CREATE PROCEDURE `reset_user_limits`()
BEGIN
    UPDATE users 
    SET process_count = 0 
    WHERE plan = 'free' 
    AND DAY(last_login) = 1;
END//

DELIMITER ;

-- --------------------------------------------------------
-- Triggers
-- --------------------------------------------------------

DELIMITER //

CREATE TRIGGER `before_process_insert`
BEFORE INSERT ON `processes`
FOR EACH ROW
BEGIN
    SET NEW.process_uid = MD5(CONCAT(NEW.user_id, NOW(), RAND()));
END//

CREATE TRIGGER `after_track_insert`
AFTER INSERT ON `tracks`
FOR EACH ROW
BEGIN
    UPDATE processes 
    SET tracks_count = tracks_count + 1,
        file_size = file_size + NEW.file_size
    WHERE id = NEW.process_id;
END//

CREATE TRIGGER `update_user_storage`
AFTER INSERT ON `processes`
FOR EACH ROW
BEGIN
    UPDATE users 
    SET storage_used = storage_used + NEW.file_size
    WHERE id = NEW.user_id;
END//

DELIMITER ;

-- --------------------------------------------------------
-- Índices e Otimizações
-- --------------------------------------------------------

CREATE INDEX idx_processes_user_status ON processes(user_id, status);
CREATE INDEX idx_processes_created_status ON processes(created_at, status);
CREATE INDEX idx_tracks_process_type ON tracks(process_id, track_type);
CREATE INDEX idx_downloads_user_date ON downloads(user_id, created_at);
CREATE INDEX idx_queue_status_priority ON queue(status, priority);

-- --------------------------------------------------------
-- Eventos agendados
-- --------------------------------------------------------

SET GLOBAL event_scheduler = ON;

CREATE EVENT `daily_cleanup`
ON SCHEDULE EVERY 1 DAY
STARTS '2024-01-01 02:00:00'
DO
BEGIN
    CALL cleanup_old_files(30);
    
    -- Limpar arquivos temporários
    DELETE FROM queue 
    WHERE status IN ('completed', 'failed') 
    AND completed_at < DATE_SUB(NOW(), INTERVAL 7 DAY);
END;

CREATE EVENT `hourly_stats`
ON SCHEDULE EVERY 1 HOUR
DO
BEGIN
    INSERT INTO logs (level, message, context)
    SELECT 'info', 'Estatísticas horárias', 
    JSON_OBJECT(
        'active_processes', COUNT(CASE WHEN status IN ('pending', 'downloading', 'converting', 'separating') THEN 1 END),
        'completed_today', COUNT(CASE WHEN DATE(created_at) = CURDATE() AND status = 'completed' THEN 1 END),
        'total_users', (SELECT COUNT(*) FROM users),
        'storage_used', (SELECT SUM(storage_used) FROM users)
    )
    FROM processes;
END;

-- Fim do script