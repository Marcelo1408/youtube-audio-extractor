<?php
require_once 'config.php';
require_once 'includes/auth.php';

// Verificar se é admin
if (!isAdmin()) {
    redirect('index.php');
}

$db = new Database();
$conn = $db->getConnection();

// Processar ações administrativas
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'update_settings':
            // Atualizar configurações
            foreach ($_POST['settings'] as $key => $value) {
                $stmt = $conn->prepare("
                    INSERT INTO settings (setting_key, setting_value) 
                    VALUES (?, ?)
                    ON DUPLICATE KEY UPDATE setting_value = ?
                ");
                $stmt->bind_param("sss", $key, $value, $value);
                $stmt->execute();
                $stmt->close();
            }
            $_SESSION['success_message'] = 'Configurações atualizadas com sucesso!';
            break;
            
        case 'manage_user':
            $userId = intval($_POST['user_id']);
            $actionType = $_POST['type'];
            
            switch ($actionType) {
                case 'suspend':
                    $stmt = $conn->prepare("UPDATE users SET status = 'suspended' WHERE id = ?");
                    break;
                case 'activate':
                    $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
                    break;
                case 'delete':
                    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
                    break;
                case 'make_admin':
                    $stmt = $conn->prepare("UPDATE users SET role = 'admin' WHERE id = ?");
                    break;
            }
            
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $stmt->close();
            
            $_SESSION['success_message'] = 'Ação realizada com sucesso!';
            break;
    }
    
    redirect('admin.php');
}

// Obter estatísticas
$stats = [];

// Total de usuários
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN plan = 'premium' THEN 1 ELSE 0 END) as premium_users,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_users,
        SUM(storage_used) as total_storage
    FROM users
");
$stmt->execute();
$stats['users'] = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Processamentos
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_processes,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_processes,
        SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing_processes,
        SUM(file_size) as total_file_size
    FROM processes
");
$stmt->execute();
$stats['processes'] = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Downloads
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_downloads,
        COUNT(DISTINCT user_id) as unique_downloaders,
        SUM(file_size) as total_downloaded_size
    FROM downloads
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
");
$stmt->execute();
$stats['downloads'] = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Sistema
$stats['system'] = [
    'disk_usage' => disk_free_space('/') ? 
        round((1 - (disk_free_space('/') / disk_total_space('/'))) * 100, 2) : 0,
    'memory_usage' => memory_get_usage(true) / 1024 / 1024, // MB
    'server_load' => sys_getloadavg()[0] ?? 0,
    'php_version' => PHP_VERSION,
    'mysql_version' => $conn->server_version
];

// Obter usuários recentes
$stmt = $conn->prepare("
    SELECT id, username, email, plan, status, last_login, created_at 
    FROM users 
    ORDER BY created_at DESC 
    LIMIT 10
");
$stmt->execute();
$recent_users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Obter processamentos recentes
$stmt = $conn->prepare("
    SELECT p.*, u.username 
    FROM processes p
    JOIN users u ON p.user_id = u.id
    ORDER BY p.created_at DESC 
    LIMIT 10
");
$stmt->execute();
$recent_processes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Obter configurações
$stmt = $conn->prepare("SELECT setting_key, setting_value FROM settings");
$stmt->execute();
$settings_result = $stmt->get_result();
$settings = [];
while ($row = $settings_result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
$stmt->close();

require_once 'includes/header.php';
?>

<div class="container">
    <div class="admin-header">
        <h1 class="gradient-text">Painel de Administração</h1>
        <div class="admin-actions">
            <button class="btn btn-secondary" onclick="refreshStats()">
                <i class="fas fa-sync-alt"></i> Atualizar
            </button>
        </div>
    </div>

    <!-- Estatísticas -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-content">
                <div class="stat-number"><?php echo $stats['users']['total_users']; ?></div>
                <div class="stat-label">Total de Usuários</div>
                <div class="stat-detail">
                    <span class="badge success"><?php echo $stats['users']['active_users']; ?> ativos</span>
                    <span class="badge warning"><?php echo $stats['users']['premium_users']; ?> premium</span>
                </div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-tasks"></i>
            </div>
            <div class="stat-content">
                <div class="stat-number"><?php echo $stats['processes']['total_processes']; ?></div>
                <div class="stat-label">Processamentos</div>
                <div class="stat-detail">
                    <span class="badge success"><?php echo $stats['processes']['completed_processes']; ?> concluídos</span>
                    <span class="badge info"><?php echo $stats['processes']['processing_processes']; ?> processando</span>
                </div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-download"></i>
            </div>
            <div class="stat-content">
                <div class="stat-number"><?php echo $stats['downloads']['total_downloads']; ?></div>
                <div class="stat-label">Downloads (7 dias)</div>
                <div class="stat-detail">
                    <span class="badge"><?php echo $stats['downloads']['unique_downloaders']; ?> usuários</span>
                </div>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-server"></i>
            </div>
            <div class="stat-content">
                <div class="stat-number"><?php echo $stats['system']['disk_usage']; ?>%</div>
                <div class="stat-label">Uso do Disco</div>
                <div class="stat-detail">
                    <span class="badge">Load: <?php echo round($stats['system']['server_load'], 2); ?></span>
                    <span class="badge">PHP <?php echo $stats['system']['php_version']; ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Abas -->
    <div class="admin-tabs">
        <button class="tab-btn active" data-tab="users">Usuários</button>
        <button class="tab-btn" data-tab="processes">Processamentos</button>
        <button class="tab-btn" data-tab="system">Sistema</button>
        <button class="tab-btn" data-tab="settings">Configurações</button>
    </div>

    <!-- Conteúdo das abas -->
    <div class="tab-content active" id="users-tab">
        <div class="card">
            <h3><i class="fas fa-users-cog"></i> Gerenciar Usuários</h3>
            
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Usuário</th>
                            <th>Email</th>
                            <th>Plano</th>
                            <th>Status</th>
                            <th>Último Login</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td>
                                <div class="user-cell">
                                    <div class="user-avatar">
                                        <?php echo strtoupper(substr($user['username'], 0, 2)); ?>
                                    </div>
                                    <div class="user-info">
                                        <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                        <small><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <span class="badge <?php echo $user['plan'] === 'premium' ? 'warning' : ''; ?>">
                                    <?php echo $user['plan']; ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge <?php echo $user['status'] === 'active' ? 'success' : 'error'; ?>">
                                    <?php echo $user['status']; ?>
                                </span>
                            </td>
                            <td>
                                <?php echo $user['last_login'] ? 
                                    date('d/m/Y H:i', strtotime($user['last_login'])) : 'Nunca'; ?>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <?php if ($user['status'] === 'active'): ?>
                                        <button class="btn btn-small btn-error" 
                                                onclick="manageUser(<?php echo $user['id']; ?>, 'suspend')">
                                            <i class="fas fa-ban"></i>
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-small btn-success" 
                                                onclick="manageUser(<?php echo $user['id']; ?>, 'activate')">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-small btn-warning"
                                            onclick="manageUser(<?php echo $user['id']; ?>, 'make_admin')">
                                        <i class="fas fa-crown"></i>
                                    </button>
                                    
                                    <button class="btn btn-small btn-error"
                                            onclick="deleteUser(<?php echo $user['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="tab-content" id="processes-tab">
        <div class="card">
            <h3><i class="fas fa-tasks"></i> Processamentos Recentes</h3>
            
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Usuário</th>
                            <th>Título do Vídeo</th>
                            <th>Status</th>
                            <th>Tamanho</th>
                            <th>Data</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_processes as $process): ?>
                        <tr>
                            <td><?php echo $process['id']; ?></td>
                            <td><?php echo htmlspecialchars($process['username']); ?></td>
                            <td title="<?php echo htmlspecialchars($process['video_title']); ?>">
                                <?php echo truncate(htmlspecialchars($process['video_title']), 50); ?>
                            </td>
                            <td>
                                <span class="badge status-<?php echo $process['status']; ?>">
                                    <?php echo $process['status']; ?>
                                </span>
                            </td>
                            <td><?php echo formatBytes($process['file_size']); ?></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($process['created_at'])); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="downloads.php?id=<?php echo $process['id']; ?>" 
                                       class="btn btn-small btn-primary" target="_blank">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <button class="btn btn-small btn-error"
                                            onclick="deleteProcess(<?php echo $process['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="tab-content" id="system-tab">
        <div class="card">
            <h3><i class="fas fa-server"></i> Status do Sistema</h3>
            
            <div class="system-info">
                <div class="info-item">
                    <label>Uso de Disco:</label>
                    <div class="progress">
                        <div class="progress-fill" 
                             style="width: <?php echo $stats['system']['disk_usage']; ?>%">
                            <span><?php echo $stats['system']['disk_usage']; ?>%</span>
                        </div>
                    </div>
                </div>
                
                <div class="info-item">
                    <label>Uso de Memória:</label>
                    <span><?php echo round($stats['system']['memory_usage'], 2); ?> MB</span>
                </div>
                
                <div class="info-item">
                    <label>Load Average:</label>
                    <span><?php echo round($stats['system']['server_load'], 2); ?></span>
                </div>
                
                <div class="info-item">
                    <label>Versão PHP:</label>
                    <span><?php echo $stats['system']['php_version']; ?></span>
                </div>
                
                <div class="info-item">
                    <label>Versão MySQL:</label>
                    <span><?php echo $stats['system']['mysql_version']; ?></span>
                </div>
            </div>
            
            <div class="system-actions">
                <button class="btn btn-secondary" onclick="clearCache()">
                    <i class="fas fa-broom"></i> Limpar Cache
                </button>
                <button class="btn btn-warning" onclick="restartWorkers()">
                    <i class="fas fa-redo"></i> Reiniciar Workers
                </button>
                <button class="btn btn-error" onclick="runMaintenance()">
                    <i class="fas fa-tools"></i> Manutenção
                </button>
            </div>
        </div>
    </div>

    <div class="tab-content" id="settings-tab">
        <div class="card">
            <h3><i class="fas fa-cog"></i> Configurações do Sistema</h3>
            
            <form method="POST" action="admin.php">
                <input type="hidden" name="action" value="update_settings">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                
                <div class="settings-grid">
                    <div class="setting-group">
                        <h4><i class="fas fa-globe"></i> Site</h4>
                        
                        <div class="form-group">
                            <label>Nome do Site:</label>
                            <input type="text" name="settings[site_name]" 
                                   value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>"
                                   class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label>Descrição:</label>
                            <textarea name="settings[site_description]" class="form-control" rows="3"><?php echo htmlspecialchars($settings['site_description'] ?? ''); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="setting-group">
                        <h4><i class="fas fa-sliders-h"></i> Limites</h4>
                        
                        <div class="form-group">
                            <label>Duração Máxima do Vídeo (segundos):</label>
                            <input type="number" name="settings[max_video_duration]" 
                                   value="<?php echo htmlspecialchars($settings['max_video_duration'] ?? '7200'); ?>"
                                   class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label>Tamanho Máximo do Vídeo (MB):</label>
                            <input type="number" name="settings[max_video_size]" 
                                   value="<?php echo htmlspecialchars($settings['max_video_size'] ?? '1024'); ?>"
                                   class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label>Processamentos Simultâneos:</label>
                            <input type="number" name="settings[concurrent_processes]" 
                                   value="<?php echo htmlspecialchars($settings['concurrent_processes'] ?? '3'); ?>"
                                   class="form-control" min="1" max="10">
                        </div>
                    </div>
                    
                    <div class="setting-group">
                        <h4><i class="fas fa-user-plus"></i> Registro</h4>
                        
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="settings[enable_registration]" value="1"
                                    <?php echo ($settings['enable_registration'] ?? '1') === '1' ? 'checked' : ''; ?>>
                                Permitir novos registros
                            </label>
                        </div>
                        
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="settings[require_email_verification]" value="1"
                                    <?php echo ($settings['require_email_verification'] ?? '0') === '1' ? 'checked' : ''; ?>>
                                Requer verificação de email
                            </label>
                        </div>
                    </div>
                    
                    <div class="setting-group">
                        <h4><i class="fas fa-envelope"></i> Email</h4>
                        
                        <div class="form-group">
                            <label>SMTP Host:</label>
                            <input type="text" name="settings[smtp_host]" 
                                   value="<?php echo htmlspecialchars($settings['smtp_host'] ?? ''); ?>"
                                   class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="settings[enable_email_notifications]" value="1"
                                    <?php echo ($settings['enable_email_notifications'] ?? '0') === '1' ? 'checked' : ''; ?>>
                                Ativar notificações por email
                            </label>
                        </div>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Configurações
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: var(--gradient-metal);
    border-radius: var(--border-radius);
    padding: 1.5rem;
    border: 1px solid var(--metal-border);
    display: flex;
    align-items: center;
    gap: 1rem;
}

.stat-icon {
    font-size: 2.5rem;
    color: var(--primary);
}

.stat-content {
    flex: 1;
}

.stat-number {
    font-size: 2rem;
    font-weight: 700;
    color: var(--text-primary);
}

.stat-label {
    color: var(--text-secondary);
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
}

.stat-detail {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
}

.badge {
    padding: 0.25rem 0.5rem;
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 600;
}

.badge.success {
    background: rgba(0, 200, 83, 0.2);
    color: var(--success);
}

.badge.warning {
    background: rgba(255, 215, 0, 0.2);
    color: var(--accent-yellow);
}

.badge.info {
    background: rgba(33, 150, 243, 0.2);
    color: var(--info);
}

.badge.error {
    background: rgba(255, 82, 82, 0.2);
    color: var(--error);
}

.admin-tabs {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 2rem;
    border-bottom: 2px solid var(--metal-border);
    padding-bottom: 0.5rem;
}

.tab-btn {
    background: none;
    border: none;
    color: var(--text-secondary);
    padding: 0.75rem 1.5rem;
    border-radius: var(--border-radius-sm);
    cursor: pointer;
    transition: var(--transition-normal);
    font-weight: 600;
}

.tab-btn:hover {
    color: var(--text-primary);
    background: rgba(255, 255, 255, 0.05);
}

.tab-btn.active {
    color: var(--primary);
    background: rgba(255, 0, 0, 0.1);
    border-bottom: 2px solid var(--primary);
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

.table-responsive {
    overflow-x: auto;
}

.admin-table {
    width: 100%;
    border-collapse: collapse;
}

.admin-table th {
    background: rgba(255, 255, 255, 0.05);
    color: var(--text-secondary);
    font-weight: 600;
    text-align: left;
    padding: 1rem;
    border-bottom: 2px solid var(--metal-border);
}

.admin-table td {
    padding: 1rem;
    border-bottom: 1px solid var(--metal-border);
    color: var(--text-primary);
}

.admin-table tr:hover {
    background: rgba(255, 255, 255, 0.02);
}

.user-cell {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.user-avatar {
    width: 36px;
    height: 36px;
    background: var(--gradient-primary);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 0.9rem;
}

.user-info {
    display: flex;
    flex-direction: column;
}

.user-info small {
    color: var(--text-muted);
    font-size: 0.8rem;
}

.action-buttons {
    display: flex;
    gap: 0.5rem;
}

.system-info {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.info-item {
    background: rgba(255, 255, 255, 0.03);
    padding: 1rem;
    border-radius: var(--border-radius-sm);
    border: 1px solid var(--metal-border);
}

.info-item label {
    display: block;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
    font-weight: 600;
}

.progress {
    height: 24px;
    background: var(--metal-border);
    border-radius: 12px;
    overflow: hidden;
    position: relative;
}

.progress-fill {
    height: 100%;
    background: var(--gradient-primary);
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 40px;
}

.progress-fill span {
    color: white;
    font-size: 0.8rem;
    font-weight: 600;
}

.system-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
}

.settings-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-bottom: 2rem;
}

.setting-group {
    background: rgba(255, 255, 255, 0.03);
    padding: 1.5rem;
    border-radius: var(--border-radius-sm);
    border: 1px solid var(--metal-border);
}

.setting-group h4 {
    color: var(--accent-yellow);
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
</style>

<script>
// Abas
document.querySelectorAll('.tab-btn').forEach(button => {
    button.addEventListener('click', function() {
        // Remover classe active de todas as abas
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        
        // Adicionar classe active à aba clicada
        this.classList.add('active');
        const tabId = this.getAttribute('data-tab') + '-tab';
        document.getElementById(tabId).classList.add('active');
    });
});

// Gerenciar usuários
function manageUser(userId, action) {
    if (!confirm(`Tem certeza que deseja ${action} este usuário?`)) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'manage_user');
    formData.append('user_id', userId);
    formData.append('type', action);
    formData.append('csrf_token', '<?php echo csrf_token(); ?>');
    
    fetch('admin.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(() => {
        location.reload();
    });
}

function deleteUser(userId) {
    if (!confirm('Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.')) {
        return;
    }
    
    manageUser(userId, 'delete');
}

function deleteProcess(processId) {
    if (!confirm('Tem certeza que deseja excluir este processamento?')) {
        return;
    }
    
    fetch('api/admin.php?action=delete_process&id=' + processId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Erro: ' + data.error);
            }
        });
}

// Sistema
function clearCache() {
    fetch('api/admin.php?action=clear_cache')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Cache limpo com sucesso!');
            } else {
                alert('Erro: ' + data.error);
            }
        });
}

function restartWorkers() {
    if (!confirm('Reiniciar workers interromperá processamentos em andamento. Continuar?')) {
        return;
    }
    
    fetch('api/admin.php?action=restart_workers')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Workers reiniciados com sucesso!');
            } else {
                alert('Erro: ' + data.error);
            }
        });
}

function runMaintenance() {
    if (!confirm('Executar manutenção pode levar alguns minutos. Continuar?')) {
        return;
    }
    
    fetch('api/admin.php?action=maintenance')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Manutenção concluída com sucesso!');
            } else {
                alert('Erro: ' + data.error);
            }
        });
}

function refreshStats() {
    location.reload();
}
</script>

<?php
$db->close();
require_once 'includes/footer.php';

function truncate($string, $length = 50) {
    if (strlen($string) > $length) {
        return substr($string, 0, $length) . '...';
    }
    return $string;
}

function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>