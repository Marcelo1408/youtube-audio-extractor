#!/usr/bin/env python3
"""
Script para download de vídeos do YouTube usando yt-dlp
"""

import os
import sys
import json
import subprocess
import logging
from datetime import datetime
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/www/youtube-audio-extractor/logs/download.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class YouTubeDownloader:
    def __init__(self, config_path=None):
        self.config = self.load_config(config_path)
        self.video_path = self.config.get('video_path', '/var/www/youtube-audio-extractor/assets/uploads/videos')
        self.audio_path = self.config.get('audio_path', '/var/www/youtube-audio-extractor/assets/uploads/audio')
        
        # Criar diretórios se não existirem
        Path(self.video_path).mkdir(parents=True, exist_ok=True)
        Path(self.audio_path).mkdir(parents=True, exist_ok=True)
    
    def load_config(self, config_path):
        """Carregar configurações"""
        default_config = {
            'video_path': '/var/www/youtube-audio-extractor/assets/uploads/videos',
            'audio_path': '/var/www/youtube-audio-extractor/assets/uploads/audio',
            'max_duration': 7200,  # 2 horas
            'quality': 'bestaudio/best',
            'format': 'mp3',
            'bitrate': '192k'
        }
        
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r') as f:
                user_config = json.load(f)
                default_config.update(user_config)
        
        return default_config
    
    def extract_video_id(self, url):
        """Extrair ID do vídeo da URL"""
        import re
        
        patterns = [
            r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})',
            r'(?:v=)([a-zA-Z0-9_-]{11})'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        
        return None
    
    def get_video_info(self, url):
        """Obter informações do vídeo usando yt-dlp"""
        try:
            cmd = [
                'yt-dlp',
                '--dump-json',
                '--no-warnings',
                url
            ]
            
            logger.info(f"Obtendo informações do vídeo: {url}")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                info = json.loads(result.stdout)
                return {
                    'id': info.get('id'),
                    'title': info.get('title'),
                    'duration': info.get('duration'),
                    'thumbnail': info.get('thumbnail'),
                    'channel': info.get('uploader'),
                    'description': info.get('description'),
                    'view_count': info.get('view_count'),
                    'like_count': info.get('like_count'),
                    'upload_date': info.get('upload_date')
                }
            else:
                logger.error(f"Erro ao obter informações: {result.stderr}")
                return None
                
        except subprocess.TimeoutExpired:
            logger.error("Timeout ao obter informações do vídeo")
            return None
        except Exception as e:
            logger.error(f"Erro ao obter informações: {str(e)}")
            return None
    
    def download_audio(self, url, quality='192', output_format='mp3'):
        """Download direto do áudio em formato MP3"""
        try:
            video_id = self.extract_video_id(url)
            if not video_id:
                raise ValueError("URL do YouTube inválida")
            
            output_file = os.path.join(self.audio_path, f"{video_id}.{output_format}")
            
            # Comando yt-dlp para baixar apenas áudio
            cmd = [
                'yt-dlp',
                '-x',  # Extrair áudio
                '--audio-format', output_format,
                '--audio-quality', f'{quality}K',
                '--output', output_file,
                '--no-warnings',
                '--no-playlist',
                url
            ]
            
            logger.info(f"Baixando áudio: {url}")
            logger.info(f"Comando: {' '.join(cmd)}")
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Monitorar progresso
            for line in process.stdout:
                if line.strip():
                    logger.info(f"Progresso: {line.strip()}")
            
            process.wait()
            
            if process.returncode == 0 and os.path.exists(output_file):
                file_size = os.path.getsize(output_file)
                logger.info(f"Download concluído: {output_file} ({file_size} bytes)")
                
                return {
                    'success': True,
                    'video_id': video_id,
                    'file_path': output_file,
                    'file_size': file_size,
                    'format': output_format,
                    'bitrate': quality
                }
            else:
                error_msg = process.stderr.read()
                logger.error(f"Erro no download: {error_msg}")
                return {
                    'success': False,
                    'error': error_msg
                }
                
        except Exception as e:
            logger.error(f"Erro no download: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def download_video(self, url, resolution='720p'):
        """Download do vídeo completo"""
        try:
            video_id = self.extract_video_id(url)
            if not video_id:
                raise ValueError("URL do YouTube inválida")
            
            output_template = os.path.join(self.video_path, f"{video_id}.%(ext)s")
            
            # Comando yt-dlp para baixar vídeo
            cmd = [
                'yt-dlp',
                '-f', f'bestvideo[height<={resolution[:-1]}]+bestaudio/best[height<={resolution[:-1]}]',
                '--merge-output-format', 'mp4',
                '--output', output_template,
                '--no-warnings',
                '--no-playlist',
                url
            ]
            
            logger.info(f"Baixando vídeo: {url}")
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Monitorar progresso
            for line in process.stdout:
                if line.strip():
                    logger.info(f"Progresso: {line.strip()}")
            
            process.wait()
            
            # Encontrar arquivo baixado
            downloaded_files = list(Path(self.video_path).glob(f"{video_id}.*"))
            
            if process.returncode == 0 and downloaded_files:
                video_file = str(downloaded_files[0])
                file_size = os.path.getsize(video_file)
                logger.info(f"Download concluído: {video_file} ({file_size} bytes)")
                
                return {
                    'success': True,
                    'video_id': video_id,
                    'file_path': video_file,
                    'file_size': file_size,
                    'format': 'mp4',
                    'resolution': resolution
                }
            else:
                error_msg = process.stderr.read()
                logger.error(f"Erro no download: {error_msg}")
                return {
                    'success': False,
                    'error': error_msg
                }
                
        except Exception as e:
            logger.error(f"Erro no download: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }

def main():
    """Função principal"""
    if len(sys.argv) < 3:
        print("Uso: python download_video.py <url> <tipo> [qualidade]")
        print("Tipos: audio, video")
        print("Exemplo: python download_video.py https://youtube.com/watch?v=... audio 192")
        sys.exit(1)
    
    url = sys.argv[1]
    download_type = sys.argv[2]
    quality = sys.argv[3] if len(sys.argv) > 3 else '192'
    
    downloader = YouTubeDownloader()
    
    # Obter informações primeiro
    info = downloader.get_video_info(url)
    if info:
        print(f"Título: {info['title']}")
        print(f"Duração: {info['duration']} segundos")
        print(f"Canal: {info['channel']}")
    
    # Realizar download
    if download_type == 'audio':
        result = downloader.download_audio(url, quality)
    elif download_type == 'video':
        resolution = f"{quality}p" if quality.isdigit() else quality
        result = downloader.download_video(url, resolution)
    else:
        print(f"Tipo inválido: {download_type}")
        sys.exit(1)
    
    # Exibir resultado
    if result['success']:
        print(f"Download concluído com sucesso!")
        print(f"Arquivo: {result['file_path']}")
        print(f"Tamanho: {result['file_size']} bytes")
        
        # Salvar metadados
        metadata = {
            'url': url,
            'type': download_type,
            'result': result,
            'info': info,
            'timestamp': datetime.now().isoformat()
        }
        
        metadata_file = result['file_path'] + '.json'
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
            
        print(f"Metadados salvos em: {metadata_file}")
    else:
        print(f"Erro no download: {result.get('error', 'Erro desconhecido')}")
        sys.exit(1)

if __name__ == "__main__":
    main()