#!/usr/bin/env python3
"""
Script para extrair áudio de vídeos usando FFmpeg
"""

import os
import sys
import json
import subprocess
import logging
from pathlib import Path
from pydub import AudioSegment

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/www/youtube-audio-extractor/logs/audio_extract.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AudioExtractor:
    def __init__(self, ffmpeg_path='/usr/bin/ffmpeg'):
        self.ffmpeg_path = ffmpeg_path
        self.output_path = '/var/www/youtube-audio-extractor/assets/uploads/audio'
        
        # Verificar se FFmpeg está instalado
        if not os.path.exists(ffmpeg_path):
            raise FileNotFoundError(f"FFmpeg não encontrado em: {ffmpeg_path}")
        
        # Criar diretório de saída
        Path(self.output_path).mkdir(parents=True, exist_ok=True)
    
    def get_audio_info(self, audio_file):
        """Obter informações do arquivo de áudio"""
        try:
            cmd = [
                self.ffmpeg_path,
                '-i', audio_file,
                '-hide_banner'
            ]
            
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True,
                timeout=10
            )
            
            info = {
                'duration': 0,
                'bitrate': 0,
                'sample_rate': 0,
                'channels': 0,
                'format': ''
            }
            
            # Analisar saída do FFmpeg
            output = result.stderr
            
            # Extrair duração
            import re
            duration_match = re.search(r'Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})', output)
            if duration_match:
                hours, minutes, seconds = map(float, duration_match.groups())
                info['duration'] = int(hours * 3600 + minutes * 60 + seconds)
            
            # Extrair bitrate
            bitrate_match = re.search(r'bitrate: (\d+) kb/s', output)
            if bitrate_match:
                info['bitrate'] = int(bitrate_match.group(1))
            
            # Extrair informações de áudio
            audio_match = re.search(r'Audio: (\w+), (\d+) Hz', output)
            if audio_match:
                info['format'] = audio_match.group(1)
                info['sample_rate'] = int(audio_match.group(2))
            
            # Extrair canais
            channels_match = re.search(r'(mono|stereo|5\.1|7\.1)', output)
            if channels_match:
                channels = channels_match.group(1)
                if channels == 'mono':
                    info['channels'] = 1
                elif channels == 'stereo':
                    info['channels'] = 2
                else:
                    info['channels'] = int(channels[0]) if channels[0].isdigit() else 2
            
            return info
            
        except Exception as e:
            logger.error(f"Erro ao obter informações do áudio: {str(e)}")
            return None
    
    def convert_to_mp3(self, input_file, output_file=None, bitrate='192k'):
        """Converter arquivo para MP3"""
        try:
            if not output_file:
                base_name = os.path.splitext(os.path.basename(input_file))[0]
                output_file = os.path.join(self.output_path, f"{base_name}.mp3")
            
            cmd = [
                self.ffmpeg_path,
                '-i', input_file,
                '-codec:a', 'libmp3lame',
                '-qscale:a', '2',  # Qualidade 2 (0-9, 0=melhor)
                '-b:a', bitrate,
                '-y',  # Sobrescrever arquivo existente
                output_file
            ]
            
            logger.info(f"Convertendo para MP3: {input_file}")
            logger.info(f"Comando: {' '.join(cmd)}")
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Monitorar progresso
            for line in process.stderr:
                if 'time=' in line:
                    logger.info(f"Progresso: {line.strip()}")
            
            process.wait()
            
            if process.returncode == 0 and os.path.exists(output_file):
                file_size = os.path.getsize(output_file)
                audio_info = self.get_audio_info(output_file)
                
                logger.info(f"Conversão concluída: {output_file} ({file_size} bytes)")
                
                return {
                    'success': True,
                    'input_file': input_file,
                    'output_file': output_file,
                    'file_size': file_size,
                    'bitrate': bitrate,
                    'format': 'mp3',
                    'audio_info': audio_info
                }
            else:
                error_msg = process.stderr.read()
                logger.error(f"Erro na conversão: {error_msg}")
                return {
                    'success': False,
                    'error': error_msg
                }
                
        except Exception as e:
            logger.error(f"Erro na conversão: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def extract_audio_from_video(self, video_file, output_format='mp3', bitrate='192k'):
        """Extrair áudio de arquivo de vídeo"""
        try:
            base_name = os.path.splitext(os.path.basename(video_file))[0]
            output_file = os.path.join(self.output_path, f"{base_name}.{output_format}")
            
            cmd = [
                self.ffmpeg_path,
                '-i', video_file,
                '-vn',  # Sem vídeo
                '-acodec', 'libmp3lame' if output_format == 'mp3' else 'copy',
                '-ab', bitrate,
                '-ar', '44100',  # Taxa de amostragem
                '-ac', '2',  # Estéreo
                '-y',
                output_file
            ]
            
            logger.info(f"Extraindo áudio do vídeo: {video_file}")
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Monitorar progresso
            for line in process.stderr:
                if 'time=' in line:
                    logger.info(f"Progresso: {line.strip()}")
            
            process.wait()
            
            if process.returncode == 0 and os.path.exists(output_file):
                file_size = os.path.getsize(output_file)
                audio_info = self.get_audio_info(output_file)
                
                logger.info(f"Extração concluída: {output_file} ({file_size} bytes)")
                
                return {
                    'success': True,
                    'video_file': video_file,
                    'audio_file': output_file,
                    'file_size': file_size,
                    'bitrate': bitrate,
                    'format': output_format,
                    'audio_info': audio_info
                }
            else:
                error_msg = process.stderr.read()
                logger.error(f"Erro na extração: {error_msg}")
                return {
                    'success': False,
                    'error': error_msg
                }
                
        except Exception as e:
            logger.error(f"Erro na extração: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def split_by_silence(self, audio_file, min_silence_len=1000, silence_thresh=-40):
        """Dividir áudio por silêncio (para podcasts, etc.)"""
        try:
            from pydub import AudioSegment
            from pydub.silence import split_on_silence
            
            logger.info(f"Dividindo áudio por silêncio: {audio_file}")
            
            # Carregar áudio
            audio = AudioSegment.from_file(audio_file)
            
            # Dividir por silêncio
            chunks = split_on_silence(
                audio,
                min_silence_len=min_silence_len,
                silence_thresh=silence_thresh,
                keep_silence=500
            )
            
            logger.info(f"Encontrados {len(chunks)} segmentos")
            
            # Salvar segmentos
            segments = []
            base_name = os.path.splitext(os.path.basename(audio_file))[0]
            
            for i, chunk in enumerate(chunks):
                segment_file = os.path.join(
                    self.output_path,
                    f"{base_name}_segment_{i+1:03d}.mp3"
                )
                
                chunk.export(segment_file, format='mp3', bitrate='192k')
                segment_size = os.path.getsize(segment_file)
                
                segments.append({
                    'segment': i + 1,
                    'file_path': segment_file,
                    'file_size': segment_size,
                    'duration': len(chunk) / 1000  # Converter para segundos
                })
                
                logger.info(f"Segmento {i+1}: {segment_file} ({segment_size} bytes)")
            
            return {
                'success': True,
                'original_file': audio_file,
                'segments': segments,
                'total_segments': len(segments)
            }
            
        except Exception as e:
            logger.error(f"Erro ao dividir áudio: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }

def main():
    """Função principal"""
    if len(sys.argv) < 3:
        print("Uso: python extract_audio.py <arquivo> <ação> [parâmetros]")
        print("Ações: convert, extract, split")
        print("Exemplos:")
        print("  python extract_audio.py video.mp4 extract mp3 192k")
        print("  python extract_audio.py audio.wav convert mp3")
        print("  python extract_audio.py podcast.mp3 split")
        sys.exit(1)
    
    input_file = sys.argv[1]
    action = sys.argv[2]
    
    if not os.path.exists(input_file):
        print(f"Arquivo não encontrado: {input_file}")
        sys.exit(1)
    
    extractor = AudioExtractor()
    
    if action == 'extract':
        output_format = sys.argv[3] if len(sys.argv) > 3 else 'mp3'
        bitrate = sys.argv[4] if len(sys.argv) > 4 else '192k'
        result = extractor.extract_audio_from_video(input_file, output_format, bitrate)
    
    elif action == 'convert':
        output_format = sys.argv[3] if len(sys.argv) > 3 else 'mp3'
        bitrate = sys.argv[4] if len(sys.argv) > 4 else '192k'
        result = extractor.convert_to_mp3(input_file, bitrate=bitrate)
    
    elif action == 'split':
        min_silence = int(sys.argv[3]) if len(sys.argv) > 3 else 1000
        silence_thresh = int(sys.argv[4]) if len(sys.argv) > 4 else -40
        result = extractor.split_by_silence(input_file, min_silence, silence_thresh)
    
    else:
        print(f"Ação inválida: {action}")
        sys.exit(1)
    
    # Exibir resultado
    if result['success']:
        print("Operação concluída com sucesso!")
        
        if 'audio_file' in result:
            print(f"Áudio extraído: {result['audio_file']}")
            print(f"Tamanho: {result['file_size']} bytes")
        
        if 'output_file' in result:
            print(f"Arquivo convertido: {result['output_file']}")
            print(f"Tamanho: {result['file_size']} bytes")
        
        if 'segments' in result:
            print(f"Total de segmentos: {result['total_segments']}")
            for seg in result['segments']:
                print(f"  Segmento {seg['segment']}: {seg['file_path']}")
        
        # Salvar resultado
        result_file = f"{input_file}.result.json"
        with open(result_file, 'w') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"Resultado salvo em: {result_file}")
    
    else:
        print(f"Erro: {result.get('error', 'Erro desconhecido')}")
        sys.exit(1)

if __name__ == "__main__":
    main()