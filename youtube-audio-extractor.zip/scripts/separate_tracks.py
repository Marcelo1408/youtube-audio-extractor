#!/usr/bin/env python3
"""
Script para separar faixas de áudio usando Spleeter
"""

import os
import sys
import json
import subprocess
import logging
import shutil
from pathlib import Path
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/www/youtube-audio-extractor/logs/spleeter.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class SpleeterSeparator:
    def __init__(self, spleeter_path=None):
        self.spleeter_path = spleeter_path or self.find_spleeter()
        self.output_path = '/var/www/youtube-audio-extractor/assets/uploads/tracks'
        
        # Verificar se Spleeter está instalado
        if not self.spleeter_path:
            raise EnvironmentError("Spleeter não encontrado. Instale com: pip install spleeter")
        
        # Criar diretório de saída
        Path(self.output_path).mkdir(parents=True, exist_ok=True)
        
        # Mapeamento de stems
        self.stem_names = {
            2: ['vocals', 'accompaniment'],
            4: ['vocals', 'drums', 'bass', 'other'],
            5: ['vocals', 'drums', 'bass', 'piano', 'other']
        }
    
    def find_spleeter(self):
        """Encontrar caminho do Spleeter"""
        try:
            import spleeter
            return 'spleeter'
        except ImportError:
            # Tentar encontrar no PATH
            if shutil.which('spleeter'):
                return 'spleeter'
        return None
    
    def separate(self, audio_file, stems=2, output_format='mp3', bitrate='192k'):
        """Separar faixas de áudio usando Spleeter"""
        try:
            if stems not in [2, 4, 5]:
                raise ValueError("Stems deve ser 2, 4 ou 5")
            
            # Criar diretório de saída baseado no nome do arquivo
            base_name = Path(audio_file).stem
            output_dir = Path(self.output_path) / base_name
            output_dir.mkdir(parents=True, exist_ok=True)
            
            # Comando Spleeter
            cmd = [
                self.spleeter_path,
                'separate',
                '-p', f'spleeter:{stems}stems',
                '-o', str(output_dir),
                '-c', output_format,
                '-b', bitrate,
                str(audio_file)
            ]
            
            logger.info(f"Separando faixas: {audio_file}")
            logger.info(f"Comando: {' '.join(cmd)}")
            
            # Executar Spleeter
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Capturar saída em tempo real
            stdout_lines = []
            stderr_lines = []
            
            for line in process.stdout:
                stdout_lines.append(line.strip())
                logger.info(f"Spleeter: {line.strip()}")
            
            for line in process.stderr:
                stderr_lines.append(line.strip())
                if line.strip() and not line.startswith('WARNING:'):
                    logger.error(f"Spleeter error: {line.strip()}")
            
            process.wait()
            
            if process.returncode == 0:
                # Processar arquivos gerados
                tracks = self.process_output_files(output_dir, base_name, stems, output_format)
                
                logger.info(f"Separação concluída. {len(tracks)} faixas geradas.")
                
                return {
                    'success': True,
                    'audio_file': audio_file,
                    'output_dir': str(output_dir),
                    'stems': stems,
                    'tracks': tracks,
                    'stdout': stdout_lines,
                    'stderr': stderr_lines
                }
            else:
                error_msg = '\n'.join(stderr_lines)
                logger.error(f"Erro no Spleeter: {error_msg}")
                
                return {
                    'success': False,
                    'error': error_msg,
                    'stderr': stderr_lines
                }
                
        except Exception as e:
            logger.error(f"Erro na separação: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def process_output_files(self, output_dir, base_name, stems, output_format):
        """Processar arquivos gerados pelo Spleeter"""
        tracks = []
        
        # Encontrar diretório com os stems
        stems_dir = output_dir / base_name
        
        if not stems_dir.exists():
            # Tentar encontrar em subdiretórios
            for item in output_dir.iterdir():
                if item.is_dir():
                    stems_dir = item
                    break
        
        if not stems_dir.exists():
            logger.warning(f"Diretório de stems não encontrado: {stems_dir}")
            return tracks
        
        # Processar cada stem
        for i, stem_name in enumerate(self.stem_names[stems], 1):
            stem_file = stems_dir / f"{stem_name}.{output_format}"
            
            if stem_file.exists():
                # Mover para o diretório principal
                new_file = output_dir / f"{stem_name}.{output_format}"
                shutil.move(str(stem_file), str(new_file))
                
                # Obter informações do arquivo
                file_size = new_file.stat().st_size
                
                tracks.append({
                    'track_number': i,
                    'track_name': stem_name.capitalize(),
                    'stem_name': stem_name,
                    'file_name': new_file.name,
                    'file_path': str(new_file),
                    'file_size': file_size,
                    'format': output_format
                })
                
                logger.info(f"Faixa {i} criada: {new_file} ({file_size} bytes)")
        
        # Remover diretório de stems se estiver vazio
        try:
            if stems_dir.exists():
                shutil.rmtree(str(stems_dir))
        except:
            pass
        
        return tracks
    
    def separate_batch(self, audio_files, stems=2, output_format='mp3'):
        """Separar múltiplos arquivos em lote"""
        results = []
        
        for audio_file in audio_files:
            logger.info(f"Processando: {audio_file}")
            result = self.separate(audio_file, stems, output_format)
            results.append(result)
            
            if not result['success']:
                logger.warning(f"Falha ao processar {audio_file}: {result.get('error')}")
        
        return results

def main():
    """Função principal"""
    if len(sys.argv) < 3:
        print("Uso: python separate_tracks.py <arquivo_audio> <stems> [formato]")
        print("Stems: 2, 4, ou 5")
        print("Formato: mp3 (padrão), wav, ogg")
        print("Exemplo: python separate_tracks.py audio.mp3 2 mp3")
        sys.exit(1)
    
    audio_file = sys.argv[1]
    stems = int(sys.argv[2])
    output_format = sys.argv[3] if len(sys.argv) > 3 else 'mp3'
    
    if not os.path.exists(audio_file):
        print(f"Arquivo não encontrado: {audio_file}")
        sys.exit(1)
    
    if stems not in [2, 4, 5]:
        print(f"Número de stems inválido: {stems}. Use 2, 4 ou 5.")
        sys.exit(1)
    
    try:
        separator = SpleeterSeparator()
        
        # Verificar se é um lote
        if os.path.isdir(audio_file):
            audio_files = list(Path(audio_file).glob('*.mp3')) + \
                         list(Path(audio_file).glob('*.wav')) + \
                         list(Path(audio_file).glob('*.ogg'))
            
            if not audio_files:
                print(f"Nenhum arquivo de áudio encontrado em: {audio_file}")
                sys.exit(1)
            
            print(f"Processando {len(audio_files)} arquivos...")
            results = separator.separate_batch(audio_files, stems, output_format)
            
            successful = sum(1 for r in results if r['success'])
            failed = len(results) - successful
            
            print(f"Processamento em lote concluído:")
            print(f"  Sucesso: {successful}")
            print(f"  Falhas: {failed}")
            
            # Salvar relatório
            report_file = f"batch_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_file, 'w') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            print(f"Relatório salvo em: {report_file}")
            
        else:
            # Processar arquivo único
            result = separator.separate(audio_file, stems, output_format)
            
            if result['success']:
                print("Separação concluída com sucesso!")
                print(f"Diretório de saída: {result['output_dir']}")
                print(f"Faixas geradas:")
                
                for track in result['tracks']:
                    print(f"  {track['track_number']}. {track['track_name']}:")
                    print(f"     Arquivo: {track['file_name']}")
                    print(f"     Tamanho: {track['file_size']} bytes")
                    print(f"     Caminho: {track['file_path']}")
                
                # Salvar metadados
                metadata_file = Path(audio_file).with_suffix('.metadata.json')
                with open(metadata_file, 'w') as f:
                    json.dump(result, f, indent=2, ensure_ascii=False)
                print(f"Metadados salvos em: {metadata_file}")
            else:
                print(f"Erro na separação: {result.get('error', 'Erro desconhecido')}")
                sys.exit(1)
                
    except Exception as e:
        print(f"Erro: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()