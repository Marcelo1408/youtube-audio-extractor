#!/bin/bash

# YouTube Audio Extractor - Instalador Completo
# Para VPS Debian 12

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função para log
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERRO] $1${NC}"
    exit 1
}

# Verificar se é root
if [[ $EUID -ne 0 ]]; then
   error "Este script precisa ser executado como root"
fi

log "Iniciando instalação do YouTube Audio Extractor..."

# Atualizar sistema
log "Atualizando sistema..."
apt update && apt upgrade -y

# Instalar dependências do sistema
log "Instalando dependências do sistema..."
apt install -y \
    apache2 \
    mysql-server \
    php8.2 \
    php8.2-mysql \
    php8.2-curl \
    php8.2-gd \
    php8.2-mbstring \
    php8.2-xml \
    php8.2-zip \
    python3 \
    python3-pip \
    python3-venv \
    ffmpeg \
    libavcodec-extra \
    git \
    wget \
    curl \
    unzip \
    zip \
    redis-server \
    supervisor \
    nginx \
    certbot \
    python3-certbot-nginx \
    libssl-dev \
    libffi-dev \
    build-essential

# Instalar PHP adicional
apt install -y \
    php8.2-redis \
    php8.2-bcmath \
    php8.2-intl

# Instalar Node.js (opcional para futuras melhorias)
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs

# Configurar MySQL
log "Configurando MySQL..."
mysql_secure_installation <<EOF
n
y
y
y
y
EOF

# Criar banco de dados e usuário
log "Criando banco de dados..."
mysql -e "CREATE DATABASE IF NOT EXISTS youtube_extractor CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -e "CREATE USER IF NOT EXISTS 'youtube_user'@'localhost' IDENTIFIED BY 'SenhaSegura123!';"
mysql -e "GRANT ALL PRIVILEGES ON youtube_extractor.* TO 'youtube_user'@'localhost';"
mysql -e "FLUSH PRIVILEGES;"

# Instalar yt-dlp (alternativa moderna ao youtube-dl)
log "Instalando yt-dlp..."
pip3 install yt-dlp

# Instalar Spleeter
log "Instalando Spleeter..."
pip3 install spleeter

# Instalar TensorFlow
log "Instalando TensorFlow..."
pip3 install tensorflow

# Instalar outras bibliotecas Python
log "Instalando bibliotecas Python adicionais..."
pip3 install pydub mutagen redis celery

# Clonar repositório ou criar estrutura
log "Criando estrutura do projeto..."
PROJECT_DIR="/var/www/youtube-audio-extractor"
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

# Criar diretórios necessários
mkdir -p {app,scripts,api,includes,assets/{css,js,uploads/{videos,audio,tracks,temp}},sql,logs,systemd}

# Configurar permissões
log "Configurando permissões..."
chown -R www-data:www-data $PROJECT_DIR
chmod -R 755 $PROJECT_DIR/assets/uploads
chmod -R 755 $PROJECT_DIR/logs

# Configurar Apache
log "Configurando Apache..."
cat > /etc/apache2/sites-available/youtube-extractor.conf <<EOF
<VirtualHost *:80>
    ServerName seu-dominio.com
    ServerAdmin webmaster@seu-dominio.com
    DocumentRoot $PROJECT_DIR
    
    ErrorLog \${APACHE_LOG_DIR}/youtube-error.log
    CustomLog \${APACHE_LOG_DIR}/youtube-access.log combined
    
    <Directory $PROJECT_DIR>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    # Aumentar limites para uploads grandes
    LimitRequestBody 1073741824
    php_value upload_max_filesize 1G
    php_value post_max_size 1G
    php_value max_execution_time 300
    php_value max_input_time 300
    php_value memory_limit 512M
</VirtualHost>
EOF

# Desabilitar site padrão e habilitar novo
a2dissite 000-default.conf
a2ensite youtube-extractor.conf

# Habilitar módulos Apache
a2enmod rewrite headers expires

# Configurar PHP
log "Configurando PHP..."
sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 1G/' /etc/php/8.2/apache2/php.ini
sed -i 's/^post_max_size = .*/post_max_size = 1G/' /etc/php/8.2/apache2/php.ini
sed -i 's/^max_execution_time = .*/max_execution_time = 300/' /etc/php/8.2/apache2/php.ini
sed -i 's/^max_input_time = .*/max_input_time = 300/' /etc/php/8.2/apache2/php.ini
sed -i 's/^memory_limit = .*/memory_limit = 512M/' /etc/php/8.2/apache2/php.ini

# Configurar Redis
log "Configurando Redis..."
sed -i 's/^supervised no/supervised systemd/' /etc/redis/redis.conf
systemctl restart redis

# Configurar Supervisor para workers
log "Configurando Supervisor..."
cat > /etc/supervisor/conf.d/youtube-worker.conf <<EOF
[program:youtube-worker]
command=python3 $PROJECT_DIR/scripts/worker.py
directory=$PROJECT_DIR
user=www-data
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=$PROJECT_DIR/logs/worker.log
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=5
environment=PATH="/usr/bin:/usr/local/bin"
EOF

# Recarregar Supervisor
supervisorctl reread
supervisorctl update
supervisorctl start youtube-worker

# Configurar sistema de filas (Celery opcional)
log "Configurando sistema de filas..."
cat > $PROJECT_DIR/scripts/celery_worker.sh <<EOF
#!/bin/bash
cd $PROJECT_DIR
celery -A worker.celery worker --loglevel=info
EOF

chmod +x $PROJECT_DIR/scripts/celery_worker.sh

# Configurar SSL com Let's Encrypt
log "Configurando SSL..."
echo ""
echo "Para configurar SSL, execute após configurar DNS:"
echo "certbot --nginx -d seu-dominio.com -d www.seu-dominio.com"
echo ""

# Criar cron jobs
log "Configurando cron jobs..."
(crontab -l 2>/dev/null; echo "0 2 * * * /usr/bin/find $PROJECT_DIR/assets/uploads/temp -type f -mtime +1 -delete") | crontab -
(crontab -l 2>/dev/null; echo "*/5 * * * * /usr/bin/php $PROJECT_DIR/scripts/cleanup.php") | crontab -
(crontab -l 2>/dev/null; echo "0 0 * * * /usr/bin/mysqldump -u youtube_user -p'SenhaSegura123!' youtube_extractor > $PROJECT_DIR/backup/db_backup_\$(date +\%Y\%m\%d).sql") | crontab -

# Criar script de backup
mkdir -p $PROJECT_DIR/backup
cat > $PROJECT_DIR/scripts/backup.sh <<EOF
#!/bin/bash
BACKUP_DIR="$PROJECT_DIR/backup"
DATE=\$(date +%Y%m%d_%H%M%S)

# Backup do banco
mysqldump -u youtube_user -p'SenhaSegura123!' youtube_extractor > \$BACKUP_DIR/db_backup_\$DATE.sql
gzip \$BACKUP_DIR/db_backup_\$DATE.sql

# Backup dos uploads
tar -czf \$BACKUP_DIR/uploads_backup_\$DATE.tar.gz -C $PROJECT_DIR/assets/uploads .

# Manter apenas últimos 7 backups
find \$BACKUP_DIR -name "*.gz" -mtime +7 -delete
find \$BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
EOF

chmod +x $PROJECT_DIR/scripts/backup.sh

# Configurar firewall
log "Configurando firewall..."
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# Reiniciar serviços
log "Reiniciando serviços..."
systemctl restart apache2
systemctl restart redis
systemctl restart supervisor

# Instalação concluída
log "Instalação concluída!"
echo ""
echo "=============================================="
echo " YouTube Audio Extractor Instalado com Sucesso"
echo "=============================================="
echo ""
echo "Acesse o sistema em: http://$(curl -s ifconfig.me)"
echo ""
echo "Próximos passos:"
echo "1. Configure o arquivo .env com suas informações"
echo "2. Importe o banco de dados: mysql youtube_extractor < sql/database.sql"
echo "3. Configure o domínio no Apache"
echo "4. Execute o SSL: certbot --nginx"
echo "5. Acesse o admin em: http://audioextractor.giize.com/admin.php"
echo ""
echo "Credenciais padrão MySQL:"
echo "Usuário: audioextrac_usr"
echo "Senha: 3GqG!%Yg7i;YsI4Y"
echo "Banco: audioextractor"
echo ""
echo "Lembre-se de alterar todas as senhas padrão!"
