#!/usr/bin/env python3
"""
Worker principal para processamento em background
"""

import os
import sys
import json
import time
import redis
import logging
import threading
from datetime import datetime
from pathlib import Path
from download_video import YouTubeDownloader
from extract_audio import AudioExtractor
from separate_tracks import SpleeterSeparator

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/www/youtube-audio-extractor/logs/worker.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ProcessWorker:
    def __init__(self):
        # Configurações
        self.redis_host = 'localhost'
        self.redis_port = 6379
        self.redis_db = 0
        
        # Fila de processamento
        self.queue_name = 'youtube:process:queue'
        self.processing_queue = 'youtube:process:processing'
        self.completed_queue = 'youtube:process:completed'
        self.failed_queue = 'youtube:process:failed'
        
        # Conectar ao Redis
        self.redis_client = redis.Redis(
            host=self.redis_host,
            port=self.redis_port,
            db=self.redis_db,
            decode_responses=True
        )
        
        # Inicializar processadores
        self.downloader = YouTubeDownloader()
        self.extractor = AudioExtractor()
        self.separator = SpleeterSeparator()
        
        # Status do worker
        self.running = True
        self.worker_id = f"worker_{os.getpid()}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        logger.info(f"Worker iniciado: {self.worker_id}")
    
    def process_job(self, job_data):
        """Processar um job específico"""
        try:
            job_id = job_data.get('job_id')
            process_id = job_data.get('process_id')
            user_id = job_data.get('user_id')
            youtube_url = job_data.get('youtube_url')
            action = job_data.get('action', 'download_audio')
            params = job_data.get('params', {})
            
            logger.info(f"Processando job {job_id} para usuário {user_id}")
            
            # Atualizar status para processando
            self.update_status(process_id, 'processing', {'worker_id': self.worker_id})
            
            result = None
            
            if action == 'download_audio':
                # Baixar apenas áudio
                quality = params.get('quality', '192')
                format = params.get('format', 'mp3')
                
                result = self.downloader.download_audio(youtube_url, quality, format)
                
                if result['success']:
                    # Obter informações do áudio
                    audio_info = self.extractor.get_audio_info(result['file_path'])
                    
                    self.update_status(process_id, 'completed', {
                        'file_path': result['file_path'],
                        'file_size': result['file_size'],
                        'audio_info': audio_info
                    })
                    
                    logger.info(f"Download de áudio concluído: {result['file_path']}")
                else:
                    raise Exception(f"Erro no download: {result.get('error')}")
            
            elif action == 'download_video':
                # Baixar vídeo completo
                resolution = params.get('resolution', '720p')
                
                result = self.downloader.download_video(youtube_url, resolution)
                
                if result['success']:
                    self.update_status(process_id, 'completed', {
                        'file_path': result['file_path'],
                        'file_size': result['file_size'],
                        'resolution': result['resolution']
                    })
                    
                    logger.info(f"Download de vídeo concluído: {result['file_path']}")
                else:
                    raise Exception(f"Erro no download: {result.get('error')}")
            
            elif action == 'extract_audio':
                # Extrair áudio de vídeo existente
                video_file = params.get('video_file')
                format = params.get('format', 'mp3')
                bitrate = params.get('bitrate', '192k')
                
                if not os.path.exists(video_file):
                    raise FileNotFoundError(f"Arquivo de vídeo não encontrado: {video_file}")
                
                result = self.extractor.extract_audio_from_video(video_file, format, bitrate)
                
                if result['success']:
                    self.update_status(process_id, 'completed', {
                        'audio_file': result['audio_file'],
                        'file_size': result['file_size'],
                        'audio_info': result['audio_info']
                    })
                    
                    logger.info(f"Extração de áudio concluída: {result['audio_file']}")
                else:
                    raise Exception(f"Erro na extração: {result.get('error')}")
            
            elif action == 'separate_tracks':
                # Separar faixas de áudio
                audio_file = params.get('audio_file')
                stems = params.get('stems', 2)
                format = params.get('format', 'mp3')
                
                if not os.path.exists(audio_file):
                    raise FileNotFoundError(f"Arquivo de áudio não encontrado: {audio_file}")
                
                result = self.separator.separate(audio_file, stems, format)
                
                if result['success']:
                    self.update_status(process_id, 'completed', {
                        'output_dir': result['output_dir'],
                        'tracks': result['tracks'],
                        'stems': stems
                    })
                    
                    logger.info(f"Separação de faixas concluída: {len(result['tracks'])} faixas")
                else:
                    raise Exception(f"Erro na separação: {result.get('error')}")
            
            elif action == 'full_process':
                # Processamento completo: download + separação
                quality = params.get('quality', '192')
                format = params.get('format', 'mp3')
                stems = params.get('stems', 2)
                
                # 1. Baixar áudio
                logger.info("Fase 1: Baixando áudio do YouTube...")
                download_result = self.downloader.download_audio(youtube_url, quality, format)
                
                if not download_result['success']:
                    raise Exception(f"Erro no download: {download_result.get('error')}")
                
                # 2. Separar faixas (se solicitado)
                if stems > 0:
                    logger.info(f"Fase 2: Separando em {stems} faixas...")
                    separate_result = self.separator.separate(
                        download_result['file_path'], 
                        stems, 
                        format
                    )
                    
                    if separate_result['success']:
                        self.update_status(process_id, 'completed', {
                            'original_audio': download_result['file_path'],
                            'output_dir': separate_result['output_dir'],
                            'tracks': separate_result['tracks'],
                            'stems': stems
                        })
                        
                        logger.info(f"Processamento completo concluído: {len(separate_result['tracks'])} faixas")
                    else:
                        # Se falhar a separação, retornar apenas o áudio original
                        logger.warning(f"Separação falhou, retornando áudio original: {separate_result.get('error')}")
                        self.update_status(process_id, 'completed', {
                            'audio_file': download_result['file_path'],
                            'file_size': download_result['file_size'],
                            'warning': 'Separação de faixas falhou'
                        })
                else:
                    # Apenas download
                    self.update_status(process_id, 'completed', {
                        'audio_file': download_result['file_path'],
                        'file_size': download_result['file_size']
                    })
            
            else:
                raise ValueError(f"Ação desconhecida: {action}")
            
            # Mover job para fila de concluídos
            self.redis_client.lpush(self.completed_queue, json.dumps({
                'job_id': job_id,
                'process_id': process_id,
                'user_id': user_id,
                'action': action,
                'result': result,
                'completed_at': datetime.now().isoformat(),
                'worker_id': self.worker_id
            }))
            
            logger.info(f"Job {job_id} concluído com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao processar job {job_data.get('job_id')}: {str(e)}")
            
            # Mover job para fila de falhas
            self.redis_client.lpush(self.failed_queue, json.dumps({
                'job_id': job_data.get('job_id'),
                'process_id': job_data.get('process_id'),
                'user_id': job_data.get('user_id'),
                'action': job_data.get('action'),
                'error': str(e),
                'failed_at': datetime.now().isoformat(),
                'worker_id': self.worker_id
            }))
            
            # Atualizar status para falha
            self.update_status(job_data.get('process_id'), 'failed', {'error': str(e)})
    
    def update_status(self, process_id, status, data=None):
        """Atualizar status do processo no Redis"""
        try:
            status_key = f"youtube:process:{process_id}:status"
            
            status_data = {
                'process_id': process_id,
                'status': status,
                'updated_at': datetime.now().isoformat(),
                'worker_id': self.worker_id
            }
            
            if data:
                status_data.update(data)
            
            self.redis_client.set(status_key, json.dumps(status_data))
            self.redis_client.expire(status_key, 86400)  # Expira em 24 horas
            
            # Publicar atualização
            self.redis_client.publish(f"youtube:process:{process_id}", json.dumps(status_data))
            
        except Exception as e:
            logger.error(f"Erro ao atualizar status: {str(e)}")
    
    def run(self):
        """Loop principal do worker"""
        logger.info("Worker em execução. Aguardando jobs...")
        
        while self.running:
            try:
                # Buscar job da fila (bloqueante)
                job_json = self.redis_client.brpoplpush(
                    self.queue_name, 
                    self.processing_queue, 
                    timeout=5
                )
                
                if job_json:
                    job_data = json.loads(job_json)
                    
                    # Processar job
                    self.process_job(job_data)
                    
                    # Remover da fila de processamento
                    self.redis_client.lrem(self.processing_queue, 1, job_json)
                
                # Verificar se deve parar
                if self.redis_client.get(f"worker:{self.worker_id}:stop"):
                    logger.info(f"Recebido comando para parar worker {self.worker_id}")
                    self.running = False
                
                # Atualizar heartbeat
                self.redis_client.setex(
                    f"worker:{self.worker_id}:heartbeat",
                    30,  # Expira em 30 segundos
                    datetime.now().isoformat()
                )
                
            except redis.exceptions.ConnectionError:
                logger.error("Conexão com Redis perdida. Tentando reconectar...")
                time.sleep(5)
                self.reconnect_redis()
                
            except KeyboardInterrupt:
                logger.info("Worker interrompido pelo usuário")
                self.running = False
                
            except Exception as e:
                logger.error(f"Erro no worker: {str(e)}")
                time.sleep(1)
        
        logger.info(f"Worker {self.worker_id} finalizado")
    
    def reconnect_redis(self):
        """Reconectar ao Redis"""
        try:
            self.redis_client = redis.Redis(
                host=self.redis_host,
                port=self.redis_port,
                db=self.redis_db,
                decode_responses=True
            )
            logger.info("Reconectado ao Redis")
        except Exception as e:
            logger.error(f"Erro ao reconectar ao Redis: {str(e)}")
    
    def stop(self):
        """Parar o worker"""
        self.running = False
        logger.info("Sinal de parada recebido")

def main():
    """Função principal"""
    worker = ProcessWorker()
    
    try:
        worker.run()
    except KeyboardInterrupt:
        worker.stop()
    except Exception as e:
        logger.error(f"Erro fatal: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()