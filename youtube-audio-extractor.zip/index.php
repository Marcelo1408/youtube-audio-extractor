<?php
require_once 'config.php';
require_once 'db.php';
require_once 'app/YouTubeDownloader.php';
require_once 'app/QueueManager.php';

use App\YouTubeDownloader;
use App\QueueManager;

// Verificar se há mensagens de sucesso
$success_message = '';
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

// Verificar se há erros
$error_message = '';
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// Obter estatísticas do sistema
$db = new Database();
$conn = $db->getConnection();

$stats = [
    'total_processes' => 0,
    'completed_today' => 0,
    'active_users' => 0
];

try {
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_processes,
            SUM(CASE WHEN DATE(created_at) = CURDATE() AND status = 'completed' THEN 1 ELSE 0 END) as completed_today,
            COUNT(DISTINCT user_id) as active_users
        FROM processes
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt->execute();
    $stats = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} catch (Exception $e) {
    log_message("Erro ao obter estatísticas: " . $e->getMessage(), 'ERROR');
}

require_once 'includes/header.php';
?>

<div class="container">
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="hero-content">
            <h1 class="gradient-text">Extraia Áudio do YouTube <span class="highlight">Profissionalmente</span></h1>
            <p class="hero-description">
                Baixe vídeos, extraia áudio em alta qualidade e separe faixas automaticamente com IA.
                Tudo isso de forma rápida, segura e gratuita.
            </p>
            
            <div class="hero-stats">
                <div class="stat-item">
                    <div class="stat-number"><?php echo number_format($stats['total_processes']); ?></div>
                    <div class="stat-label">Processamentos</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo number_format($stats['completed_today']); ?></div>
                    <div class="stat-label">Hoje</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo number_format($stats['active_users']); ?></div>
                    <div class="stat-label">Usuários Ativos</div>
                </div>
            </div>
        </div>
        
        <div class="hero-illustration">
            <div class="visualizer">
                <div class="bar"></div><div class="bar"></div><div class="bar"></div>
                <div class="bar"></div><div class="bar"></div><div class="bar"></div>
                <div class="bar"></div><div class="bar"></div><div class="bar"></div>
            </div>
        </div>
    </div>

    <?php if ($success_message): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
        </div>
    <?php endif; ?>

    <?php if ($error_message): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
        </div>
    <?php endif; ?>

    <!-- Formulário de Processamento -->
    <div class="card process-card">
        <div class="card-header">
            <h2><i class="fas fa-magic"></i> Iniciar Novo Processamento</h2>
            <p>Cole a URL do YouTube e configure as opções desejadas</p>
        </div>
        
        <form id="processForm" class="process-form" method="POST" action="api/process.php">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            
            <div class="form-row">
                <div class="form-group col-md-8">
                    <label for="youtube_url">
                        <i class="fab fa-youtube"></i> URL do YouTube
                    </label>
                    <input type="url" 
                           id="youtube_url" 
                           name="youtube_url" 
                           class="form-control"
                           placeholder="https://www.youtube.com/watch?v=..."
                           required
                           autocomplete="off">
                    <div class="form-text">Cole o link completo do vídeo do YouTube</div>
                </div>
                
                <div class="form-group col-md-4">
                    <label for="quality">
                        <i class="fas fa-volume-up"></i> Qualidade
                    </label>
                    <select id="quality" name="quality" class="form-control">
                        <option value="64">64 kbps (Menor)</option>
                        <option value="128" selected>128 kbps (Padrão)</option>
                        <option value="192">192 kbps (Boa)</option>
                        <option value="320">320 kbps (Excelente)</option>
                    </select>
                </div>
            </div>
            
            <!-- Pré-visualização do Vídeo -->
            <div id="videoPreview" class="video-preview" style="display: none;">
                <div class="preview-loading">
                    <i class="fas fa-spinner fa-spin"></i> Carregando informações...
                </div>
                <div class="preview-content" style="display: none;">
                    <div class="preview-thumbnail">
                        <img id="previewThumb" src="" alt="">
                    </div>
                    <div class="preview-details">
                        <h4 id="previewTitle"></h4>
                        <div class="preview-meta">
                            <span id="previewChannel"></span>
                            <span id="previewDuration"></span>
                            <span id="previewViews"></span>
                        </div>
                        <p id="previewDescription" class="preview-description"></p>
                    </div>
                </div>
            </div>
            
            <!-- Opções Avançadas -->
            <div class="advanced-options">
                <button type="button" class="btn btn-link" data-toggle="collapse" data-target="#advancedOptions">
                    <i class="fas fa-cog"></i> Opções Avançadas
                </button>
                
                <div id="advancedOptions" class="collapse">
                    <div class="options-grid">
                        <div class="option-group">
                            <h5><i class="fas fa-sliders-h"></i> Separação de Faixas</h5>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="separate_tracks" id="noSeparate" value="0" checked>
                                <label class="form-check-label" for="noSeparate">
                                    Apenas converter para MP3
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="separate_tracks" id="separate2" value="2">
                                <label class="form-check-label" for="separate2">
                                    2 Faixas (Vocais + Acompanhamento)
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="separate_tracks" id="separate4" value="4">
                                <label class="form-check-label" for="separate4">
                                    4 Faixas (Vocais, Bateria, Baixo, Outros)
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="separate_tracks" id="separate5" value="5">
                                <label class="form-check-label" for="separate5">
                                    5 Faixas (Vocais, Bateria, Baixo, Piano, Outros)
                                </label>
                            </div>
                        </div>
                        
                        <div class="option-group">
                            <h5><i class="fas fa-file-export"></i> Formato de Saída</h5>
                            <select name="output_format" class="form-control">
                                <option value="mp3" selected>MP3 (Recomendado)</option>
                                <option value="wav">WAV (Alta qualidade)</option>
                                <option value="flac">FLAC (Lossless)</option>
                                <option value="ogg">OGG</option>
                            </select>
                            
                            <h5 class="mt-3"><i class="fas fa-cut"></i> Recortar Áudio</h5>
                            <div class="time-range">
                                <div class="time-input">
                                    <label>Início:</label>
                                    <input type="text" name="start_time" placeholder="00:00:00" class="form-control">
                                </div>
                                <div class="time-input">
                                    <label>Fim:</label>
                                    <input type="text" name="end_time" placeholder="00:00:00" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Botões de Ação -->
            <div class="form-actions">
                <button type="button" id="previewBtn" class="btn btn-secondary">
                    <i class="fas fa-eye"></i> Pré-visualizar
                </button>
                
                <?php if (isLoggedIn()): ?>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-play-circle"></i> Iniciar Processamento
                    </button>
                <?php else: ?>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#loginModal">
                        <i class="fas fa-sign-in-alt"></i> Faça Login para Continuar
                    </button>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Recursos e Funcionalidades -->
    <div class="features-section">
        <h2 class="section-title">Por que escolher nosso sistema?</h2>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-bolt"></i>
                </div>
                <h3>Processamento Rápido</h3>
                <p>Utilizamos tecnologia de ponta para processar seus vídeos em minutos</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-robot"></i>
                </div>
                <h3>Separação com IA</h3>
                <p>Spleeter AI separa faixas de áudio com precisão profissional</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-cloud-download-alt"></i>
                </div>
                <h3>Downloads Ilimitados</h3>
                <p>Baixe todos os arquivos processados sem limitações</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3>100% Seguro</h3>
                <p>Seus dados e arquivos são protegidos com criptografia</p>
            </div>
        </div>
    </div>

    <!-- Processamentos Recentes (se logado) -->
    <?php if (isLoggedIn()): ?>
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-history"></i> Seus Processamentos Recentes</h2>
                <a href="downloads.php" class="btn btn-link">Ver todos</a>
            </div>
            
            <div id="recentProcesses">
                <div class="loading-spinner">
                    <i class="fas fa-spinner fa-spin"></i> Carregando...
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Modal de Login -->
<div class="modal fade" id="loginModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Faça Login para Continuar</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Para processar vídeos do YouTube, é necessário ter uma conta.</p>
                <div class="modal-buttons">
                    <a href="login.php?redirect=process" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt"></i> Fazer Login
                    </a>
                    <a href="register.php" class="btn btn-secondary">
                        <i class="fas fa-user-plus"></i> Criar Conta
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Pré-visualização do vídeo
    const previewBtn = document.getElementById('previewBtn');
    const youtubeUrl = document.getElementById('youtube_url');
    const videoPreview = document.getElementById('videoPreview');
    
    previewBtn.addEventListener('click', function() {
        const url = youtubeUrl.value.trim();
        
        if (!url || !url.includes('youtube.com') && !url.includes('youtu.be')) {
            alert('Por favor, insira uma URL válida do YouTube');
            return;
        }
        
        // Mostrar loading
        videoPreview.style.display = 'block';
        videoPreview.querySelector('.preview-loading').style.display = 'block';
        videoPreview.querySelector('.preview-content').style.display = 'none';
        
        // Buscar informações via AJAX
        fetch('api/youtube.php?action=preview&url=' + encodeURIComponent(url))
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Atualizar preview
                    document.getElementById('previewThumb').src = data.thumbnail;
                    document.getElementById('previewTitle').textContent = data.title;
                    document.getElementById('previewChannel').innerHTML = 
                        `<i class="fas fa-user"></i> ${data.channel}`;
                    document.getElementById('previewDuration').innerHTML = 
                        `<i class="fas fa-clock"></i> ${data.duration_formatted}`;
                    document.getElementById('previewViews').innerHTML = 
                        `<i class="fas fa-eye"></i> ${data.view_count_formatted}`;
                    document.getElementById('previewDescription').textContent = 
                        data.description.substring(0, 200) + '...';
                    
                    // Mostrar conteúdo
                    videoPreview.querySelector('.preview-loading').style.display = 'none';
                    videoPreview.querySelector('.preview-content').style.display = 'flex';
                    
                    // Preencher campos automaticamente
                    if (data.duration > 3600) { // Mais de 1 hora
                        document.querySelector('input[name="end_time"]').value = '01:00:00';
                    }
                } else {
                    videoPreview.querySelector('.preview-loading').innerHTML = 
                        `<div class="alert alert-error">${data.error}</div>`;
                }
            })
            .catch(error => {
                videoPreview.querySelector('.preview-loading').innerHTML = 
                    '<div class="alert alert-error">Erro ao carregar informações</div>';
            });
    });
    
    // Envio do formulário
    const processForm = document.getElementById('processForm');
    
    processForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        <?php if (!isLoggedIn()): ?>
            $('#loginModal').modal('show');
            return;
        <?php endif; ?>
        
        // Validar URL
        const url = youtubeUrl.value.trim();
        if (!url || !url.includes('youtube.com') && !url.includes('youtu.be')) {
            alert('Por favor, insira uma URL válida do YouTube');
            return;
        }
        
        // Validar tempo (se preenchido)
        const startTime = document.querySelector('input[name="start_time"]').value;
        const endTime = document.querySelector('input[name="end_time"]').value;
        
        if (startTime && endTime) {
            if (!isValidTime(startTime) || !isValidTime(endTime)) {
                alert('Formato de hora inválido. Use HH:MM:SS');
                return;
            }
        }
        
        // Mostrar tela de processamento
        showProcessingScreen();
        
        // Enviar formulário via AJAX
        const formData = new FormData(processForm);
        
        fetch('api/process.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Redirecionar para página de status
                window.location.href = 'process.php?action=status&id=' + data.process_id;
            } else {
                hideProcessingScreen();
                alert('Erro: ' + data.error);
            }
        })
        .catch(error => {
            hideProcessingScreen();
            alert('Erro ao processar: ' + error.message);
        });
    });
    
    // Carregar processamentos recentes (se logado)
    <?php if (isLoggedIn()): ?>
    loadRecentProcesses();
    
    function loadRecentProcesses() {
        fetch('api/process.php?action=recent')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const container = document.getElementById('recentProcesses');
                    container.innerHTML = '';
                    
                    if (data.processes.length === 0) {
                        container.innerHTML = `
                            <div class="empty-state">
                                <i class="fas fa-music"></i>
                                <p>Nenhum processamento recente</p>
                            </div>
                        `;
                        return;
                    }
                    
                    data.processes.forEach(process => {
                        const processEl = createProcessElement(process);
                        container.appendChild(processEl);
                    });
                }
            });
    }
    
    function createProcessElement(process) {
        const statusClass = process.status;
        const statusText = {
            'pending': 'Pendente',
            'processing': 'Processando',
            'completed': 'Concluído',
            'failed': 'Falhou'
        };
        
        const progress = process.status === 'processing' ? 
            `<div class="progress-small">
                <div class="progress-fill" style="width: ${process.progress || 0}%"></div>
            </div>` : '';
        
        return document.createRange().createContextualFragment(`
            <div class="process-item">
                <div class="process-thumbnail">
                    <img src="${process.thumbnail || 'assets/img/default-thumb.jpg'}" 
                         alt="${process.video_title}">
                </div>
                <div class="process-details">
                    <h4>${process.video_title}</h4>
                    <div class="process-meta">
                        <span><i class="fas fa-clock"></i> ${process.duration_formatted}</span>
                        <span><i class="fas fa-calendar"></i> ${process.created_at_formatted}</span>
                        <span class="status ${statusClass}">
                            <i class="fas fa-circle"></i> ${statusText[process.status]}
                        </span>
                    </div>
                    ${progress}
                </div>
                <div class="process-actions">
                    ${process.status === 'completed' ? `
                        <a href="downloads.php?id=${process.id}" class="btn btn-primary btn-small">
                            <i class="fas fa-download"></i> Baixar
                        </a>
                    ` : ''}
                    ${process.status === 'processing' ? `
                        <a href="process.php?action=status&id=${process.id}" class="btn btn-small">
                            <i class="fas fa-eye"></i> Ver
                        </a>
                    ` : ''}
                </div>
            </div>
        `);
    }
    <?php endif; ?>
    
    // Funções auxiliares
    function isValidTime(time) {
        return /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/.test(time);
    }
    
    function showProcessingScreen() {
        const overlay = document.createElement('div');
        overlay.id = 'processingOverlay';
        overlay.innerHTML = `
            <div class="processing-modal">
                <div class="processing-icon">
                    <i class="fas fa-cog fa-spin"></i>
                </div>
                <h3>Processando seu vídeo...</h3>
                <p>Por favor, aguarde. Isso pode levar alguns minutos.</p>
                <div class="progress-container">
                    <div class="progress-bar">
                        <div class="progress-fill" id="overlayProgress"></div>
                    </div>
                    <div class="progress-text" id="overlayProgressText">Iniciando...</div>
                </div>
                <p class="processing-note">
                    <i class="fas fa-info-circle"></i>
                    Você será redirecionado automaticamente quando o processamento estiver completo.
                </p>
            </div>
        `;
        
        document.body.appendChild(overlay);
        document.body.style.overflow = 'hidden';
    }
    
    function hideProcessingScreen() {
        const overlay = document.getElementById('processingOverlay');
        if (overlay) {
            overlay.remove();
            document.body.style.overflow = '';
        }
    }
});

// Atualizar progresso do processamento (para quando estiver na página de status)
<?php if (isset($_GET['action']) && $_GET['action'] === 'status' && isset($_GET['id'])): ?>
function monitorProcessStatus(processId) {
    function checkStatus() {
        fetch(`api/process.php?action=status&id=${processId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateProcessStatus(data);
                    
                    if (data.status === 'completed') {
                        setTimeout(() => {
                            window.location.href = 'downloads.php?id=' + processId + '&success=1';
                        }, 2000);
                    } else if (data.status === 'failed') {
                        showProcessError(data.error);
                    } else {
                        setTimeout(checkStatus, 3000);
                    }
                }
            });
    }
    
    checkStatus();
}

monitorProcessStatus(<?php echo intval($_GET['id']); ?>);
<?php endif; ?>
</script>

<?php 
$db->close();
require_once 'includes/footer.php';
?>