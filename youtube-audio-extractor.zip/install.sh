#!/bin/bash
# Arquivo: install.sh
# YouTube Audio Extractor Pro - Instalador Automático VPS

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
error() { echo -e "${RED}[✗]${NC} $1"; exit 1; }

# Banner
echo -e "${BLUE}"
cat << "EOF"
╔══════════════════════════════════════════════════════════════╗
║      🎵 YOUTUBE AUDIO EXTRACTOR PRO - INSTALADOR VPS        ║
║              Node.js + MariaDB + Ubuntu 22.04               ║
╚══════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Verificar root
if [[ $EUID -ne 0 ]]; then
    error "Execute como root: sudo bash $0"
fi

# 1. Atualizar sistema
log "Atualizando sistema..."
apt update && apt upgrade -y

# 2. Instalar Node.js
log "Instalando Node.js 18.x..."
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs npm
npm install -g pm2

# 3. Instalar MariaDB
log "Instalando MariaDB..."
apt install -y mariadb-server mariadb-client
systemctl start mariadb
systemctl enable mariadb

# 4. Instalar dependências
log "Instalando dependências..."
apt install -y nginx ffmpeg python3 python3-pip certbot python3-certbot-nginx
apt install -y git curl wget unzip build-essential

# 5. Configurar banco de dados
log "Configurando banco de dados..."
mysql -e "CREATE DATABASE IF NOT EXISTS youtube_extractor;"
mysql -e "CREATE USER IF NOT EXISTS 'youtube_user'@'localhost' IDENTIFIED BY 'YoutubePass123!';"
mysql -e "GRANT ALL PRIVILEGES ON youtube_extractor.* TO 'youtube_user'@'localhost';"
mysql -e "FLUSH PRIVILEGES;"

# 6. Clonar projeto
log "Baixando projeto..."
cd /opt
git clone https://github.com/seu-usuario/youtube-extractor-pro.git
cd youtube-extractor-pro

# 7. Instalar dependências Node.js
log "Instalando dependências do Node.js..."
cd backend
npm install --production

# 8. Configurar Nginx
log "Configurando Nginx..."
cat > /etc/nginx/sites-available/youtube-extractor << 'NGINX'
server {
    listen 80;
    server_name _;
    
    # Frontend
    root /opt/youtube-extractor-pro;
    index index.html;
    
    # API Proxy
    location /api/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # WebSocket
    location /socket.io/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
    
    # Uploads
    location /uploads/ {
        alias /opt/youtube-extractor-pro/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    # HTML pages
    location / {
        try_files $uri $uri.html $uri/ =404;
    }
}
NGINX

ln -sf /etc/nginx/sites-available/youtube-extractor /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx

# 9. Configurar firewall
log "Configurando firewall..."
ufw --force enable
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force reload

# 10. Iniciar aplicação com PM2
log "Iniciando aplicação..."
cd /opt/youtube-extractor-pro/backend
pm2 start server.js --name "youtube-extractor"
pm2 save
pm2 startup

# 11. Criar diretórios
log "Criando diretórios..."
mkdir -p /opt/youtube-extractor-pro/uploads/{videos,audio,temp}
chown -R www-data:www-data /opt/youtube-extractor-pro/uploads
chmod -R 755 /opt/youtube-extractor-pro/uploads

# 12. Finalização
log "Instalação concluída com sucesso!"
echo ""
echo -e "${GREEN}=================================================${NC}"
echo -e "${BLUE}🎵 YouTube Audio Extractor Pro Instalado!${NC}"
echo -e "${GREEN}=================================================${NC}"
echo ""
echo "🌐 URL: http://$(curl -s ifconfig.me)"
echo "📁 Diretório: /opt/youtube-extractor-pro"
echo "🛠️  Comandos úteis:"
echo "   • Ver logs: pm2 logs youtube-extractor"
echo "   • Reiniciar: pm2 restart youtube-extractor"
echo "   • Status: pm2 status"
echo ""
echo "⚠️  IMPORTANTE:"
echo "   1. Configure seu domínio no arquivo .env"
echo "   2. Configure o banco de dados em backend/config/database.js"
echo "   3. Configure o email em backend/config/mailer.js"
echo ""
echo "✅ Pronto para uso! Acesse a URL acima para começar."