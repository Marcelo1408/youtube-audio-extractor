# YouTube Audio Extractor - Sistema Completo

Sistema profissional para extração de áudio de vídeos do YouTube com separação de faixas usando IA.

## 🚀 Características Principais

- **Download de vídeos do YouTube** em alta qualidade
- **Extração de áudio** em múltiplos formatos (MP3, WAV, FLAC, OGG)
- **Separação de faixas com IA** usando Spleeter (2, 4 ou 5 stems)
- **Processamento em background** com sistema de filas
- **Interface moderna e responsiva**
- **Sistema de usuários** com diferentes planos
- **Painel administrativo** completo
- **API REST** para integrações
- **Segurança avançada** com proteção contra abuso

## 🛠️ Requisitos do Sistema

### Servidor VPS (Recomendado)
- **Sistema Operacional**: Debian 12 ou Ubuntu 22.04
- **CPU**: 2+ núcleos (4+ recomendado)
- **RAM**: 4GB+ (8GB+ para melhor performance)
- **Armazenamento**: 50GB+ SSD
- **Python**: 3.8+
- **PHP**: 8.0+
- **MySQL**: 8.0+
- **Redis**: 6.0+

### Dependências
```bash
# Python
yt-dlp          # Download de vídeos do YouTube
spleeter        # Separação de faixas de áudio
tensorflow      # Machine Learning
pydub           # Processamento de áudio
redis           # Cliente Redis

# PHP
php8.0+         # PHP 8.0 ou superior
ext-mysql       # Extensão MySQL
ext-redis       # Extensão Redis
ext-curl        # Extensão cURL
ext-gd          # Extensão GD